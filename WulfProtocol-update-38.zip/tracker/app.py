"""Personal health & price tracker — run `python app.py`, then open http://127.0.0.1:8765"""
import importlib
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from datetime import date, datetime, timedelta
from pathlib import Path

import mimetypes

from flask import Flask, jsonify, request, send_from_directory

import browsers
import db
import inventory
import labs
import schedule as sch
import scraper
import sites as st

mimetypes.add_type("image/vnd.microsoft.icon", ".cur")      # Windows cursor files (some systems have no type for .cur)
app = Flask(__name__, static_folder="static", static_url_path="/static")
db.init()
for _m in db.q("SELECT id, route FROM meds WHERE route_type IS NULL"):   # older entries: guess the type from the route text
    db.x("UPDATE meds SET route_type=? WHERE id=?", (st.infer_route(_m["route"]), _m["id"]))

MED_FIELDS = ["name", "kind", "dose", "dose_unit", "route", "schedule", "start_date", "end_date", "cycle_on",
              "cycle_off", "stock_qty", "refill_lead_days", "color", "notes", "active", "route_type", "sites", "opened_on",
              "use_within_days", "vial_amount", "vial_unit", "diluent_ml", "container", "reference"]
PALETTE = ["#2f7dd1", "#e07a3f", "#3aa675", "#b05fd0", "#d9a521", "#d9534f", "#2aa5b5", "#7b8794"]


def err(msg, code=400):
    return jsonify({"error": msg}), code


@app.errorhandler(Exception)
def on_error(e):
    code = getattr(e, "code", 500)
    if code == 500:
        app.logger.exception(e)
    return jsonify({"error": str(getattr(e, "description", e))}), code if isinstance(code, int) else 500


def release_info():
    """The friendly release label (codename, status, version, tagline) from release.json: the one place it is written."""
    base = {"name": "WULFPROTOCOL", "codename": "MOONRISE", "status": "BETA", "version": "1.0", "tagline": "Your evolution starts here.", "splash_seconds": 12}
    try:
        base.update(json.loads((Path(__file__).resolve().parent / "release.json").read_text(encoding="utf-8")))
    except Exception:
        pass
    b = app_version()
    base["build"] = b
    base["build_id"] = f"{base['version']}-{str(base['status']).lower()}.{b}"
    return base


@app.route("/")
def index():
    import html as _h
    r = release_info()
    page = (Path(__file__).resolve().parent / "static" / "index.html").read_text(encoding="utf-8")
    for k in ("name", "codename", "status", "version", "tagline", "build_id", "splash_seconds"):
        page = page.replace(f"__{k.upper()}__", _h.escape(str(r[k])))
    page = re.sub(r'((?:src|href)="/static/[^"?]+)"', lambda m: f'{m.group(1)}?v={r["build"]}"', page)       # a new build never serves stale scripts
    resp = app.response_class(page, mimetype="text/html")
    resp.headers["Cache-Control"] = "no-cache"
    return resp


# ============================================================ medications
def clean_med(d, partial=False):
    out = {}
    for k in MED_FIELDS:
        if k in d:
            v = d[k]
            if k == "schedule" and not isinstance(v, str):
                v = json.dumps(v)
            if k in ("dose", "stock_qty") and v in ("", None):
                v = None
            elif k in ("dose", "stock_qty"):
                v = float(v)
            if k in ("cycle_on", "cycle_off", "refill_lead_days"):
                v = int(v or 0)
            if k == "end_date" and not v:
                v = None
            if k == "active":
                v = 1 if v else 0
            if k in ("vial_amount", "diluent_ml"):
                v = float(v) if v not in ("", None) else None
            if k == "reference":
                v = json.dumps(v, ensure_ascii=False) if isinstance(v, dict) and v else None
            if k == "container":
                v = "pen" if v == "pen" else "vial"
            if k == "use_within_days":
                v = int(v) if v not in ("", None) else None
            if k == "opened_on" and not v:
                v = None
            if k == "sites":
                v = json.dumps(v) if isinstance(v, list) and v else None
            if k == "route_type":
                v = v if v in st.ROUTES else "other"
            out[k] = v
    if out.get("route_type"):
        out["route"] = st.ROUTES[out["route_type"]]["short"]
    if not partial:
        if not out.get("name", "").strip():
            raise ValueError("Name is required")
        out.setdefault("start_date", date.today().isoformat())
    return out


def site_logs(mid):
    return db.q("SELECT site, taken_at FROM dose_logs WHERE med_id=? AND status='taken' AND site IS NOT NULL AND site!='' "
                "ORDER BY taken_at DESC LIMIT 500", (mid,))


def _clean_freq(f):
    t = f.get("type")
    if t not in ("daily", "interval", "weekdays"):
        raise ValueError
    out = {"type": t}
    if t == "interval":
        out["every"] = max(1, int(f.get("every") or 1))
    if t == "weekdays":
        out["days"] = sorted({int(d) for d in f.get("days") or [] if 0 <= int(d) <= 6})
        if not out["days"]:
            raise ValueError
    if f.get("times"):
        out["times"] = sorted({str(x)[:5] for x in f["times"]})
    return out


def plan_info(m, today=None):
    """Dose steps by week: where you are in the plan, and what the dose should be today."""
    try:
        steps = json.loads(m.get("phases") or "null")
    except Exception:
        steps = None
    if not steps:
        return None
    steps = sorted(({"from_week": int(x["from_week"]), "dose": float(x["dose"]), **({"to_week": int(x["to_week"])} if x.get("to_week") else {}),
                         **({"schedule": x["schedule"]} if x.get("schedule") else {})} for x in steps), key=lambda x: x["from_week"])
    today = today or date.today()
    try:
        start = date.fromisoformat((m.get("phase_start") or m["start_date"])[:10])
    except Exception:
        start = today
    week = max(1, (today - start).days // 7 + 1)
    cur = 0
    for i, x in enumerate(steps):
        if x["from_week"] <= week:
            cur = i
    nxt = steps[cur + 1] if cur + 1 < len(steps) else None
    end = steps[-1].get("to_week")
    base = sch.sched(m)
    for x in steps:
        x["text"] = sch.describe({**m, "schedule": json.dumps({**x["schedule"], "times": x["schedule"].get("times") or base["times"]}) if x.get("schedule") else m["schedule"]})
    return {"week": week, "start": start.isoformat(), "steps": steps, "current": cur, "dose": steps[cur]["dose"],
            "last_week": steps[-1]["from_week"], "end_week": end, "finished": bool(end and week > end),
            "next": ({**nxt, "on": (start + timedelta(weeks=nxt["from_week"] - 1)).isoformat()} if nxt else None)}


def sync_phases():
    """Keep each medication's dose equal to today's dose step."""
    for m in db.q("SELECT * FROM meds WHERE phases IS NOT NULL AND phases!=''"):
        p = plan_info(m)
        if p and p["dose"] != m["dose"]:
            db.x("UPDATE meds SET dose=? WHERE id=?", (p["dose"], m["id"]))


@app.put("/api/meds/<int:mid>/phases")
def med_phases(mid):
    d = request.json or {}
    m = db.q("SELECT * FROM meds WHERE id=?", (mid,), one=True)
    if not m:
        return err("Not found", 404)
    steps = d.get("steps")
    if not steps:
        db.x("UPDATE meds SET phases=NULL, phase_start=NULL WHERE id=?", (mid,))
        return jsonify({"ok": True})
    try:
        clean, seen = [], set()
        for x in steps:
            w, dose = int(x["from_week"]), float(x["dose"])
            if w < 1 or dose <= 0:
                raise ValueError
            if w not in seen:
                seen.add(w)
                clean.append({"from_week": w, "dose": dose, **({"to_week": int(x["to_week"])} if x.get("to_week") else {}),
                              **({"schedule": _clean_freq(x["schedule"])} if x.get("schedule") else {})})
        top = max(clean, key=lambda x: x["from_week"])         # only the last step can carry an end week
        for c in clean:
            if c is not top:
                c.pop("to_week", None)
        if top.get("to_week") and top["to_week"] < top["from_week"]:
            top.pop("to_week")
        start = (d.get("start") or m["start_date"])[:10]
        date.fromisoformat(start)
    except (KeyError, ValueError, TypeError):
        return err("Check the weeks and doses")
    db.x("UPDATE meds SET phases=?, phase_start=? WHERE id=?", (json.dumps(sorted(clean, key=lambda x: x["from_week"])), start, mid))
    sync_phases()
    return jsonify({"ok": True})


@app.post("/api/meds/<int:mid>/plan-action")
def med_plan_action(mid):
    """hold = stay on today's step one more week (later steps slide back a week); back = restart from the previous step."""
    m = db.q("SELECT * FROM meds WHERE id=?", (mid,), one=True)
    p = plan_info(m) if m else None
    if not p:
        return err("No dose steps on this medication")
    steps, cur = [{k: v for k, v in x.items() if k != "text"} for x in p["steps"]], p["current"]
    act = (request.json or {}).get("action")
    start = p["start"]
    if act == "hold":
        for i, x in enumerate(steps):
            if i > cur:
                x["from_week"] += 1
            if x.get("to_week"):
                x["to_week"] += 1
    elif act == "back":
        if cur == 0:
            return err("You're already on the first step")
        start = (date.today() - timedelta(weeks=steps[cur - 1]["from_week"] - 1)).isoformat()
    else:
        return err("Unknown action")
    db.x("UPDATE meds SET phases=?, phase_start=? WHERE id=?", (json.dumps(steps), start, mid))
    sync_phases()
    return jsonify({"ok": True})


def med_view(m):
    m = dict(m)
    m["route_type"] = m.get("route_type") or st.infer_route(m.get("route"))
    ri = st.ROUTES[m["route_type"]]
    m["route_label"], m["route_icon"] = ri["label"], ri["icon"]
    m["has_sites"] = bool(st.enabled_sites(m))
    m["expiry"] = st.expiry_info(m)
    m["schedule_obj"] = sch.sched(m)
    m["plan"] = plan_info(m)
    m["schedule_text"] = sch.describe({**m, "schedule": json.dumps(sch.effective(m))}) if m.get("phases") else sch.describe(m)
    try:
        m["reference_obj"] = json.loads(m["reference"]) if m.get("reference") else None
    except Exception:
        m["reference_obj"] = None
    if m["reference_obj"] and m["reference_obj"].get("name"):          # show the current version of the saved reference sheet
        row = db.q("SELECT data FROM library WHERE lower(name)=lower(?)", (m["reference_obj"]["name"],), one=True)
        if row:
            try:
                d = json.loads(row["data"])
                m["reference_obj"] = {"name": m["reference_obj"]["name"], "group": ", ".join(d.get("groups") or []), "names": d.get("names", ""),
                                      **{k: d.get(k, "") for k in ("indications", "reconstitute", "storage", "dosage", "onset", "half_life", "side_effects", "notes")}}
            except Exception:
                pass
    return m


@app.get("/api/meds")
def meds_list():
    sync_phases()
    include_inactive = request.args.get("all") == "1"
    rows = db.q("SELECT * FROM meds" + ("" if include_inactive else " WHERE active=1") + " ORDER BY active DESC, name")
    now, grace = datetime.now(), db.get_settings()["grace_minutes"]
    out = []
    for m in rows:
        v = med_view(m)
        logged = {r["slot"] for r in db.q("SELECT slot FROM dose_logs WHERE med_id=? AND slot>=?",
                                          (m["id"], now.strftime("%Y-%m-%d")))}
        v["cycle"] = sch.cycle_info(m)
        v["refill"] = sch.refill_info(m, logged, now, grace)
        nxt = next((s for s in sch.slots_between(m, now, now + timedelta(days=60)) if sch.iso(s) not in logged), None)
        v["next_dose"] = sch.iso(nxt) if nxt else None
        v["site_info"] = st.site_info(v, site_logs(m["id"])) if v["has_sites"] else None
        out.append(v)
    return jsonify(out)


@app.get("/api/route-types")
def route_types():
    return jsonify(st.ROUTES)


@app.post("/api/meds")
def med_create():
    d = clean_med(request.json)
    if not d.get("color"):
        d["color"] = PALETTE[db.q("SELECT COUNT(*) n FROM meds", one=True)["n"] % len(PALETTE)]
    cols = ",".join(d)
    mid = db.x(f"INSERT INTO meds({cols}) VALUES ({','.join('?' * len(d))})", tuple(d.values()))
    return jsonify({"id": mid})


@app.put("/api/meds/<int:mid>")
def med_update(mid):
    d = clean_med(request.json, partial=True)
    if d:
        db.x(f"UPDATE meds SET {','.join(k + '=?' for k in d)} WHERE id=?", (*d.values(), mid))
    return jsonify({"ok": True})


def _catchup_slots(m, since, until=None, skip=()):
    """Scheduled doses from `since` up to now (or `until`, exclusive) that aren't logged yet. m needs schedule, start_date, cycle fields."""
    now = datetime.now()
    a = datetime.combine(date.fromisoformat(since[:10]), datetime.min.time())
    b = now if not until else min(now, datetime.combine(date.fromisoformat(until[:10]), datetime.min.time()) - timedelta(minutes=1))
    skip = set(skip)
    return [s for s in sch.slots_between({**m, "start_date": min(m["start_date"], since[:10])}, a, b) if sch.iso(s) not in skip][:2000]


@app.post("/api/meds/preview-catch-up")
def med_catchup_preview():
    d = request.json or {}
    try:
        m = {"schedule": d.get("schedule") or {"type": "daily", "times": ["08:00"]}, "start_date": d["since"][:10], "end_date": d.get("end_date") or None,
             "cycle_on": int(d.get("cycle_on") or 0), "cycle_off": int(d.get("cycle_off") or 0)}
        slots = _catchup_slots(m, d["since"], d.get("until"))
    except (KeyError, ValueError, TypeError):
        return err("Check the dates")
    dose = float(d["dose"]) if d.get("dose") not in (None, "") else None
    out = {"count": len(slots), "used": round(dose * len(slots), 4) if dose else None}
    if dose and d.get("start_stock") not in (None, ""):
        left = max(0.0, float(d["start_stock"]) - dose * len(slots))
        out.update(left=round(left, 4), doses_left=int(left // dose))
    return jsonify(out)


@app.post("/api/meds/<int:mid>/catch-up")
def med_catchup(mid):
    """You started a medication before you added it: record the scheduled doses since `since` as taken (assumed) and work out what's left."""
    d = request.json or {}
    m = db.q("SELECT * FROM meds WHERE id=?", (mid,), one=True)
    if not m:
        return err("Not found", 404)
    since = (d.get("since") or m["start_date"])[:10]
    have = {r["slot"] for r in db.q("SELECT slot FROM dose_logs WHERE med_id=? AND slot IS NOT NULL", (mid,))}
    try:
        slots = _catchup_slots(m, since, d.get("until"), have)
    except ValueError:
        return err("Check the dates")
    for s in slots:
        key = sch.iso(s)
        db.x("INSERT INTO dose_logs(med_id,slot,status,taken_at,amount,notes) VALUES (?,?,?,?,?,?)",
             (mid, key, "taken", key, m["dose"], "added by catch-up (assumed taken)"))
    out = {"added": len(slots)}
    if d.get("start_stock") not in (None, "") and m["dose"]:
        used = db.q("SELECT COALESCE(SUM(amount),0) u FROM dose_logs WHERE med_id=? AND status='taken' AND taken_at>=?", (mid, since), one=True)["u"]
        left = max(0.0, float(d["start_stock"]) - used)
        db.x("UPDATE meds SET stock_qty=? WHERE id=?", (left, mid))
        out.update(stock=round(left, 4), doses_left=int(left // m["dose"]))
    return jsonify(out)


LIB_FIELDS = ["groups", "names", "indications", "reconstitute", "storage", "dosage", "onset", "half_life", "side_effects", "notes"]


def _lib_clean(d):
    d = d or {}
    name = (d.get("name") or "").strip()
    out = {"name": name}
    for k in LIB_FIELDS:
        v = d.get(k)
        if k == "groups":
            out[k] = [str(g).strip() for g in v if str(g).strip()] if isinstance(v, list) else []
        else:
            out[k] = v.strip() if isinstance(v, str) else ""
    return name, out


def _lib_row(r):
    try:
        d = json.loads(r["data"])
    except Exception:
        d = {}
    d["id"], d["name"] = r["id"], r["name"]
    return d


@app.get("/api/library")
def library_list():
    return jsonify([_lib_row(r) for r in db.q("SELECT * FROM library ORDER BY name COLLATE NOCASE")])


@app.post("/api/library")
def library_add():
    name, d = _lib_clean(request.json)
    if not name:
        return err("Give it a name.")
    return jsonify({"id": db.x("INSERT INTO library(name,data) VALUES (?,?)", (name, json.dumps(d, ensure_ascii=False)))})


@app.put("/api/library/<int:lid>")
def library_put(lid):
    name, d = _lib_clean(request.json)
    if not name:
        return err("Give it a name.")
    db.x("UPDATE library SET name=?, data=? WHERE id=?", (name, json.dumps(d, ensure_ascii=False), lid))
    return jsonify({"ok": True})


@app.delete("/api/library/<int:lid>")
def library_del(lid):
    db.x("DELETE FROM library WHERE id=?", (lid,))
    return jsonify({"ok": True})


@app.get("/api/meds/<int:mid>/supplies")
def med_supplies_get(mid):
    return jsonify(inventory.supplies_for(mid))


@app.put("/api/meds/<int:mid>/supplies")
def med_supplies_put(mid):
    if not db.q("SELECT id FROM meds WHERE id=?", (mid,), one=True):
        return err("Unknown medication", 404)
    inventory.set_supplies(mid, (request.json or {}).get("links") or [])
    return jsonify({"ok": True})


@app.delete("/api/meds/<int:mid>")
def med_delete(mid):
    db.x("DELETE FROM meds WHERE id=?", (mid,))
    return jsonify({"ok": True})


@app.post("/api/meds/<int:mid>/restock")
def med_restock(mid):
    d = request.json
    qty = float(d["qty"])
    m = db.q("SELECT stock_qty FROM meds WHERE id=?", (mid,), one=True)
    new = qty if d.get("mode") == "set" else (m["stock_qty"] or 0) + qty
    db.x("UPDATE meds SET stock_qty=? WHERE id=?", (new, mid))
    if d.get("new_vial"):                       # a fresh vial / bottle: restart the expiry clock
        db.x("UPDATE meds SET opened_on=? WHERE id=?", (date.today().isoformat(), mid))
    return jsonify({"stock_qty": new})


@app.get("/api/meds/<int:mid>")
def med_detail(mid):
    sync_phases()
    m = db.q("SELECT * FROM meds WHERE id=?", (mid,), one=True)
    if not m:
        return err("Not found", 404)
    now, grace = datetime.now(), db.get_settings()["grace_minutes"]
    v = med_view(m)
    logs = db.q("SELECT * FROM dose_logs WHERE med_id=? ORDER BY taken_at DESC LIMIT 200", (mid,))
    logged = {l["slot"] for l in logs if l["slot"]}
    v["cycle"] = sch.cycle_info(m)
    v["refill"] = sch.refill_info(m, logged, now, grace)
    v["logs"] = logs
    ec = {}
    for l in logs:
        if l["status"] == "taken" and l.get("effects"):
            try:
                for e in json.loads(l["effects"]):
                    ec[e] = ec.get(e, 0) + 1
            except Exception:
                pass
    v["effect_counts"] = sorted(ec.items(), key=lambda kv: -kv[1])
    v["effect_doses"] = sum(1 for l in logs if l["status"] == "taken")
    v["site_info"] = st.site_info(v, site_logs(mid)) if v["has_sites"] else None
    # open slots the user can log against (last 14 days unlogged + next 3)
    a = max(datetime.combine(date.fromisoformat(m["start_date"]), datetime.min.time()), now - timedelta(days=14))
    v["open_slots"] = [sch.iso(s) for s in sch.slots_between(m, a, now + timedelta(days=3)) if sch.iso(s) not in logged]
    # weekly counts, last 12 weeks
    wk = []
    monday = date.today() - timedelta(days=date.today().weekday())
    for i in range(11, -1, -1):
        w0 = monday - timedelta(weeks=i)
        w1 = w0 + timedelta(days=7)
        n = sum(1 for l in logs if l["status"] == "taken" and w0.isoformat() <= l["taken_at"][:10] < w1.isoformat())
        wk.append({"week": w0.isoformat(), "count": n})
    v["weekly"] = wk
    stats = adherence(m, logs, now, grace, 30)
    stats["total_taken"] = db.q("SELECT COUNT(*) n FROM dose_logs WHERE med_id=? AND status='taken'", (mid,), one=True)["n"]
    v["stats"] = stats
    return jsonify(v)


def adherence(m, logs, now, grace, days):
    by_slot = {l["slot"]: l for l in logs if l["slot"]}
    start = max(datetime.combine(date.fromisoformat(m["start_date"]), datetime.min.time()), now - timedelta(days=days))
    t = s = ms = 0
    for slot in sch.slots_between(m, start, now):
        l = by_slot.get(sch.iso(slot))
        if l:
            t += l["status"] == "taken"
            s += l["status"] == "skipped"
        elif now - slot > timedelta(minutes=grace):
            ms += 1
    total = t + s + ms
    return {"taken": t, "skipped": s, "missed": ms, "pct": round(100 * t / total) if total else None}


# ============================================================ dose logs
@app.post("/api/logs")
def log_create():
    sync_phases()
    d = request.json
    m = db.q("SELECT * FROM meds WHERE id=?", (d["med_id"],), one=True)
    if not m:
        return err("Unknown medication", 404)
    status = d.get("status", "taken")
    taken_at = d.get("taken_at") or datetime.now().strftime("%Y-%m-%dT%H:%M")
    amount = d.get("amount")
    amount = float(amount) if amount not in (None, "") else m["dose"]
    slot = d.get("slot") or None
    if slot and db.q("SELECT 1 FROM dose_logs WHERE med_id=? AND slot=?", (m["id"], slot)):
        return err("That dose is already logged", 409)
    eff = [str(x).strip()[:60] for x in (d.get("effects") or []) if str(x).strip()][:20]
    lid = db.x("INSERT INTO dose_logs(med_id,slot,status,taken_at,amount,site,notes,effects) VALUES (?,?,?,?,?,?,?,?)",
               (m["id"], slot, status, taken_at, amount if status == "taken" else None, d.get("site"), d.get("notes"),
                json.dumps(eff, ensure_ascii=False) if eff and status == "taken" else None))
    if status == "taken" and m["stock_qty"] is not None and amount:
        db.x("UPDATE meds SET stock_qty=MAX(0, stock_qty-?) WHERE id=?", (amount, m["id"]))
    if status == "taken":
        inventory.use_for_dose(m["id"], -1)           # syringes, swabs, etc. linked to this med
    return jsonify({"id": lid})


@app.delete("/api/logs/<int:lid>")
def log_delete(lid):
    l = db.q("SELECT l.*, m.stock_qty FROM dose_logs l JOIN meds m ON m.id=l.med_id WHERE l.id=?", (lid,), one=True)
    if l:
        if l["status"] == "taken" and l["stock_qty"] is not None and l["amount"]:
            db.x("UPDATE meds SET stock_qty=stock_qty+? WHERE id=?", (l["amount"], l["med_id"]))
        if l["status"] == "taken":
            inventory.use_for_dose(l["med_id"], +1)
        db.x("DELETE FROM dose_logs WHERE id=?", (lid,))
    return jsonify({"ok": True})


# ============================================================ dashboard
def build_dashboard():
    sync_phases()
    now = datetime.now()
    cfg = db.get_settings()
    grace = cfg["grace_minutes"]
    today = now.date()
    meds = db.q("SELECT * FROM meds WHERE active=1") if cfg["use_meds"] else []
    due, missed, today_list, upcoming, refills, cycles, expiring = [], [], [], [], [], [], []
    tot = {"taken": 0, "skipped": 0, "missed": 0}
    for m in meds:
        logs = db.q("SELECT * FROM dose_logs WHERE med_id=? AND slot IS NOT NULL AND slot>=?",
                    (m["id"], sch.iso(now - timedelta(days=31))))
        by_slot = {l["slot"]: l for l in logs}
        mv = med_view(m)
        si = st.site_info(mv, site_logs(m["id"])) if mv["has_sites"] else None
        base = {"med_id": m["id"], "name": m["name"], "color": m["color"], "dose": m["dose"],
                "unit": m["dose_unit"], "route": mv["route_label"] and st.ROUTES[mv["route_type"]]["short"],
                "route_icon": mv["route_icon"], "has_sites": mv["has_sites"], "next_site": si["suggest"] if si else None}
        if mv["expiry"] and mv["expiry"]["low"]:
            expiring.append({**base, **mv["expiry"]})
        start = max(datetime.combine(date.fromisoformat(m["start_date"]), datetime.min.time()), now - timedelta(days=30))
        for slot in sch.slots_between(m, start, now + timedelta(days=7, hours=23)):
            key = sch.iso(slot)
            l = by_slot.get(key)
            item = {**base, "slot": key}
            if slot <= now:
                if l:
                    item["status"] = l["status"]
                    tot[l["status"]] += 1
                elif now - slot > timedelta(minutes=grace):
                    item["status"] = "missed"
                    tot["missed"] += 1
                    if slot >= now - timedelta(days=7):
                        missed.append(item)
                else:
                    item["status"] = "due"
                    due.append(item)
            else:
                item["status"] = "taken" if (l and l["status"] == "taken") else ("skipped" if l else "upcoming")
                if not l:
                    upcoming.append(item)
            if slot.date() == today:
                today_list.append(item)
        logged = set(by_slot)
        r = sch.refill_info(m, logged, now, grace)
        if r and r.get("low"):
            refills.append({**base, **r})
        c = sch.cycle_info(m)
        if c["state"] != "ended" and (c["enabled"] or c.get("days_to_end") is not None or c["state"] == "not_started"):
            cycles.append({**base, **c, "cycle_on": m["cycle_on"], "cycle_off": m["cycle_off"]})
    missed.sort(key=lambda i: i["slot"], reverse=True)
    due.sort(key=lambda i: i["slot"])
    today_list.sort(key=lambda i: i["slot"])
    upcoming.sort(key=lambda i: i["slot"])
    refills.sort(key=lambda r: (r["days_left"] if r["days_left"] is not None else 999))
    denom = sum(tot.values())
    return {
        "now": now.strftime("%Y-%m-%dT%H:%M"),
        "due": due, "missed": missed, "today": today_list, "upcoming": upcoming[:40],
        "refills": refills, "cycles": cycles, "expiring": expiring,
        "adherence": {**tot, "pct": round(100 * tot["taken"] / denom) if denom else None},
        "med_count": len(meds),
        "fitness": fitness_summary() if cfg["use_fitness"] else None,
        "prices": price_highlights() if cfg["use_prices"] else None,
        "labs": labs.summary() if cfg["use_fitness"] else None,
        "inventory": inventory.summary(items_payload(with_history=False)),
    }


@app.get("/api/dashboard")
def dashboard():
    return jsonify(build_dashboard())


# ============================================================ fitness
def age_of(birth):
    if not birth:
        return None
    b, t = date.fromisoformat(birth), date.today()
    return t.year - b.year - ((t.month, t.day) < (b.month, b.day))


def fitness_summary():
    p = db.q("SELECT * FROM profile WHERE id=1", one=True)
    w = db.q("SELECT date,value FROM metrics WHERE metric='weight' ORDER BY date DESC, id DESC LIMIT 400")
    out = {"profile": p, "age": age_of(p["birth_date"]), "weights": list(reversed(w[:60]))}
    if w:
        cur = w[0]
        out["latest"] = cur
        out["days_since_weight"] = (date.today() - date.fromisoformat(cur["date"])).days
        out["remind_days"] = db.get_settings()["weigh_reminder_days"]
        out["weigh_due"] = out["remind_days"] > 0 and out["days_since_weight"] >= out["remind_days"]
        cutoff = (date.today() - timedelta(days=30)).isoformat()
        older = [r for r in w if r["date"] <= cutoff]
        ref = older[0] if older else w[-1]
        out["change_30d"] = round(cur["value"] - ref["value"], 2) if ref is not cur else None
        if p["height_cm"]:
            out["bmi"] = round(cur["value"] / (p["height_cm"] / 100) ** 2, 1)
    return out


@app.get("/api/profile")
def profile_get():
    p = db.q("SELECT * FROM profile WHERE id=1", one=True)
    p["age"] = age_of(p["birth_date"])
    return jsonify(p)


@app.put("/api/profile")
def profile_put():
    d = request.json
    cols = [k for k in ("height_cm", "birth_date", "sex", "goal_weight_kg", "units") if k in d]
    vals = [(d[k] if d[k] not in ("",) else None) for k in cols]
    if cols:
        db.x(f"UPDATE profile SET {','.join(c + '=?' for c in cols)} WHERE id=1", vals)
    return jsonify({"ok": True})


@app.get("/api/metrics")
def metrics_list():
    return jsonify(db.q("SELECT * FROM metrics ORDER BY date, id"))


@app.post("/api/metrics")
def metrics_add():
    d = request.json
    db.x("INSERT INTO metrics(date,metric,value,notes) VALUES (?,?,?,?)",
         (d.get("date") or date.today().isoformat(), d["metric"], float(d["value"]), d.get("notes")))
    return jsonify({"ok": True})


@app.delete("/api/metrics/<int:mid>")
def metrics_del(mid):
    db.x("DELETE FROM metrics WHERE id=?", (mid,))
    return jsonify({"ok": True})


# ============================================================ labs & events
def _num(v):
    return None if v in (None, "") else float(v)


@app.get("/api/labs")
def labs_get():
    return jsonify(labs.build())


@app.get("/api/labs/presets")
def labs_presets():
    p = db.q("SELECT sex FROM profile WHERE id=1", one=True)
    have = {r["name"].lower() for r in db.q("SELECT name FROM biomarkers")}
    out = labs.presets((p or {}).get("sex"))
    for x in out:
        x["added"] = x["name"].lower() in have
    return jsonify({"presets": out, "categories": labs.CATEGORIES})


@app.post("/api/biomarkers")
def biomarker_add():
    items = request.json if isinstance(request.json, list) else [request.json]
    ids = []
    for d in items:
        name = (d.get("name") or "").strip()
        if not name:
            return jsonify({"error": "Give the marker a name"}), 400
        if db.q("SELECT id FROM biomarkers WHERE lower(name)=lower(?)", (name,), one=True):
            continue                                            # already tracked
        ids.append(db.x("INSERT INTO biomarkers(name,unit,category,ref_low,ref_high,retest_days,notes) VALUES (?,?,?,?,?,?,?)",
                        (name, d.get("unit") or "", d.get("category") or "Other", _num(d.get("ref_low")), _num(d.get("ref_high")),
                         int(d["retest_days"]) if d.get("retest_days") not in (None, "") else None, d.get("notes"))))
    return jsonify({"ok": True, "ids": ids})


@app.put("/api/biomarkers/<int:bid>")
def biomarker_put(bid):
    d = request.json
    cols, vals = [], []
    for k in ("name", "unit", "category", "notes"):
        if k in d:
            cols.append(k); vals.append(d[k])
    for k in ("ref_low", "ref_high"):
        if k in d:
            cols.append(k); vals.append(_num(d[k]))
    if "retest_days" in d:
        cols.append("retest_days"); vals.append(int(d["retest_days"]) if d["retest_days"] not in (None, "") else None)
    if cols:
        db.x(f"UPDATE biomarkers SET {','.join(c + '=?' for c in cols)} WHERE id=?", (*vals, bid))
    return jsonify({"ok": True})


@app.delete("/api/biomarkers/<int:bid>")
def biomarker_del(bid):
    db.x("DELETE FROM lab_results WHERE biomarker_id=?", (bid,))
    db.x("DELETE FROM biomarkers WHERE id=?", (bid,))
    return jsonify({"ok": True})


@app.post("/api/lab-results")
def lab_results_add():
    d = request.json
    when = d.get("date") or date.today().isoformat()
    n = 0
    for r in d.get("results", []):
        if r.get("value") in (None, ""):
            continue
        db.x("INSERT INTO lab_results(biomarker_id,date,value,lab,notes) VALUES (?,?,?,?,?)",
             (int(r["biomarker_id"]), when, float(r["value"]), d.get("lab"), r.get("notes") or d.get("notes")))
        n += 1
    return jsonify({"ok": True, "added": n})


@app.put("/api/lab-results/<int:rid>")
def lab_result_put(rid):
    d = request.json
    db.x("UPDATE lab_results SET date=COALESCE(?,date), value=COALESCE(?,value), lab=?, notes=? WHERE id=?",
         (d.get("date"), _num(d.get("value")), d.get("lab"), d.get("notes"), rid))
    return jsonify({"ok": True})


@app.delete("/api/lab-results/<int:rid>")
def lab_result_del(rid):
    db.x("DELETE FROM lab_results WHERE id=?", (rid,))
    return jsonify({"ok": True})


@app.get("/api/events")
def events_get():
    return jsonify({"events": labs.all_events(), "types": labs.EVENT_TYPES})


@app.post("/api/events")
def event_add():
    d = request.json
    if not (d.get("title") or "").strip():
        return jsonify({"error": "Give the event a title"}), 400
    i = db.x("INSERT INTO events(date,end_date,type,title,notes,med_id) VALUES (?,?,?,?,?,?)",
             (d.get("date") or date.today().isoformat(), d.get("end_date") or None, d.get("type") or "other",
              d["title"].strip(), d.get("notes"), d.get("med_id") or None))
    return jsonify({"ok": True, "id": i})


@app.put("/api/events/<int:eid>")
def event_put(eid):
    d = request.json
    db.x("UPDATE events SET date=?, end_date=?, type=?, title=?, notes=?, med_id=? WHERE id=?",
         (d.get("date"), d.get("end_date") or None, d.get("type") or "other", (d.get("title") or "").strip(), d.get("notes"),
          d.get("med_id") or None, eid))
    return jsonify({"ok": True})


@app.delete("/api/events/<int:eid>")
def event_del(eid):
    db.x("DELETE FROM events WHERE id=?", (eid,))
    return jsonify({"ok": True})


@app.get("/api/labs/export.csv")
def labs_csv():
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["date", "marker", "value", "unit", "ref_low", "ref_high", "status", "lab", "notes"])
    for b in labs.build()["biomarkers"]:
        for r in b["results"]:
            w.writerow([r["date"], b["name"], r["value"], b["unit"], b["ref_low"], b["ref_high"], r["status"], r["lab"] or "", r["notes"] or ""])
    resp = app.response_class(buf.getvalue(), mimetype="text/csv")
    resp.headers["Content-Disposition"] = f"attachment; filename=labs-{date.today()}.csv"
    return resp


# ============================================================ inventory
INV_FIELDS = ("name", "category", "unit", "size", "expiry_date", "lot", "location", "notes")


def _inv_vals(d):
    cols, vals = [], []
    for k in INV_FIELDS:
        if k in d:
            cols.append(k); vals.append((d[k] or None) if k not in ("name", "category", "unit") else (d[k] or None))
    for k in ("qty", "low_at", "per_dose"):
        if k in d:
            cols.append(k); vals.append(float(d[k]) if d[k] not in (None, "") else None)
    for k in ("med_id", "price_item_id"):
        if k in d:
            cols.append(k); vals.append(int(d[k]) if d[k] not in (None, "") else None)
    return cols, vals


@app.get("/api/inventory")
def inventory_get():
    return jsonify(inventory.build(items_payload(with_history=False)))


@app.post("/api/inventory")
def inventory_add():
    items = request.json if isinstance(request.json, list) else [request.json]
    ids = []
    for d in items:
        if not (d.get("name") or "").strip():
            return err("Give the item a name")
        d = {**d, "name": d["name"].strip(), "qty": d.get("qty") or 0, "category": d.get("category") or "Supplies", "unit": d.get("unit") or "pcs"}
        cols, vals = _inv_vals(d)
        i = db.x(f"INSERT INTO inventory({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals)
        start = float(d["qty"] or 0)
        if start > 0:
            db.x("INSERT INTO inventory_log(inv_id,ts,change,qty_after,reason) VALUES (?,?,?,?,?)", (i, inventory._now(), start, start, "starting amount"))
        ids.append(i)
    return jsonify({"ok": True, "ids": ids})


@app.put("/api/inventory/<int:iid>")
def inventory_put(iid):
    d = request.json
    qty = d.pop("qty", None)
    cols, vals = _inv_vals(d)
    if cols:
        db.x(f"UPDATE inventory SET {','.join(c + '=?' for c in cols)} WHERE id=?", (*vals, iid))
    if qty not in (None, ""):
        inventory.adjust(iid, reason="corrected", set_to=float(qty))
    return jsonify({"ok": True})


@app.delete("/api/inventory/<int:iid>")
def inventory_del(iid):
    db.x("DELETE FROM inventory WHERE id=?", (iid,))
    return jsonify({"ok": True})


@app.post("/api/inventory/<int:iid>/adjust")
def inventory_adjust(iid):
    d = request.json
    if d.get("set") not in (None, ""):
        new = inventory.adjust(iid, reason=d.get("reason") or "corrected", note=d.get("note"), set_to=float(d["set"]))
    else:
        new = inventory.adjust(iid, float(d["delta"]), d.get("reason") or ("restocked" if float(d["delta"]) > 0 else "used"), d.get("note"))
    if new is None:
        return err("Not found", 404)
    return jsonify({"qty": new})


@app.post("/api/inventory/<int:iid>/open-vial")
def inventory_open_vial(iid):
    r = inventory.open_vial(iid)
    return (jsonify(r), 400) if r.get("error") else jsonify(r)


@app.get("/api/orders")
def orders_get():
    return jsonify(inventory.orders_payload())


@app.post("/api/orders")
def orders_add():
    d = request.json or {}
    lines = [ln for ln in (d.get("lines") or []) if float(ln.get("qty") or 0) > 0]
    if not lines:
        return err("Nothing to order")
    ids = inventory.add_orders(lines, d.get("ordered_on"), d.get("expected_by"))
    return jsonify({"ok": True, "ids": ids})


@app.post("/api/orders/<int:oid>/receive")
def orders_receive(oid):
    d = request.json or {}
    try:
        r = inventory.receive_order(oid, d.get("qty"), d.get("per_item") or 1, int(d["inv_id"]) if d.get("inv_id") not in (None, "") else None,
                                    d.get("new_item"), d.get("lot"), d.get("expiry_date"), d.get("note"), d.get("received_on"))
    except ValueError:
        return err("Check the numbers you entered")
    return (jsonify(r), 400) if r.get("error") else jsonify(r)


@app.post("/api/orders/<int:oid>/cancel")
def orders_cancel(oid):
    db.x("UPDATE orders SET status='cancelled' WHERE id=? AND status='open'", (oid,))
    return jsonify({"ok": True})


@app.put("/api/orders/<int:oid>")
def orders_put(oid):
    d = request.json or {}
    cols, vals = [], []
    for k in ("expected_by", "site", "notes"):
        if k in d:
            cols.append(k); vals.append(d[k] or None)
    if "unit_price" in d:
        cols.append("unit_price"); vals.append(float(d["unit_price"]) if d["unit_price"] not in (None, "") else None)
    if cols:
        db.x(f"UPDATE orders SET {','.join(c + '=?' for c in cols)} WHERE id=?", (*vals, oid))
    return jsonify({"ok": True})


@app.get("/api/inventory/<int:iid>/history")
def inventory_history(iid):
    return jsonify(db.q("SELECT * FROM inventory_log WHERE inv_id=? ORDER BY ts DESC, id DESC LIMIT 100", (iid,)))


# ============================================================ prices
def items_payload(with_history=True):
    items = db.q("SELECT * FROM items ORDER BY name COLLATE NOCASE")
    srcs = db.q("SELECT * FROM sources ORDER BY id")
    hist = {}
    cutoff = (datetime.now() - timedelta(days=180)).strftime("%Y-%m-%dT%H:%M:%S")
    stock = {}
    for h in db.q("SELECT source_id, ts, price, in_stock FROM price_history WHERE ts>=? ORDER BY ts", (cutoff,)):
        hist.setdefault(h["source_id"], []).append([h["ts"], h["price"]])
        if h["in_stock"] is not None:
            stock.setdefault(h["source_id"], []).append((h["ts"], h["in_stock"]))
    cfg = db.get_settings()
    week_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S")
    for it in items:
        it["sources"] = [s for s in srcs if s["item_id"] == it["id"]]
        best = None
        for s in it["sources"]:
            h = hist.get(s["id"], [])
            s["history"] = h if with_history else []
            s["stock_since"] = stock_since(stock.get(s["id"], []))
            s["status"], s["status_msg"] = source_status(s, cfg)
            old = [p for ts, p in h if ts <= week_ago]
            s["price_7d_ago"] = old[-1] if old else (h[0][1] if h else None)
            s["low"] = min((p for _, p in h), default=None)
            s["high"] = max((p for _, p in h), default=None)
            avail = s["last_price"] is not None and s["in_stock"] != 0
            if avail and (best is None or s["last_price"] < best["last_price"]):
                best = s
        it["best"] = ({"source_id": best["id"], "site": best["site"], "price": best["last_price"],
                       "currency": best["currency"], "price_7d_ago": best["price_7d_ago"],
                       "is_lowest": best["low"] is not None and best["last_price"] <= best["low"]} if best else None)
        it["at_target"] = bool(best and it["target_price"] and best["last_price"] <= it["target_price"])
        it["trend"] = price_trend(hist.get(best["id"], []), best["last_price"], best["price_7d_ago"]) if best else None
        it["attention"] = [{"source_id": s["id"], "site": s["site"], "status": s["status"], "msg": s["status_msg"]}
                           for s in it["sources"] if s["status"] != "ok"]
    return items


def stock_since(points):
    """Timestamp the current in/out-of-stock state began, if we saw it change (None when it has always been the same)."""
    if len(points) < 2:
        return None
    cur, since = points[-1][1], None
    for ts, v in reversed(points):
        if bool(v) != bool(cur):
            break
        since = ts
    return since if since != points[0][0] else None


def source_status(s, cfg):
    """ok | signin | noprice | error | stale — drives the Needs-attention list and the dot on each store."""
    err = s["last_error"]
    if err:
        low = err.lower()
        if "sign-in" in low or "sign in" in low or "log in" in low or "login" in low:
            return "signin", "Needs you to sign in again"
        if "find a price" in low or "selector" in low or "robot check" in low or "unavailable" in low:
            return "noprice", "Can't find the price on the page"
        return "error", err
    if not s["last_checked"]:
        return "stale", "Not checked yet"
    age_h = (datetime.now() - datetime.fromisoformat(s["last_checked"])).total_seconds() / 3600
    limit = max(48, float(cfg["check_hours"]) * 3) if cfg["auto_check"] else 24 * 14
    if age_h > limit:
        return "stale", f"Last checked {int(age_h // 24)} days ago"
    return "ok", ""


def price_trend(h, now, old7):
    """Badges data for the price shown: change this week, and 30-day low / high (needs a few days of history to mean anything)."""
    if now is None:
        return None
    pct = round((now - old7) / old7 * 100, 1) if old7 else None
    t30 = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%S")
    win = [(ts, p) for ts, p in h if ts >= t30]
    span = (datetime.fromisoformat(win[-1][0]) - datetime.fromisoformat(win[0][0])).days if len(win) > 1 else 0
    prices = [p for _, p in win]
    ok = len(win) >= 3 and span >= 5
    return {"pct_week": pct, "days": span,
            "low30": bool(ok and now <= min(prices) + 0.005 and max(prices) > now + 0.005),
            "high30": bool(ok and now >= max(prices) - 0.005 and min(prices) < now - 0.005)}


def price_highlights():
    its = items_payload(with_history=False)
    hits = []
    for it in its:
        b = it["best"]
        if not b:
            continue
        drop = (b["price_7d_ago"] - b["price"]) if b["price_7d_ago"] else 0
        if it["at_target"] or drop > 0.005:
            hits.append({"id": it["id"], "name": it["name"], "image": it["image"], "price": b["price"],
                         "currency": b["currency"], "site": b["site"], "at_target": it["at_target"],
                         "target": it["target_price"], "drop": round(drop, 2), "is_lowest": b["is_lowest"]})
    hits.sort(key=lambda h: (not h["at_target"], -h["drop"]))
    return {"count": len(its), "highlights": hits[:6],
            "errors": sum(1 for i in its for s in i["sources"] if s["status"] != "ok"),
            "stock": stock_alerts(5)}


def stock_alerts(limit=50, days=30):
    cut = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S")
    return db.q("""SELECT e.id, e.kind, e.ts, e.price, e.item_id, i.name, s.site, s.url, s.currency FROM stock_events e
                   JOIN sources s ON s.id=e.source_id JOIN items i ON i.id=e.item_id
                   WHERE e.seen=0 AND e.ts>=? ORDER BY e.ts DESC LIMIT ?""", (cut, limit))


@app.get("/api/stock-events")
def stock_events_get():
    return jsonify(stock_alerts())


@app.post("/api/stock-events/seen")
def stock_events_seen():
    ids = (request.json or {}).get("ids")
    if ids:
        db.x(f"UPDATE stock_events SET seen=1 WHERE id IN ({','.join('?' * len(ids))})", tuple(int(i) for i in ids))
    else:
        db.x("UPDATE stock_events SET seen=1")
    return jsonify({"ok": True})


@app.get("/api/items")
def items_get():
    return jsonify(items_payload())


@app.post("/api/items")
def item_add():
    d = request.json
    url = (d.get("url") or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        return err("Paste a full link starting with http:// or https://")
    tp = d.get("target_price")
    iid = db.x("INSERT INTO items(name,category,target_price,notes) VALUES (?,?,?,?)",
               (d.get("name") or scraper.site_of(url), d.get("category"), float(tp) if tp not in (None, "") else None, d.get("notes")))
    sid = db.x("INSERT INTO sources(item_id,url,site,selector,needs_login) VALUES (?,?,?,?,?)",
               (iid, url, scraper.site_of(url), d.get("selector") or None, 1 if d.get("needs_login") else 0))
    res = scraper.check_source(sid) or {}
    upd = {}
    if res.get("image"):
        upd["image"] = res["image"]
    if not d.get("name") and res.get("name"):
        upd["name"] = res["name"][:140]
    if upd:
        db.x(f"UPDATE items SET {','.join(k + '=?' for k in upd)} WHERE id=?", (*upd.values(), iid))
    return jsonify({"id": iid, "source_id": sid, "check": res})


@app.put("/api/items/<int:iid>")
def item_update(iid):
    d = request.json
    cols = [k for k in ("name", "category", "target_price", "notes", "image") if k in d]
    vals = [(d[k] if d[k] != "" else None) for k in cols]
    if cols:
        db.x(f"UPDATE items SET {','.join(c + '=?' for c in cols)} WHERE id=?", (*vals, iid))
    return jsonify({"ok": True})


@app.delete("/api/items/<int:iid>")
def item_delete(iid):
    db.x("DELETE FROM items WHERE id=?", (iid,))
    return jsonify({"ok": True})


@app.post("/api/items/<int:iid>/sources")
def source_add(iid):
    d = request.json
    url = (d.get("url") or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        return err("Paste a full link starting with http:// or https://")
    sid = db.x("INSERT INTO sources(item_id,url,site,selector,needs_login) VALUES (?,?,?,?,?)",
               (iid, url, scraper.site_of(url), d.get("selector") or None, 1 if d.get("needs_login") else 0))
    return jsonify({"source_id": sid, "check": scraper.check_source(sid)})


@app.put("/api/sources/<int:sid>")
def source_update(sid):
    d = request.json
    cols = [k for k in ("url", "selector", "needs_login") if k in d]
    vals = [(d[k] if d[k] != "" else None) for k in cols]
    vals = [int(bool(v)) if c == "needs_login" else v for c, v in zip(cols, vals)]
    if cols:
        db.x(f"UPDATE sources SET {','.join(c + '=?' for c in cols)} WHERE id=?", (*vals, sid))
    return jsonify({"ok": True})


@app.delete("/api/sources/<int:sid>")
def source_delete(sid):
    db.x("DELETE FROM sources WHERE id=?", (sid,))
    return jsonify({"ok": True})


@app.post("/api/sources/<int:sid>/check")
def source_check(sid):
    return jsonify(scraper.check_source(sid))


@app.post("/api/check-all")
def check_all():
    threading.Thread(target=scraper.check_all, daemon=True).start()
    return jsonify({"started": True})


@app.post("/api/sources/<int:sid>/login")
def source_login(sid):
    if not scraper.pw_available():
        return err("Sign-in mode isn't installed yet. Open Settings and press 'Install sign-in mode'.")
    s = db.q("SELECT url FROM sources WHERE id=?", (sid,), one=True)
    if not s:
        return err("Not found", 404)
    if scraper.login_window_busy():
        return err("A sign-in window is already open. Look for it in your taskbar.", 409)

    def run():
        try:
            scraper.open_login_window(s["url"])
            r = scraper.check_source(sid) or {}                # check straight away so you can see whether the sign-in worked
            scraper.login_state["result"] = {"ok": bool(r.get("ok")), "price": r.get("price"), "currency": r.get("currency"),
                                             "error": r.get("error")}
        except Exception as e:  # noqa: BLE001
            print("login window error:", e)
    scraper.login_state.update(state="starting", error="", result=None, mode="login")
    threading.Thread(target=run, daemon=True).start()
    for _ in range(50):                            # wait a few seconds so a launch failure is reported instead of silently logged
        time.sleep(0.2)
        if scraper.login_state["state"] != "starting":
            break
    if scraper.login_state["state"] == "error":
        return err("Couldn't open the browser: " + scraper.login_state["error"])
    return jsonify({"started": True})


@app.post("/api/sources/<int:sid>/candidates")
def source_candidates(sid):
    s = db.q("SELECT * FROM sources WHERE id=?", (sid,), one=True)
    if not s:
        return err("Not found", 404)
    try:
        html, via = scraper.fetch_html(s["url"], bool(s["needs_login"]), force_browser=bool(s["needs_login"]) or None)
    except Exception as e:  # noqa: BLE001
        return err("Couldn't load the page: " + (str(e).splitlines() or ["error"])[0][:200])
    cands, cur = scraper.find_candidates(html, s["selector"])
    return jsonify({"candidates": cands, "current": cur, "selector": s["selector"], "signed_out": scraper.looks_like_login(html) and cur is None})


def _site_same(a, b):
    return scraper.site_of(a) == scraper.site_of(b)


def _finish_pick(sid, r):
    """After the person clicked a price: save it, then re-read the page *fresh* (not through their click) to prove it works."""
    s = db.q("SELECT * FROM sources WHERE id=?", (sid,), one=True)
    prev = {"selector": s["selector"], "needs_login": s["needs_login"], "url": s["url"]}
    want = r["price"]
    db.x("UPDATE sources SET selector=?, last_error=NULL WHERE id=?", (r["selector"], sid))
    new_url = r.get("url")
    tries = []
    if new_url and new_url != s["url"] and _site_same(new_url, s["url"]):     # the size/option you chose may live in the address
        tries.append(new_url)
    tries.append(s["url"])
    res, used_browser = None, bool(s["needs_login"])
    for u in tries:
        db.x("UPDATE sources SET url=? WHERE id=?", (u, sid))
        if not s["needs_login"]:                      # does a plain request already see this price? if not the page needs the browser
            try:
                got = scraper.extract(scraper.requests.get(u, headers=scraper.HEADERS, timeout=20).text, r["selector"])["price"]
            except Exception:
                got = None
            used_browser = not (got is not None and abs(got - want) < 0.005)
            db.x("UPDATE sources SET needs_login=? WHERE id=?", (1 if used_browser else 0, sid))
        res = scraper.check_source(sid) or {}
        if res.get("ok") and abs(res["price"] - want) < 0.005:
            break
    ok = bool(res and res.get("ok") and abs(res["price"] - want) < 0.005)
    out = {"mode": "pick", "ok": ok, "picked": want, "price": res.get("price") if res else None, "currency": res.get("currency") if res else None,
           "url_updated": ok and db.q("SELECT url FROM sources WHERE id=?", (sid,), one=True)["url"] != prev["url"], "browser": used_browser}
    if not ok:                                         # put things back the way they were so a bad pick never breaks a working store
        db.x("UPDATE sources SET selector=?, needs_login=?, url=? WHERE id=?", (prev["selector"], prev["needs_login"], prev["url"], sid))
        out["error"] = (f"You picked {want:g}, but opening the page fresh reads {res['price']:g}. The price probably depends on an option you chose "
                        "(size, quantity) or on being signed in. Nothing was changed.") if res and res.get("ok") else \
                       ("The price you picked couldn't be read again on a fresh visit" + (": " + res["error"] if res and res.get("error") else "") + ". Nothing was changed.")
    return out


@app.post("/api/sources/<int:sid>/pick")
def source_pick(sid):
    if not scraper.pw_available():
        return err("Sign-in mode isn't installed yet. Open Settings and press 'Install sign-in mode'.")
    s = db.q("SELECT url FROM sources WHERE id=?", (sid,), one=True)
    if not s:
        return err("Not found", 404)
    if scraper.login_window_busy():
        return err("A browser window is already open. Look for it in your taskbar.", 409)

    def run():
        try:
            r = scraper.open_pick_window(s["url"])
            if r.get("cancelled"):
                scraper.login_state["result"] = {"mode": "pick", "ok": False, "cancelled": True}
            elif r.get("error"):
                scraper.login_state["result"] = {"mode": "pick", "ok": False, "error": r["error"]}
            else:
                scraper.login_state["result"] = _finish_pick(sid, r)
        except Exception as e:  # noqa: BLE001
            print("pick window error:", e)
    scraper.login_state.update(state="starting", error="", result=None, mode="pick")
    threading.Thread(target=run, daemon=True).start()
    for _ in range(50):
        time.sleep(0.2)
        if scraper.login_state["state"] != "starting":
            break
    if scraper.login_state["state"] == "error":
        return err("Couldn't open the browser: " + scraper.login_state["error"])
    return jsonify({"started": True})


# ---- bulk add / CSV import: items are created straight away, prices are fetched in the background
BULK = {}


def _norm_url(u):
    return (u or "").strip().lower().rstrip("/")


def _bulk_worker(job, todo):
    for t in todo:
        res = {}
        try:
            res = scraper.check_source(t["sid"]) or {}
            upd = {}
            if res.get("image"):
                upd["image"] = res["image"]
            if t["auto_name"] and res.get("name"):
                upd["name"] = res["name"][:140]
            if upd and t["new_item"]:
                db.x(f"UPDATE items SET {','.join(k + '=?' for k in upd)} WHERE id=?", (*upd.values(), t["iid"]))
        except Exception as e:  # noqa: BLE001
            res = {"ok": False, "error": str(e)[:150]}
        BULK[job]["done"] += 1
        BULK[job]["results"].append({"name": t["label"], "ok": bool(res.get("ok")), "price": res.get("price"), "error": res.get("error")})
        time.sleep(0.6)
    BULK[job]["finished"] = True


@app.post("/api/items/bulk")
def items_bulk():
    rows = (request.json or {}).get("rows") or []
    if not rows:
        return err("Nothing to add")
    if len(rows) > 300:
        return err("That's a lot at once. Please import up to 300 links per batch.")
    have_urls = {_norm_url(r["url"]) for r in db.q("SELECT url FROM sources")}
    by_name = {r["name"].strip().lower(): r["id"] for r in db.q("SELECT id,name FROM items")}
    todo, skipped = [], []
    for r in rows:
        url = (r.get("url") or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            skipped.append({"row": r.get("name") or url or "(blank)", "why": "not a full link (http:// or https://)"})
            continue
        if _norm_url(url) in have_urls:
            skipped.append({"row": r.get("name") or url, "why": "already tracked"})
            continue
        have_urls.add(_norm_url(url))
        name = (r.get("name") or "").strip()
        new_item = not (name and name.lower() in by_name)
        if new_item:
            tp = r.get("target_price")
            try:
                tp = float(str(tp).replace("$", "").strip()) if tp not in (None, "") else None
            except ValueError:
                tp = None
            iid = db.x("INSERT INTO items(name,category,target_price,notes) VALUES (?,?,?,?)",
                       (name or scraper.site_of(url), (r.get("category") or "").strip() or None, tp, None))
            if name:
                by_name[name.lower()] = iid
        else:
            iid = by_name[name.lower()]
        sid = db.x("INSERT INTO sources(item_id,url,site,selector,needs_login) VALUES (?,?,?,?,?)",
                   (iid, url, scraper.site_of(url), None, 1 if str(r.get("needs_login", "")).strip().lower() in ("1", "true", "yes", "y", "x") else 0))
        todo.append({"iid": iid, "sid": sid, "auto_name": not name, "new_item": new_item, "label": name or scraper.site_of(url)})
    job = str(int(time.time() * 1000))
    BULK[job] = {"total": len(todo), "done": 0, "results": [], "finished": not todo, "skipped": skipped}
    if todo:
        threading.Thread(target=_bulk_worker, args=(job, todo), daemon=True).start()
    return jsonify({"job": job, **BULK[job]})


@app.get("/api/items/bulk/<job>")
def items_bulk_status(job):
    return jsonify(BULK.get(job) or {"finished": True, "total": 0, "done": 0, "results": [], "skipped": []})


@app.get("/api/login-window/status")
def login_window_status():
    return jsonify(scraper.login_state)


@app.post("/api/login-window/close")
def login_window_close():
    scraper.close_login_window()
    return jsonify({"ok": True})


# ============================================================ settings / backup
@app.get("/api/settings")
def settings_get():
    s = db.get_settings()
    return jsonify({**s, "playwright": scraper.pw_available(), "data_dir": str(db.DATA_DIR), "browser": browsers.describe(s["browser_pref"])})


# optional sign-in mode (Playwright + Chromium) is installed on demand, not up front
INSTALL = {"state": "idle", "log": ""}


def _install_browser():
    INSTALL.update(state="running", log="")
    try:
        cmds = [[sys.executable, "-m", "pip", "install", "--quiet", "playwright"]]
        if not browsers.choose(db.get_settings()["browser_pref"]):           # no Chrome/Edge found: fetch Chromium (~150 MB)
            cmds.append([sys.executable, "-m", "playwright", "install", "chromium"])
        for cmd in cmds:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=1200)
            INSTALL["log"] = ((p.stdout or "") + (p.stderr or ""))[-400:]
            if p.returncode:
                raise RuntimeError("Install failed. Check your internet connection and try again.")
        importlib.invalidate_caches()
        if not scraper.pw_available(refresh=True):
            raise RuntimeError("Installed, but the browser couldn't be found. Restart the app and try again.")
        INSTALL.update(state="done", log="")
    except Exception as e:  # noqa: BLE001
        INSTALL["state"] = "error"
        INSTALL["log"] = str(e)[:300]


@app.get("/api/install-browser")
def install_status():
    return jsonify({**INSTALL, "ready": scraper.pw_available(), "browser": browsers.describe(db.get_settings()["browser_pref"])})


@app.post("/api/install-browser")
def install_start():
    if INSTALL["state"] != "running" and not scraper.pw_available():
        threading.Thread(target=_install_browser, daemon=True).start()
        INSTALL["state"] = "running"
    return jsonify({**INSTALL, "ready": scraper.pw_available()})


@app.put("/api/settings")
def settings_put():
    db.set_settings(request.json)
    if "browser_pref" in request.json:
        scraper.pw_available(refresh=True)
    return jsonify({"ok": True})


def _startup_lnk():
    return Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / "WulfProtocol.lnk"


@app.get("/api/autostart")
def autostart_get():
    return jsonify({"supported": os.name == "nt", "enabled": os.name == "nt" and _startup_lnk().exists()})


@app.post("/api/autostart")
def autostart_set():
    if os.name != "nt":
        return err("Start-with-Windows is only available on Windows.")
    lnk = _startup_lnk()
    if request.json.get("enabled"):
        here = Path(__file__).resolve().parent
        pyw = Path(sys.executable).with_name("pythonw.exe")
        if not pyw.exists():
            pyw = Path(sys.executable)
        q = lambda p: str(p).replace("'", "''")
        ps = (f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{q(lnk)}'); $s.TargetPath='{q(pyw)}'; "
              f"$s.Arguments='launcher.py --background'; $s.WorkingDirectory='{q(here)}'; "
              f"$s.IconLocation='{q(here / 'assets' / 'wulf.ico')}'; $s.WindowStyle=7; $s.Save()")
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                           capture_output=True, text=True, creationflags=0x08000000)
        if r.returncode:
            return err("Couldn't set that up: " + (r.stderr or "")[:200])
    else:
        lnk.unlink(missing_ok=True)
    return jsonify({"ok": True, "enabled": lnk.exists()})


@app.get("/api/log")
def log_tail():
    p = db.DATA_DIR / "app.log"
    text = "\n".join(p.read_text(encoding="utf-8", errors="replace").splitlines()[-200:]) if p.exists() else ""
    return jsonify({"log": text or "(the log is empty - nothing has gone wrong)"})


@app.get("/api/ping")
def ping():
    return jsonify({"app": "wulfprotocol"})


# ============================================================ updates (from a zip you were sent)
APP_DIR = Path(__file__).resolve().parent
UPDATE_OK = {".py", ".js", ".css", ".html", ".json", ".md", ".png", ".ico", ".cur", ".svg", ".webmanifest", ".bat", ".sh", ".command", ".txt", ".woff", ".woff2", ".jpg", ".jpeg", ".gif", ".map"}


def app_version():
    try:
        return int((APP_DIR / "VERSION").read_text().strip())
    except Exception:
        return 0


@app.get("/api/version")
def version():
    return jsonify({"version": app_version(), "release": release_info()})


def _install_zip(data):
    """Install a newer copy of the app from zip bytes. Only program files are replaced: never your data folder."""
    import io, shutil, zipfile
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except Exception:
        raise ValueError("That doesn't look like a zip file")
    orig = {n.replace("\\", "/"): n for n in z.namelist() if not n.endswith("/")}      # zips made on Windows may use backslashes
    names = list(orig)
    roots = sorted((n for n in names if n.split("/")[-1] == "app.py" and n.count("/") <= 3), key=len)
    if not roots:
        raise ValueError("That zip isn't a WulfProtocol update (no app.py in it)")
    prefix = roots[0][:-len("app.py")]
    try:
        new_v = int(z.read(orig[prefix + "VERSION"]).decode().strip())
    except Exception:
        raise ValueError("That zip has no version number, so I can't tell if it's newer")
    cur = app_version()
    if new_v <= cur:
        raise ValueError("That update isn't newer than the version you already have, so nothing was changed.")
    backup = None
    if db.DB_PATH.exists():                                  # safety copy of your data first
        backup = db.DATA_DIR / f"backup-before-update-v{new_v}.db"
        try:
            shutil.copy2(db.DB_PATH, backup)
        except Exception:
            backup = None
    written = 0
    for n in names:
        if not n.startswith(prefix):
            continue
        rel = n[len(prefix):]
        parts = Path(rel).parts
        if not parts or ".." in parts or Path(rel).is_absolute() or parts[0] in ("data", ".venv", "__pycache__") or Path(rel).suffix.lower() not in UPDATE_OK and Path(rel).name != "VERSION":
            continue
        dest = (APP_DIR / rel).resolve()
        if APP_DIR not in dest.parents:
            continue
        blob = z.read(orig[n])
        if Path(rel).name == "update_source.txt" and not blob.strip():      # a blank address never erases a working one
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".new")
        tmp.write_bytes(blob)
        os.replace(tmp, dest)
        written += 1
    return {"ok": True, "version": new_v, "was": cur, "files": written, "backup": backup.name if backup else None, "release": release_info()}


@app.post("/api/update")
def apply_update():
    if request.headers.get("X-WulfProtocol") != "1":
        return err("Not allowed", 403)
    f = request.files.get("file")
    if not f:
        return err("Choose the update zip first")
    try:
        return jsonify(_install_zip(f.read()))
    except ValueError as e:
        return err(str(e))


# ---- "Check for updates": reads a small update.json (and the zip) from the address in update_source.txt
_upd_cache = {"t": 0.0, "data": None}


def _update_base():
    try:
        t = (APP_DIR / "update_source.txt").read_text(encoding="utf-8").strip()
    except Exception:
        t = ""
    return (t if t.endswith("/") else t + "/") if t.startswith(("https://", "http://127.0.0.1")) else ""


def _fetch(url, limit):
    req = urllib.request.Request(url, headers={"User-Agent": "WulfProtocol-updater"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("The update file is bigger than expected")
    return data


@app.get("/api/update/check")
def update_check():
    cur = app_version()
    base = _update_base()
    if not base:
        return jsonify({"configured": False, "current": cur, "current_release": release_info()})
    if request.args.get("force") != "1" and _upd_cache["data"] and time.time() - _upd_cache["t"] < 6 * 3600:
        return jsonify({**_upd_cache["data"], "current": cur, "current_release": release_info(), "newer": _upd_cache["data"].get("latest", 0) > cur})
    try:
        info = json.loads(_fetch(base + "update.json", 200_000))
        latest = int(info["version"])
    except Exception:
        return jsonify({"configured": True, "current": cur, "current_release": release_info(), "error": "Couldn't reach the update page. Check your internet connection and try again."})
    rel = info.get("release") if isinstance(info.get("release"), dict) else {}
    out = {"configured": True, "latest": latest, "notes": str(info.get("notes") or "")[:600],
           "release": {k: str(rel.get(k, ""))[:40] for k in ("codename", "status", "version")}}
    _upd_cache.update(t=time.time(), data=out)
    return jsonify({**out, "current": cur, "current_release": release_info(), "newer": latest > cur})


@app.post("/api/update/install")
def update_install():
    import hashlib
    if request.headers.get("X-WulfProtocol") != "1":
        return err("Not allowed", 403)
    base = _update_base()
    if not base:
        return err("Updates aren't set up on this copy")
    try:
        info = json.loads(_fetch(base + "update.json", 200_000))
        zname = str(info.get("zip") or "WulfProtocol-update.zip")
        if not re.fullmatch(r"[A-Za-z0-9._-]+\.zip", zname):
            return err("The update page listed an unexpected file name, so nothing was installed.")
        data = _fetch(base + zname, 80_000_000)         # versioned name: a slow-to-refresh update.json can never point at the wrong zip
        want = str(info.get("sha256") or "").lower()
        if want and hashlib.sha256(data).hexdigest() != want:
            return err("The downloaded update didn't match its checksum, so it was not installed. Try again in a minute.")
        res = _install_zip(data)
    except ValueError as e:
        return err(str(e))
    except Exception:
        return err("Couldn't download the update. Check your internet connection and try again.")
    _upd_cache["data"] = None
    return jsonify(res)


@app.post("/api/shutdown")
def shutdown():
    if request.headers.get("X-WulfProtocol") != "1":      # a custom header can't be sent by other websites
        return err("Not allowed", 403)
    threading.Timer(0.6, lambda: os._exit(0)).start()
    return jsonify({"ok": True})


@app.get("/api/export")
def export():
    tables = ["meds", "dose_logs", "profile", "metrics", "items", "sources", "price_history", "settings", "biomarkers", "lab_results", "events", "inventory", "inventory_log", "orders", "med_supplies", "library"]
    resp = jsonify({t: db.q(f"SELECT * FROM {t}") for t in tables})
    resp.headers["Content-Disposition"] = f"attachment; filename=tracker-backup-{date.today()}.json"
    return resp


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8765))
    url = f"http://127.0.0.1:{port}"
    try:                                           # is something already listening on our port?
        socket.create_connection(("127.0.0.1", port), timeout=1).close()
        try:
            ours = json.load(urllib.request.urlopen(url + "/api/ping", timeout=2)).get("app") == "wulfprotocol"
        except Exception:
            ours = False
        if ours:
            print("\n  WulfProtocol is already running - opening it in your browser.\n")
            if os.environ.get("NO_BROWSER") != "1":
                webbrowser.open(url)
            sys.exit(0)
        print(f"\n  Port {port} is being used by another program. Close it, or run with a different PORT.\n")
        sys.exit(1)
    except OSError:
        pass                                       # nothing there - go ahead and start
    scraper.start_scheduler()
    if os.environ.get("NO_BROWSER") != "1":
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    print(f"\n  Tracker running at http://127.0.0.1:{port}  (Ctrl+C to stop)\n  Data: {db.DATA_DIR}\n")
    app.run(host="127.0.0.1", port=port, debug=False, threaded=True)
