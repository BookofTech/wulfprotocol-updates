/* Quick add: a saved list of reference sheets. Pick one and the Add form opens pre-filled,
   with the reference info attached so it shows on the medication's page. */
const LIB_FIELDS = [["indications", "Indications"], ["reconstitute", "Reconstitute with"], ["storage", "Storage"], ["dosage", "Dosage"],
  ["onset", "Onset"], ["half_life", "Half-life"], ["side_effects", "Side effects"], ["notes", "Notes"]];

function refFromItem(it) {
  const r = { name: it.name, group: (it.groups || []).join(", "), names: it.names || "" };
  LIB_FIELDS.forEach(([k]) => (r[k] = it[k] || ""));
  return r;
}
/* ---- heads-up lines: anything the sheet wrote as ***LIKE THIS*** */
const fixFlags = t => String(t || "").replace(/\*\*\*([^*]+?)\*\*\*(?=[A-Z ]{4,}\*\*\*)/g, "***$1*** ***");
function refFlags(m) {
  const r = m && m.reference_obj; if (!r) return [];
  const out = [];
  [r.notes, r.storage, r.dosage, r.reconstitute, r.indications].forEach(t => {
    (fixFlags(t).match(/\*\*\*([^*]+?)\*\*\*/g) || []).forEach(x => { const v = x.replace(/\*/g, "").trim(); if (v && !out.includes(v)) out.push(v); });
  });
  return out;
}
const flagHtml = (m, small) => refFlags(m).map(f => `<div class="alert flag" ${small ? 'style="padding:6px 10px;font-size:.8rem;margin-top:8px"' : ""}>⚠️ ${esc(f)}</div>`).join("");
const noFlags = t => fixFlags(t).replace(/\*\*\*[^*]+?\*\*\*/g, "").replace(/\n{2,}/g, "\n").trim();

function refCard(m) {
  const r = m.reference_obj; if (!r) return "";
  const rows = [["names", "Also known as"], ...LIB_FIELDS].map(([k, l]) => [k, l, noFlags(r[k])]).filter(([k, l, v]) => v && !/^n\/?a$/i.test(v));
  return `<div class="card"><h2>Reference ${r.group ? `<span class="badge">${esc(r.group)}</span>` : ""}</h2>
    ${refFlags(m).map(f => `<div class="alert flag" style="margin-bottom:8px">⚠️ ${esc(f)}</div>`).join("")}
    <dl class="kv ref">${rows.map(([k, l, v]) => `<dt>${l}</dt><dd style="white-space:pre-line">${esc(v)}</dd>`).join("")}</dl>
    <p class="small muted" style="margin:8px 0 0">From your saved reference list. It's information you entered, not advice.</p></div>`;
}

/* ---- side effects from the sheet -> tap-to-note chips */
function effectList(m) {
  const r = m && m.reference_obj; if (!r) return [];
  const out = [];
  String(r.side_effects || "").split(/[\n,;]+/).forEach(x => {
    let v = x.replace(/^[\s\-•*]+|[\s.]+$/g, "").trim();
    if (!v || v.length > 32 || /^(none|n\/?a|possible|may|can|decreases|increases|very)\b/i.test(v) || /^and /i.test(v)) return;
    v = v.charAt(0).toUpperCase() + v.slice(1);
    if (!out.some(o => o.toLowerCase() === v.toLowerCase())) out.push(v);
  });
  return out.slice(0, 14);
}

/* ---- dose steps by week ("2.5mg weeks 1-4 / 5mg weeks 5-8 ...") */
const freqPresets = base => {
  const baseDay = base && base.type === "weekdays" && (base.days || []).length === 1 ? base.days : [0];
  return [["keep", "Keep my schedule", null], ["daily", "Every day", { type: "daily" }], ["twice", "Twice a day", { type: "daily", times: ["08:00", "20:00"] }],
    ["thrice", "Three times a day", { type: "daily", times: ["08:00", "14:00", "20:00"] }], ["eod", "Every other day", { type: "interval", every: 2 }],
    ["w1", "Once a week", { type: "weekdays", days: baseDay }], ["w2", "Twice a week", { type: "weekdays", days: [0, 3] }],
    ["w3", "3 days a week", { type: "weekdays", days: [0, 2, 4] }], ["w4", "4 days a week", { type: "weekdays", days: [0, 1, 3, 4] }],
    ["w5", "5 days a week (Mon–Fri)", { type: "weekdays", days: [0, 1, 2, 3, 4] }]];
};
function lineFreq(line) {
  const t = line.toLowerCase(); let k;
  if (/three times (a |per )?day|3\s*x\s*(a |per )?(day|daily)|\btid\b/.test(t) && !/week/.test(t)) return "thrice";
  if (/twice (a |per )?(day|daily)|2\s*x\s*(a |per )?(day|daily)|\bbid\b/.test(t)) return "twice";
  if (/every other day|\beod\b/.test(t)) return "eod";
  if (/twice (a |per )?week|twice weekly/.test(t)) return "w2";
  if (/(three|3) times (a |per )?week/.test(t)) return "w3";
  if ((k = t.match(/(\d)\s*(?:x|times)\s*(?:per|a|\/)?\s*(?:week|wk)/)) && +k[1] >= 1 && +k[1] <= 5) return "w" + k[1];
  if (/once (a |per )?week|weekly|once per week/.test(t)) return "w1";
  if (/once (a |per )?day|\bdaily\b|every day/.test(t)) return "daily";
  return "keep";
}
function parsePhases(text, unit) {
  const steps = [];
  String(text || "").split("\n").forEach(line => {
    if (/\bdays?\s*#?\d/i.test(line) && !/week/i.test(line)) return;                 // "days 1-4" style steps are not weekly
    if (/\+\s*\d/.test(line)) return;                                    // combined with another drug
    const wk = line.match(/(?:weeks?|wks?)\s*#?\s*(\d+)(?:\s*[-–]\s*(\d+|\+))?/i) || line.match(/for\s*#\s*(\d+)\s*[-–]\s*(\d+)/i);
    if (!wk) return;
    const d = line.match(/(\d+(?:\.\d+)?)\s*(mcg|µg|ug|mg|iu|ml|units?)\b/i);
    if (!d) return;
    let n = parseFloat(d[1]), u = UNIT_MAP[d[2].toLowerCase()];
    if (unit && u !== unit) {
      if (u === "mg" && unit === "mcg") n *= 1000; else if (u === "mcg" && unit === "mg") n /= 1000; else return;
    }
    const openEnd = new RegExp(wk[0].replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\s*\\+").test(line);
    const to = wk[2] && /^\d+$/.test(wk[2]) ? +wk[2] : (!wk[2] && !openEnd ? +wk[1] : null);
    steps.push({ from_week: +wk[1], dose: +n.toFixed(4), freq: lineFreq(line), ...(to ? { to_week: to } : {}) });
  });
  steps.sort((a, b) => a.from_week - b.from_week);
  const uniq = steps.filter((x, i) => !i || x.from_week !== steps[i - 1].from_week);
  uniq.forEach((x, i) => { if (i < uniq.length - 1) delete x.to_week; });
  return uniq.length >= 2 ? uniq : [];
}

/* ---- every dose amount the sheet mentions, as tap-to-use choices ("10-20mg daily" -> 10 mg, 20 mg) */
function doseOptions(text, unit) {
  const out = [];
  String(text || "").split("\n").forEach(line => {
    if (/reconstitut|per\s*kg|\/\s*kg|diluent/i.test(line)) return;
    const re = /(\d+(?:\.\d+)?)(?:\s*[-–]\s*(\d+(?:\.\d+)?))?\s*(mcg|µg|ug|mg|iu|units?)\b/gi; let m;
    while ((m = re.exec(line))) {
      const u = UNIT_MAP[m[3].toLowerCase()];
      [m[1], m[2]].filter(Boolean).forEach(v => {
        let n = parseFloat(v);
        if (u !== unit) { if (u === "mg" && unit === "mcg") n *= 1000; else if (u === "mcg" && unit === "mg") n /= 1000; else return; }
        n = +n.toFixed(4); if (n > 0 && !out.includes(n)) out.push(n);
      });
    }
  });
  return out.sort((a, b) => a - b).slice(0, 7);
}

function stepsModal(m, after) {
  const ref = m.reference_obj, plan = m.plan;
  const found = !plan && ref ? parsePhases(ref.dosage, m.dose_unit) : [];
  const base = m.schedule_obj || { type: "daily" }, FR = freqPresets(base);
  const norm = x => JSON.stringify([x.type, x.every || null, (x.days || []).slice().sort(), x.times || null]);
  const keyOf = sc => { if (!sc) return "keep"; const f = FR.find(r => r[2] && norm(r[2]) === norm(sc)); return f ? f[0] : "custom"; };
  const start = (plan ? plan.steps.map(x => ({ ...x, freq: keyOf(x.schedule) })) : (found.length ? found : [{ from_week: 1, dose: m.dose || "", freq: "keep" }, { from_week: 5, dose: "", freq: "keep" }]));
  const row = (x) => `<div class="row wrap" style="gap:8px;margin-bottom:8px" data-st ${x.freq === "custom" ? `data-custom='${esc(JSON.stringify(x.schedule))}'` : ""}><span class="small muted">From week</span><input type="number" min="1" step="1" value="${x.from_week}" style="width:80px" data-w>
    <input type="number" step="any" min="0" value="${x.dose}" style="width:100px" data-d><span class="small muted">${esc(m.dose_unit)}</span>
    <select data-f style="width:auto">${FR.map(([k, l]) => `<option value="${k}" ${x.freq === k ? "selected" : ""}>${l}</option>`).join("")}${x.freq === "custom" ? `<option value="custom" selected>As you set it</option>` : ""}</select>
    <button type="button" class="btn ghost sm" data-rm title="Remove">✕</button></div>`;
  modal(`<h2>📈 Dose steps — ${esc(m.name)}</h2>
    ${found.length ? `<div class="alert info" style="margin-bottom:10px">Read from the reference sheet. Sheets word these differently, so please check each step before saving.</div>`
      : plan ? "" : `<p class="muted" style="margin-top:0">${ref ? "Couldn't find week-by-week steps in the sheet" : "No reference sheet attached"} — type them in below.</p>`}
    <p class="small muted" style="margin:0 0 8px">Each step starts in the week shown and lasts until the next one. The dose, and how often you take it, change by themselves as the weeks pass (and the units to draw or dial follow). "Keep my schedule" leaves how often alone.</p>
    <div id="steps">${start.map(row).join("")}</div>
    <button type="button" class="btn sm" id="addst">＋ Add a step</button>
    <div class="row wrap" style="gap:12px;margin-top:12px">
      <label class="f">Week 1 started on<input type="date" id="pst" value="${esc((plan && plan.start) || m.start_date)}"></label>
      <label class="f">Plan ends after week <span class="muted">(blank = keeps going)</span><input type="number" min="1" id="pend" value="${(start[start.length - 1] || {}).to_week || ""}" style="width:110px"></label></div>
    <div class="actions"><button type="button" class="btn" data-close>Cancel</button>${plan ? `<button type="button" class="btn danger" id="stoff">Stop using steps</button>` : ""}<button class="btn primary" id="stsave">Save steps</button></div>`, {
    onMount: (el, close) => {
      const wire = () => $$("[data-rm]", el).forEach(b => b.onclick = () => { if ($$("[data-st]", el).length > 1) b.closest("[data-st]").remove(); });
      wire();
      $("#addst", el).onclick = () => { const all = $$("[data-w]", el).map(i => +i.value || 0);
        $("#steps", el).insertAdjacentHTML("beforeend", row({ from_week: (Math.max(0, ...all) || 0) + 4, dose: "", freq: "keep" })); wire(); };
      const off = $("#stoff", el);
      if (off) off.onclick = async () => { await api(`/meds/${m.id}/phases`, "PUT", { steps: null }); close(); toast("Dose steps off"); after ? after() : Router.render(); };
      $("#stsave", el).onclick = async () => {
        const steps = $$("[data-st]", el).map(r => {
          const k = $("[data-f]", r).value, st = { from_week: +$("[data-w]", r).value, dose: +$("[data-d]", r).value };
          const sc = k === "custom" ? JSON.parse(r.dataset.custom) : (FR.find(f => f[0] === k) || [])[2];
          if (sc && norm(sc) !== norm({ ...base, times: base.times && sc.times ? base.times : null })) st.schedule = sc;      // same as your own schedule = nothing to store
          return st;
        });
        if (steps.some(x => !(x.from_week >= 1) || !(x.dose > 0))) return toast("Give every step a week (1 or more) and a dose", true);
        const end = +$("#pend", el).value || 0;
        if (end) { const top = steps.reduce((a, b) => (b.from_week > a.from_week ? b : a)); if (end < top.from_week) return toast("The end week must be after the last step starts", true); top.to_week = end; }
        await run($("#stsave", el), async () => { await api(`/meds/${m.id}/phases`, "PUT", { steps, start: $("#pst", el).value }); close(); toast("Dose steps saved"); after ? after() : Router.render(); });
      };
    },
  });
}

/* ---- best-guess dose / route / schedule from the free-text "Dosage" lines (always shown for you to confirm) */
const UNIT_MAP = { mcg: "mcg", ug: "mcg", "µg": "mcg", mg: "mg", g: "g", iu: "IU", ml: "mL", unit: "units", units: "units",
  tablet: "tablet", tablets: "tablet", cap: "capsule", caps: "capsule", capsule: "capsule", capsules: "capsule", spray: "sprays", sprays: "sprays", drop: "drops", drops: "drops" };
const WK = { 1: [0], 2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 4], 5: [0, 1, 2, 3, 4], 6: [0, 1, 2, 3, 4, 5] };
function guessFromItem(it) {
  const lines = (it.dosage || "").split("\n").map(x => x.trim()).filter(x => x && !/reconstitut/i.test(x));
  const first = (lines[0] || "").replace(/^[A-Za-z ]{3,20}:\s*/, "");      // drop labels like "Beginner:"
  const all = [(it.dosage || ""), it.notes || "", it.reconstitute || ""].join("\n");
  const out = { dose: "", dose_unit: null, route_type: null, schedule: { type: "daily", times: ["08:00"] }, hints: [] };
  const m = first.match(/(\d+(?:\.\d+)?)(?:\s*[-–]\s*\d+(?:\.\d+)?)?\s*(mcg|µg|ug|mg|g|iu|ml|units?|tablets?|capsules?|caps?|sprays?|drops?)\b/i);
  if (m) {
    let n = parseFloat(m[1]), u = UNIT_MAP[m[2].toLowerCase()];
    if (u === "g") { n *= 1000; u = "mg"; }
    out.dose = n; out.dose_unit = u;
  }
  const pickRoute = t => /sub-?\s?q|subcut|subq/i.test(t) ? "subq" : /\bIM\b|intramuscular/i.test(t) ? "im"
    : /intranasal|nasal|\bIN\b/.test(t) ? "nasal" : /sublingual/i.test(t) ? "sublingual" : /topical|transdermal/i.test(t) ? "topical"
    : /oral (liquid|solution)/i.test(t) ? "oral_liquid" : /oral|tablet|capsule|pill/i.test(t) ? "oral_tablet" : null;
  out.route_type = pickRoute(first) || pickRoute(lines.slice(1).join("\n")) || (/bac water/i.test(it.reconstitute || "") ? "subq" : null);
  if (!out.route_type) out.hints.push("the sheet doesn't say how it's taken, so check “How do you take it?”");
  if (!m) out.hints.push("no dose amount found");
  const f = first;
  let k;
  if (/as[- ]needed|\bprn\b/i.test(f)) out.schedule = { type: "prn", times: [] };
  else if (/(three|3)\s*(times|x)\s*(a |per )?(day|daily)|\btid\b/i.test(f) || /\b3x daily\b/i.test(f)) out.schedule.times = ["08:00", "14:00", "20:00"];
  else if (/twice\s*(a |per )?(day|daily)|2\s*x\s*(per |a )?(day|daily)|\bbid\b|2x daily/i.test(f)) out.schedule.times = ["08:00", "20:00"];
  else if ((k = f.match(/(\d)\s*(?:x|times)\s*(?:per|a|\/)?\s*(?:week|wk)/i)) && WK[+k[1]]) out.schedule = { type: "weekdays", days: WK[+k[1]], times: ["08:00"] };
  else if (/every other day|\beod\b/i.test(f)) out.schedule = { type: "interval", every: 2, times: ["08:00"] };
  else if ((k = f.match(/every (\d+) days/i))) out.schedule = { type: "interval", every: +k[1], times: ["08:00"] };
  else if (/weekly|once (a|per) week|per week/i.test(f) && !/daily/i.test(f)) out.schedule = { type: "weekdays", days: [0], times: ["08:00"] };
  else if (/(bed ?time|at night|nightly|before bed)/i.test(f)) out.schedule.times = ["21:00"];
  else if (!/daily|per day|every day|once a day/i.test(f)) out.hints.push("the sheet doesn't say how often, so check the schedule");
  return out;
}
function prefillFromItem(it) {
  const g = guessFromItem(it), groups = it.groups || [];
  const R = App.routes, rt = g.route_type || "other";
  const fields = { name: it.name, kind: groups.some(x => /Anabolic|PCT|Post-Cycle|Analgesic/.test(x)) ? "medication" : "peptide",
    route_type: rt, dose: g.dose, dose_unit: g.dose_unit || R[rt].unit, schedule_obj: g.schedule, container: "vial" };
  const txt = (it.notes || "") + "\n" + (it.reconstitute || "");
  let w;
  if ((w = txt.match(/adding\s*(\d+(?:\.\d+)?)\s*ml[^\n]*?to (?:a |each |the )?(\d+(?:\.\d+)?)\s*mg/i))) { fields.diluent_ml = +w[1]; fields.vial_amount = +w[2]; fields.vial_unit = "mg"; }
  else if ((w = txt.match(/(\d+(?:\.\d+)?)\s*ml\s*\/\s*(\d+(?:\.\d+)?)\s*mg/i))) { fields.diluent_ml = +w[1]; fields.vial_amount = +w[2]; fields.vial_unit = "mg"; }
  if ((w = (it.notes || "").match(/cycle[^\n]*?(\d+)\s*weeks?\s*on[^\d\n]*(\d+)\s*weeks?\s*off/i))) { fields.cycle_on = +w[1] * 7; fields.cycle_off = +w[2] * 7; }
  const first = (it.dosage || "").split("\n").map(x => x.trim()).filter(x => x && !/reconstitut/i.test(x))[0];
  const hint = (first ? `From your sheet: “${first}”. Other lines are in the Reference card after you save.` : "") + (g.hints.length ? ` Check: ${g.hints.join("; ")}.` : "");
  return { fields, reference: it, openMore: true, hint };
}

/* ---- the picker */
async function quickAddModal() {
  let items = (await api("/library")).filter(i => !((i.groups || []).length && (i.groups || []).every(g => g === "Diluents & Additives"))), q = "", grp = "";
  const groups = [...new Set(items.flatMap(i => i.groups || []))].sort();
  modal(`<h2>⚡ Quick add</h2>
    <p class="muted" style="margin-top:0">Pick one from your saved list. The Add form opens pre-filled and you choose vial or pen and your supplies.</p>
    <div class="row" style="gap:8px"><input id="qs" class="grow" placeholder="Search…" autocomplete="off"><button class="btn sm" id="qnew">+ New item</button></div>
    <div class="row wrap" id="qg" style="gap:6px;margin:10px 0"></div>
    <div id="ql" class="list" style="max-height:48vh;overflow:auto"></div>`, {
    onMount: (el, close) => {
      const draw = () => {
        $("#qg", el).innerHTML = ["", ...groups].map(g => `<button type="button" class="btn sm ${g === grp ? "primary" : ""}" data-g="${esc(g)}">${g ? esc(g) : "All"}</button>`).join("");
        $$("[data-g]", el).forEach(b => b.onclick = () => { grp = b.dataset.g; draw(); });
        const shown = items.filter(i => (!grp || (i.groups || []).includes(grp)) && (!q || (i.name + " " + (i.names || "")).toLowerCase().includes(q)));
        $("#ql", el).innerHTML = shown.length ? shown.map(i => `<div class="li" style="cursor:pointer" data-pick="${i.id}">
            <div class="grow"><div class="t">${esc(i.name)}</div><div class="m">${esc((i.groups || []).join(" · "))}${i.dosage ? " — " + esc(i.dosage.split("\n")[0].slice(0, 60)) : ""}</div></div>
            <button class="btn sm ghost" data-edit="${i.id}" title="Edit this saved item">✎</button></div>`).join("")
          : '<div class="empty small">Nothing matches. Use “+ New item” to add one.</div>';
        $$("[data-pick]", el).forEach(r => r.onclick = e => {
          if (e.target.closest("[data-edit]")) return;
          const it = items.find(x => x.id === +r.dataset.pick); close(); medForm(null, prefillFromItem(it));
        });
        $$("[data-edit]", el).forEach(b => b.onclick = e => { e.stopPropagation(); close(); libEditModal(items.find(x => x.id === +b.dataset.edit)); });
      };
      $("#qs", el).oninput = e => { q = e.target.value.trim().toLowerCase(); draw(); };
      $("#qnew", el).onclick = () => { close(); libEditModal(null); };
      draw(); $("#qs", el).focus();
    },
  });
}

/* ---- add / edit / delete a saved item */
function libEditModal(it, after) {
  const v = it || { name: "", groups: [] };
  modal(`<h2>${it ? "Edit" : "New"} quick-add item</h2>
    <form id="f" class="form-grid">
      <label class="f full">Name<input name="name" required value="${esc(v.name)}"></label>
      <label class="f full">Group(s) <span class="muted">(separate with commas)</span><input name="groups" value="${esc((v.groups || []).join(", "))}"></label>
      <label class="f full">Also known as<input name="names" value="${esc(v.names || "")}"></label>
      ${LIB_FIELDS.map(([k, l]) => `<label class="f full">${l}<textarea name="${k}" rows="${k === "dosage" || k === "notes" ? 3 : 2}">${esc(v[k] || "")}</textarea></label>`).join("")}
      <div class="actions full">${it ? '<button type="button" class="btn" id="del" style="margin-right:auto">Delete</button>' : ""}<button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div>
    </form>`, {
    wide: true,
    onMount: (el, close) => {
      $("#f", el).onsubmit = async e => {
        e.preventDefault();
        const b = Object.fromEntries(new FormData(e.target)); b.groups = (b.groups || "").split(",").map(x => x.trim()).filter(Boolean);
        await run($(".primary", el), async () => {
          if (it) await api("/library/" + it.id, "PUT", b); else await api("/library", "POST", b);
          close(); toast("Saved"); after ? after() : quickAddModal();
        });
      };
      const d = $("#del", el);
      if (d) d.onclick = async () => { if (await confirmBox(`Remove ${it.name} from your quick-add list? Medications already added keep their info.`)) { await api("/library/" + it.id, "DELETE"); close(); toast("Removed"); after ? after() : quickAddModal(); } };
    },
  });
}

/* ---- browse every saved reference sheet (also reachable from Inventory and Medication) */
async function refBrowser(group) {
  const items = await api("/library"), groups = [...new Set(items.flatMap(i => i.groups || []))].sort();
  let q = "", grp = group || "";
  modal(`<h2>📖 Reference sheets</h2>
    <input id="rq" placeholder="Search…" autocomplete="off" style="width:100%">
    <div class="row wrap" id="rg" style="gap:6px;margin:10px 0"></div>
    <div id="rl" class="list" style="max-height:52vh;overflow:auto"></div>
    <div class="actions"><button type="button" class="btn sm" id="rnew2" style="margin-right:auto">+ New sheet</button><button type="button" class="btn" data-close>Close</button></div>`, {
    onMount: (el, close) => {
      const draw = () => {
        $("#rg", el).innerHTML = ["", ...groups].map(g => `<button type="button" class="btn sm ${g === grp ? "primary" : ""}" data-g="${esc(g)}">${g ? esc(g) : "All"}</button>`).join("");
        $$("[data-g]", el).forEach(b => b.onclick = () => { grp = b.dataset.g; draw(); });
        const shown = items.filter(i => (!grp || (i.groups || []).includes(grp)) && (!q || (i.name + " " + (i.names || "")).toLowerCase().includes(q)));
        $("#rl", el).innerHTML = shown.length ? shown.map(i => `<div class="li" style="cursor:pointer" data-s="${i.id}"><div class="grow"><b>${esc(i.name)}</b><div class="small muted">${esc((i.groups || []).join(" · "))}</div></div></div>`).join("") : '<div class="empty small">No sheets match.</div>';
        $$("[data-s]", el).forEach(r => r.onclick = () => { close(); refSheetModal(items.find(x => x.id === +r.dataset.s), () => refBrowser(grp)); });
      };
      $("#rq", el).oninput = e => { q = e.target.value.trim().toLowerCase(); draw(); };
      $("#rnew2", el).onclick = () => { close(); libEditModal(null, () => refBrowser(grp)); };
      draw(); $("#rq", el).focus();
    },
  });
}

function refSheetModal(it, back) {
  const rows = [["names", "Also known as"], ...LIB_FIELDS].filter(([k]) => it[k] && it[k].trim());
  const diluent = (it.groups || []).length && (it.groups || []).every(g => g === "Diluents & Additives");
  modal(`<h2>${esc(it.name)}</h2>
    <div class="row wrap" style="gap:6px;margin-bottom:10px">${(it.groups || []).map(g => `<span class="badge">${esc(g)}</span>`).join("")}</div>
    <dl class="kv ref" style="max-height:52vh;overflow:auto">${rows.map(([k, l]) => `<dt>${l}</dt><dd style="white-space:pre-line">${esc(it[k])}</dd>`).join("")}</dl>
    <p class="small muted" style="margin:8px 0 0">Information from your saved reference list, not advice.</p>
    <div class="actions"><button type="button" class="btn sm" id="redit" style="margin-right:auto">✎ Edit</button>${back ? '<button type="button" class="btn" id="rback">← Back</button>' : ""}
      <button type="button" class="btn" id="rinv">＋ Inventory</button>${diluent ? "" : '<button type="button" class="btn primary" id="rmed">＋ Add as medication</button>'}<button type="button" class="btn" data-close>Close</button></div>`, {
    wide: true,
    onMount: (el, close) => {
      $("#rinv", el).onclick = () => { close(); invAddFromRef(it); };
      const m = $("#rmed", el); if (m) m.onclick = () => { close(); medForm(null, prefillFromItem(it)); };
      $("#redit", el).onclick = () => { close(); libEditModal(it, () => { Router.render(); }); };
      const b = $("#rback", el); if (b) b.onclick = () => { close(); back(); };
    },
  });
}
