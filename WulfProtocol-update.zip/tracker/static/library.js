/* Quick add: a saved list of reference sheets. Pick one and the Add form opens pre-filled,
   with the reference info attached so it shows on the medication's page. */
const LIB_FIELDS = [["components", "Components"], ["indications", "Indications"], ["solubility", "Solubility"], ["reconstitute", "Reconstitute with"], ["storage", "Storage"],
  ["dosage", "Dosage"], ["onset", "Onset"], ["half_life", "Half-life"], ["side_effects", "Side effects"], ["pricing", "Pricing"], ["notes", "Notes"]];
const hasText = v => !!v && !/^\s*n\/?a\b/i.test(String(v));
/* what it's mixed with: the "Reconstitute with" line, or the start of the "Solubility" line ("BAC Water up to 100mg/mL" -> BAC Water)
   when the sheet stores it once mixed (so "DMSO up to 75mg/mL" on a tablet isn't shown as something to mix with) */
function mixLiquid(r) {
  if (!r) return "";
  if (hasText(r.reconstitute)) return noFlags(r.reconstitute).split("\n")[0].trim();
  if (!hasText(r.solubility) || !/reconstitut|once mixed|after mixing/i.test(r.storage || "")) return "";
  const s = noFlags(r.solubility).split("\n")[0].trim().split(/\s+(?:up to|for)\b|,|\s+or\s+/i)[0].trim();
  return /^\d/.test(s) ? "" : s;
}
/* the vial size from the "Pricing" line: "6 (50mg) vials", "(5,000IU) vial", "10mg vial", "(5mg vials)", "(2.5g) vial" -> mg / mcg / IU
   (ready-made liquids like "(10mL) vial" are skipped) */
function sheetVial(it) {
  const m = String((it && it.pricing) || "").match(/(\d[\d,]*(?:\.\d+)?)\s*(mg|mcg|iu|g)\b\s*\)?\s*(?:vials?|pens?|cartridges?)\b/i);
  if (!m) return null;
  const n = +m[1].replace(/,/g, ""), u = m[2].toLowerCase();
  return u === "g" ? { amount: n * 1000, unit: "mg" } : { amount: n, unit: u === "iu" ? "IU" : u };
}

function refFromItem(it) {
  const r = { name: it.name, group: (it.groups || []).join(", "), names: it.names || "" };
  LIB_FIELDS.forEach(([k]) => (r[k] = it[k] || ""));
  return r;
}
/* ---- heads-up lines: anything the sheet wrote as ***LIKE THIS*** */
const fixFlags = t => String(t || "").replace(/\*\*\*([^*]+?)\*\*\*(?=[A-Z ]{4,}\*\*\*)/g, "***$1*** ***");
function refFlags(m) {
  const r = m && m.reference_obj; if (!r) return [];
  const out = [];
  [r.notes, r.storage, r.dosage, r.reconstitute, r.solubility, r.indications].forEach(t => {
    (fixFlags(t).match(/\*\*\*([^*]+?)\*\*\*/g) || []).forEach(x => { const v = x.replace(/\*/g, "").trim(); if (v && !out.includes(v)) out.push(v); });
  });
  return out;
}
const flagHtml = (m, small) => refFlags(m).map(f => `<div class="alert flag" ${small ? 'style="padding:6px 10px;font-size:.8rem;margin-top:8px"' : ""}>⚠️ ${esc(f)}</div>`).join("");
const noFlags = t => fixFlags(t).replace(/\*\*\*[^*]+?\*\*\*/g, "").replace(/\n{2,}/g, "\n").trim();

function refCard(m) {
  const r = m.reference_obj; if (!r) return "";
  const rows = [["names", "Also known as"], ...LIB_FIELDS].filter(([k]) => k !== "pricing")      // Pricing is only read for the vial size (still editable in the sheet)
    .map(([k, l]) => [k, l, noFlags(r[k])]).filter(([k, l, v]) => v && !/^n\/?a$/i.test(v));
  return `<div class="card"><h2>Reference ${r.group ? `<span class="badge">${esc(r.group)}</span>` : ""}</h2>
    ${refFlags(m).map(f => `<div class="alert flag" style="margin-bottom:8px">⚠️ ${esc(f)}</div>`).join("")}
    <dl class="kv ref">${rows.map(([k, l, v]) => `<dt>${l}</dt><dd style="white-space:pre-line">${esc(v)}</dd>`).join("")}</dl>
    <p class="small muted" style="margin:8px 0 0">From your saved reference list. It's information you entered, not advice.</p></div>`;
}

/* ---- "Sheet vs yours": the main facts from the reference sheet next to this medication's own settings.
   Nothing changes unless a button is pressed. Ranges use the lower number. */
const SPAN = { day: 1, week: 7, month: 30 };
const spanDays = (n, u) => +n * SPAN[u.toLowerCase().replace(/s$/, "")];
const fmtSpan = d => d >= 30 && d % 30 === 0 ? `${d / 30} month${d === 30 ? "" : "s"}` : d % 7 === 0 ? `${d / 7} week${d === 7 ? "" : "s"}` : `${d} day${d === 1 ? "" : "s"}`;
function sheetCycle(it) {
  const text = [it.notes || "", it.dosage || ""].join("\n"), U = "(days?|weeks?|months?)", R = "(\\d+)(?:\\s*[-–]\\s*\\d+)?\\s*";
  const rx = [new RegExp(R + U + "\\b[^\\d\\n]*?\\bthen\\b[^\\d\\n]*?" + R + U + "\\s*(?:off|break|rest|pause)", "i"),         // "8-12 weeks on then 4-8 weeks off", "8 weeks then 4 week break"
              new RegExp(R + U + "\\b[^\\d\\n]*?\\bthen\\s+(?:withhold|rest|pause|stop)\\w*\\s+(?:for\\s+)?" + R + U, "i"),  // "3 months then withhold for 2 months"
              new RegExp(R + U + "\\s+on\\b[^\\d\\n]*?" + R + U + "\\s+off", "i"),                                             // "1 month on, 2 months off"
              new RegExp(R + U + "\\b[^\\d\\n]*?\\bthen\\s+off\\s+(?:for\\s+)?" + R + U, "i")];                               // "on 3 months then off 2 months"
  const found = [];                                                       // every match, in the order the sheet says them
  for (const r of rx) {
    const g = new RegExp(r.source, "gi"); let m;
    while ((m = g.exec(text))) {
      if (/per\s*week|a\s*week|weekly/i.test(m[0])) continue;            // "5 days per week then 2 days off" is a weekly schedule, not a cycle
      found.push({ at: m.index, on: spanDays(m[1], m[2]), off: spanDays(m[3], m[4]), line: text.slice(text.lastIndexOf("\n", m.index) + 1).split("\n")[0].trim() });
    }
  }
  found.sort((a, b) => a.at - b.at);
  const best = found.find(x => x.on + x.off > 7) || found[0];             // "on 5 days then off 2 days" is a week, not the cycle; otherwise the first one (the standard cycle)
  if (best) { delete best.at; return best; }
  const l = text.split("\n").find(x => /\bcycle\b|weeks? on|\bbreak\b/i.test(x) && !/post cycle|\bPCT\b|during|AAS cycle/i.test(x));
  return l ? { line: l.trim() } : null;
}
function sheetUseWithin(it) {
  const l = String(it.storage || "").split("\n").find(x => /reconstitut|once mixed|after mixing/i.test(x));
  const m = l && l.match(/(\d+)(?:\s*[-–]\s*\d+)?\s*(hours?|hrs?|days?|weeks?|months?)/i);
  if (!m) return null;
  return { days: /^h/i.test(m[2]) ? Math.max(1, Math.floor(+m[1] / 24)) : spanDays(m[1], m[2]), line: l.trim() };
}
/* "Max cycle 1 month", "Max cycle length 1-2 weeks": the longest it should run (offered as an end date, never set by itself) */
function sheetMaxCycle(it) {
  const text = [it.notes || "", it.dosage || ""].join("\n");
  const m = text.match(/max(?:imum)?\.?\s*(?:cycle|use|duration)(?:\s*length)?\s*(?:of\s*|:\s*)?(\d+)(?:\s*[-–]\s*\d+)?\s*(days?|weeks?|months?)/i)
    || text.match(/\bcycle(?:\s*(?:length|on))?\s*(?:of\s*|:\s*)?(\d+)(?:\s*[-–]\s*\d+)?\s*(days?|weeks?|months?)/i);      // "Cycle length 6-8 weeks", "Cycle on 4-6 weeks then off"
  if (!m) return null;
  return { days: spanDays(m[1], m[2]), line: text.slice(text.lastIndexOf("\n", m.index) + 1).split("\n")[0].trim() };
}
const addDays = (s, n) => { const d = new Date((s || todayStr()) + "T12:00:00"); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const perWeek = s => { if (!s || s.type === "prn") return null; const k = Math.max(1, (s.times || []).length);
  return s.type === "daily" ? 7 * k : s.type === "interval" ? 7 / (+s.every || 1) * k : s.type === "weekdays" ? (s.days || []).length * k : null; };
const oftenText = s => { if (!s || s.type === "prn") return "As needed"; const k = Math.max(1, (s.times || []).length);
  if (s.type === "daily") return k === 1 ? "Once a day" : `${k}× a day`;
  if (s.type === "interval") return `Every ${s.every} days`;
  const n = (s.days || []).length * k; return n === 1 ? "Once a week" : `${n}× a week`; };

function sheetRows(m) {
  const r = m.reference_obj; if (!r) return [];
  const g = guessFromItem(r), rows = [], R = App.routes || {};
  const toUnit = (v, from, to) => from === to ? v : from === "mg" && to === "mcg" ? v * 1000 : from === "mcg" && to === "mg" ? v / 1000 : null;
  if (g.dose) {
    const theirs = m.dose != null ? `${num(m.dose, 3)} ${m.dose_unit}` : "Not set";
    const sv = toUnit(g.dose, g.dose_unit, m.dose_unit);
    const mk = isMarks(m) && marksInfo(m), sheetInVial = mk ? toUnit(g.dose, g.dose_unit, mk.unit) : null;
    if (m.plan) rows.push({ k: "Dose", sheet: `${num(g.dose, 3)} ${g.dose_unit} to start`, yours: `Dose steps (now ${theirs}${isMarks(m) ? " on the syringe" : ""}${mk ? ` = ${num(mk.amount, 3)} ${mk.unit}` : ""})`, state: "info", vial: isMarks(m),
      note: isMarks(m) && !mk ? "You log syringe marks. Tell the app the vial's strength once and it shows how much medication each dose is." : "" });
    else if (isMarks(m) && !mk) rows.push({ k: "Dose", sheet: `${num(g.dose, 3)} ${g.dose_unit}`, yours: `${theirs} on the syringe`, state: "info", vial: true,
      note: "You log syringe marks. Tell the app the vial's strength once and it can compare them." });
    else if (mk && sheetInVial == null) rows.push({ k: "Dose", sheet: `${num(g.dose, 3)} ${g.dose_unit}`, yours: `${theirs} on the syringe = ${num(mk.amount, 3)} ${mk.unit}`, state: "info", vial: true,
      note: `Your vial is in ${mk.unit} and the sheet is in ${g.dose_unit}, so these can't be compared.` });
    else if (mk) {
      const marks = +(sheetInVial / mk.conc * 100).toFixed(1);
      rows.push({ k: "Dose", sheet: `${num(g.dose, 3)} ${g.dose_unit} (= ${num(marks, 1)} units on the syringe)`, yours: `${theirs} on the syringe = ${num(mk.amount, 3)} ${mk.unit}`,
        state: Math.abs(marks - m.dose) < 0.051 ? "same" : "differ", set: { dose: marks }, vial: true });
    }
    else if (sv == null) rows.push({ k: "Dose", sheet: `${num(g.dose, 3)} ${g.dose_unit}`, yours: theirs, state: "info",
      note: m.dose_unit === "units" ? "You log syringe marks, so these can't be compared yet." : "Different units, so these can't be compared." });
    else rows.push({ k: "Dose", sheet: `${num(sv, 3)} ${m.dose_unit}`, yours: theirs, state: Math.abs(sv - (m.dose || 0)) < 1e-9 ? "same" : "differ", set: { dose: +sv.toFixed(4) } });
  }
  if (g.route_type && R[g.route_type]) {
    rows.push({ k: "How it's taken", sheet: R[g.route_type].label, yours: (R[m.route_type] || R.other || { label: "–" }).label, state: g.route_type === m.route_type ? "same" : "differ", edit: true });
  }
  if (!g.hints.some(h => /how often/.test(h))) {
    const a = perWeek(g.schedule), b = perWeek(m.schedule_obj);
    rows.push({ k: "How often", sheet: oftenText(g.schedule), yours: m.schedule_text, state: a === b && (a != null || m.schedule_obj.type === "prn") ? "same" : "differ", edit: true });
  }
  const c = sheetCycle(r), mine = m.cycle_on ? `${fmtSpan(m.cycle_on)} on, ${fmtSpan(m.cycle_off)} off` : "No cycle";
  if (c && c.on) rows.push({ k: "Cycle", sheet: `${fmtSpan(c.on)} on, ${fmtSpan(c.off)} off`, yours: mine, state: c.on === m.cycle_on && c.off === m.cycle_off ? "same" : "differ", set: { cycle_on: c.on, cycle_off: c.off }, line: c.line });
  else if (c) rows.push({ k: "Cycle", sheet: c.line, yours: mine, state: "info" });
  const mix = mixLiquid(r), p = sheetMix(r).fields, vialMine = m.vial_amount ? `${num(m.vial_amount, 3)} ${m.vial_unit || "mg"}` : "Not set";
  const mixMine = m.diluent_ml ? `${num(m.diluent_ml, 2)} mL${m.vial_amount ? ` in a ${vialMine} vial` : ""}` : "Not set";
  if (p.diluent_ml && p.vial_amount) rows.push({ k: "Mix with", sheet: `${mix || "Water"}: ${num(p.diluent_ml, 2)} mL to a ${num(p.vial_amount, 3)} ${p.vial_unit} vial`, yours: mixMine,
    state: p.diluent_ml === m.diluent_ml && p.vial_amount === m.vial_amount && p.vial_unit === (m.vial_unit || "mg") ? "same" : "differ", set: { diluent_ml: p.diluent_ml, vial_amount: p.vial_amount, vial_unit: p.vial_unit } });
  else {
    if (p.vial_amount) rows.push({ k: "Vial size", sheet: `${num(p.vial_amount, 3)} ${p.vial_unit}`, yours: vialMine,
      state: p.vial_amount === m.vial_amount && p.vial_unit === (m.vial_unit || "mg") ? "same" : "differ", set: { vial_amount: p.vial_amount, vial_unit: p.vial_unit } });
    if (mix) rows.push({ k: "Mix with", sheet: mix + (p.diluent_ml ? `: ${num(p.diluent_ml, 2)} mL per vial` : ""), yours: mixMine, state: "info" });
  }
  const u = sheetUseWithin(r);
  const inDays = d => `${d} day${d === 1 ? "" : "s"}`;
  if (u) rows.push({ k: "Use within once mixed", sheet: inDays(u.days), yours: m.use_within_days ? inDays(m.use_within_days) : "Not set",
    state: u.days === m.use_within_days ? "same" : "differ", set: { use_within_days: u.days }, line: u.line });
  return rows;
}

function sheetCompareCard(m) {
  const rows = sheetRows(m); if (!rows.length) return "";
  const diff = rows.filter(x => x.state === "differ").length;
  const mark = { same: '<span class="sv-mark ok" title="Matches the sheet">✓</span>', differ: '<span class="sv-mark warn" title="Different from the sheet">≠</span>', info: '<span class="sv-mark" title="For information">ⓘ</span>' };
  return `<div class="card" id="sheetvs"><h2>📖 Sheet vs yours ${diff ? `<span class="badge warn">${diff} different</span>` : '<span class="badge ok">all match</span>'}</h2>
    <div class="sv">${rows.map((x, i) => `<div class="sv-row ${x.state}">${mark[x.state]}<div class="grow"><div class="sv-k">${esc(x.k)}</div>
      <div class="sv-v"><span class="muted">Sheet:</span> ${esc(x.sheet)}</div><div class="sv-v"><span class="muted">Yours:</span> ${esc(x.yours)}</div>
      ${x.note ? `<div class="small muted">${esc(x.note)}</div>` : ""}</div>
      ${x.state === "differ" ? (x.set ? `<button class="btn sm" data-sv="${i}">Use sheet's</button>` : `<button class="btn sm" data-sv-edit>Edit</button>`)
        : x.vial && x.state === "info" && !marksInfo(m) ? `<button class="btn sm" data-sv-vial>Set vial strength</button>` : ""}</div>`).join("")}</div>
    <p class="small muted" style="margin:8px 0 0">Nothing changes unless you press a button. To change the sheet itself, use 📖 Reference. Ranges use the lower number.</p></div>`;
}

function bindSheetCompare(view, m) {
  const card = $("#sheetvs", view); if (!card) return;
  const rows = sheetRows(m);
  $$("[data-sv]", card).forEach(b => b.onclick = async () => {
    const x = rows[+b.dataset.sv];
    await run(b, async () => {
      await api("/meds/" + m.id, "PUT", x.set);
      toast(x.set.use_within_days && !m.opened_on ? `${x.k}: ${x.sheet}. Set the day you opened the vial (Edit) to start the countdown.` : `${x.k} now matches the sheet: ${x.sheet}`);
      Router.render();
    });
  });
  $$("[data-sv-edit]", card).forEach(b => b.onclick = () => medForm(m));
  $$("[data-sv-vial]", card).forEach(b => b.onclick = () => vialStrengthModal(m));
}

/* asked once for a medication logged in syringe marks: what's in the vial, so marks can be turned into mg / mcg / IU */
function vialStrengthModal(m) {
  const g = m.reference_obj ? guessFromItem(m.reference_obj) : {}, sv = sheetVial(m.reference_obj);
  const du = sv ? sv.unit : ["mg", "mcg", "IU"].includes(g.dose_unit) ? g.dose_unit : (m.vial_unit || "mg");
  const start = m.vial_amount || (sv && sv.amount) || "";
  modal(`<h2>💉 Vial strength — ${esc(m.name)}</h2>
    <p class="muted" style="margin-top:0">You log ${esc(m.name)} in syringe marks (units on a U-100 insulin syringe). Tell the app what's in the vial once and it shows how much medication each dose is.</p>
    <form id="vs" class="form-grid">
      <label class="f full">The label shows<select name="mode"><option value="total">Total amount in it (e.g. 5000 IU, then water added)</option><option value="perml">Amount per mL (e.g. 200 mg/mL)</option></select></label>
      <label class="f"><span data-vs-l>Total in the vial</span><input type="number" step="any" min="0" name="amt" required placeholder="e.g. 5000" value="${start}"></label>${sv ? `<span class="small muted full" style="margin-top:-6px">The vial size ${num(sv.amount, 3)} ${esc(sv.unit)} is from your sheet's Pricing line. Change it if yours is different.</span>` : ""}
      <label class="f">Unit<select name="unit">${["mg", "mcg", "IU"].map(u => `<option ${u === du ? "selected" : ""}>${u}</option>`).join("")}</select></label>
      <label class="f full"><span data-vs-ml>Water you added (mL)</span><input type="number" step="any" min="0" name="ml" required placeholder="e.g. 5"></label>
      <div class="full small" id="vs-eq"></div>
      <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div></form>`, {
    onMount: (el, close) => {
      const f = $("#vs", el);
      const calc = () => { const per = f.mode.value === "perml", a = +f.amt.value, ml = +f.ml.value;
        $("[data-vs-l]", el).textContent = per ? "Amount in each mL" : "Total in the vial";
        $("[data-vs-ml]", el).textContent = per ? "Liquid in the vial (mL)" : "Water you added (mL)";
        const total = per ? a * ml : a;
        $("#vs-eq", el).innerHTML = total > 0 && ml > 0 && m.dose > 0 ? `Your dose of <b>${num(m.dose, 3)} units</b> on the syringe = <b>${num(total / ml * m.dose / 100, 3)} ${esc(f.unit.value)}</b>` : "";
        return { total, ml }; };
      f.oninput = calc; f.onchange = calc;
      f.onsubmit = async e => { e.preventDefault(); const { total, ml } = calc();
        if (!(total > 0 && ml > 0)) return toast("Type the amount and the mL", true);
        await run($("button.primary", el), async () => { await api("/meds/" + m.id, "PUT", { vial_amount: +total.toFixed(4), vial_unit: f.unit.value, diluent_ml: ml }); close(); toast("Vial strength saved"); Router.render(); }); };
    },
  });
}

/* ---- "At a glance": a few facts from the sheet near the top of the medication page (read-only) */
const plainTemp = t => t.replace(/(-?\d+\s*[-–]\s*\d+|-?\d+)\s*º?°?\s*C\b/g, (x, n) => /^2\s*[-–]\s*8$/.test(n.trim()) ? `${x} (fridge)` : /^-\d/.test(n.trim()) ? `${x} (freezer)` : x);
function glanceFacts(r) {
  if (!r) return [];
  const has = v => v && !/^n\/?a\b/i.test(String(v).trim()), out = [];
  const hlLine = [r.onset, r.notes].map(t => String(t || "").split("\n").find(l => /half[- ]?life/i.test(l))).find(Boolean);
  const hl = has(r.half_life) ? noFlags(r.half_life).split("\n")[0].trim() : hlLine ? hlLine.replace(/^.*half[- ]?life\s*:?\s*/i, "").trim() : "";
  if (hl) out.push(["Half-life", hl]);
  const mix = mixLiquid(r);
  const st = noFlags(r.storage || "").split("\n").map(x => x.trim()).filter(Boolean);
  const mixed = st.find(x => /reconstitut|once mixed|after mixing/i.test(x));
  if (mixed) out.push(["Once mixed", plainTemp(mixed.replace(/^(reconstituted|once mixed|after mixing)\s*:?\s*/i, ""))]);
  else if (st.length && has(st[0])) out.push(["Storage", plainTemp(st[0])]);
  if (mix) out.push(["Mix with", mix]);
  return out;
}
const glanceHtml = m => { const f = glanceFacts(m.reference_obj); return f.length ? `<div class="glance" id="glance" title="From your reference sheet">${f.map(([k, v]) => `<div class="gl"><span class="k">${esc(k)}</span>${esc(v)}</div>`).join("")}</div>` : ""; };

/* ---- side effects from the sheet -> tap-to-note chips */
function effectList(m) {
  const r = m && m.reference_obj; if (!r) return [];
  const out = [];
  String(r.side_effects || "").split(/[\n,;]+/).forEach(x => {
    let v = x.replace(/^[\s\-•*]+|[\s.]+$/g, "").trim();
    if (!v || v.length > 32 || /^(none|n\/?a|possible|may|can|decreases|increases|very)\b/i.test(v) || /^and /i.test(v)) return;
    v = v.charAt(0).toUpperCase() + v.slice(1);
    if (!out.some(o => o.toLowerCase() === v.toLowerCase())) out.push(v);
  });
  return out.slice(0, 14);
}

/* ---- dose steps by week ("2.5mg weeks 1-4 / 5mg weeks 5-8 ...") */
const freqPresets = base => {
  const baseDay = base && base.type === "weekdays" && (base.days || []).length === 1 ? base.days : [0];
  return [["keep", "Keep my schedule", null], ["daily", "Every day", { type: "daily" }], ["twice", "Twice a day", { type: "daily", times: ["08:00", "20:00"] }],
    ["thrice", "Three times a day", { type: "daily", times: ["08:00", "14:00", "20:00"] }], ["eod", "Every other day", { type: "interval", every: 2 }],
    ["w1", "Once a week", { type: "weekdays", days: baseDay }], ["w2", "Twice a week", { type: "weekdays", days: [0, 3] }],
    ["w3", "3 days a week", { type: "weekdays", days: [0, 2, 4] }], ["w4", "4 days a week", { type: "weekdays", days: [0, 1, 3, 4] }],
    ["w5", "5 days a week (Mon–Fri)", { type: "weekdays", days: [0, 1, 2, 3, 4] }]];
};
function lineFreq(line) {
  const t = line.toLowerCase(); let k;
  if (/three times (a |per )?day|3\s*x\s*(a |per )?(day|daily)|\btid\b/.test(t) && !/week/.test(t)) return "thrice";
  if (/twice (a |per )?(day|daily)|2\s*x\s*(a |per )?(day|daily)|\bbid\b/.test(t)) return "twice";
  if (/every other day|\beod\b/.test(t)) return "eod";
  if (/twice (a |per )?week|twice weekly/.test(t)) return "w2";
  if (/(three|3) times (a |per )?week/.test(t)) return "w3";
  if ((k = t.match(/(\d)\s*(?:x|times)\s*(?:per|a|\/)?\s*(?:week|wk)/)) && +k[1] >= 1 && +k[1] <= 5) return "w" + k[1];
  if (/once (a |per )?week|weekly|once per week/.test(t)) return "w1";
  if (/once (a |per )?day|\bdaily\b|every day/.test(t)) return "daily";
  return "keep";
}
/* Reads "Weeks 1-4: 250mcg daily", "Month 2: ...", "Days 1-14: ...", "First 4 weeks ...", "then 500mcg" and several steps on one line.
   Returns every step it could read (each remembers the line it came from). */
const _DASH = "(?:[-–—]|to|through|thru)";
function rawSteps(text, unit) {
  const steps = []; let prevEnd = null;
  const segs = [];
  String(text || "").split("\n").forEach(line => line.split(/;|\s\|\s|,\s*(?=(?:weeks?|wks?|months?|days?)\s*#?\d)|,?\s+(?=(?:then|thereafter|followed by)\b)/i).forEach(x => { if (x.trim()) segs.push({ t: x, line: line.trim() }); }));
  segs.forEach(({ t: line, line: src }) => {
    if (/\+\s*\d/.test(line)) return;                                    // combined with another drug
    let from = null, to = null, m, openEnd = false;                      // all in days of the plan
    if ((m = line.match(new RegExp("(?:weeks?|wks?)\\s*#?\\s*(\\d+)(?:\\s*" + _DASH + "\\s*(\\d+)|\\s*(\\+))?", "i"))) || (m = line.match(/for\s*#\s*(\d+)\s*[-–]\s*(\d+)/i))) {
      if (m[2] && +m[2] > 104) m[2] = null;                              // "week #1-175": a running total after the dash, not weeks 1 to 175
      from = (+m[1] - 1) * 7 + 1; if (m[2]) to = +m[2] * 7; else if (m[3]) openEnd = true; else to = +m[1] * 7;
    } else if ((m = line.match(new RegExp("months?\\s*#?\\s*(\\d+)(?:\\s*" + _DASH + "\\s*(\\d+))?", "i")))) {
      from = (+m[1] - 1) * 28 + 1; to = (+(m[2] || m[1])) * 28;
    } else if ((m = line.match(new RegExp("days?\\s*#?\\s*(\\d+)(?:\\s*" + _DASH + "\\s*(\\d+)|\\s*(\\+))?", "i")))) {
      from = +m[1]; if (m[2]) to = +m[2]; else if (m[3]) openEnd = true; else to = +m[1];
    } else if ((m = line.match(/first\s+(\d+)\s*(weeks?|days?)/i))) {
      from = 1; to = +m[1] * (/week/i.test(m[2]) ? 7 : 1);
    } else if (/\b(then|thereafter|after that|afterwards|followed by)\b/i.test(line) && prevEnd != null) {
      from = prevEnd + 1; const f = line.match(/for\s+(\d+)\s*(weeks?|days?)/i); if (f) to = from + +f[1] * (/week/i.test(f[2]) ? 7 : 1) - 1; else openEnd = true;
    } else return;
    const d = line.match(/(\d+(?:\.\d+)?)\s*(mcg|µg|ug|mg|iu|ml|units?)\b/i);
    if (!d) return;
    let n = parseFloat(d[1]), u = UNIT_MAP[d[2].toLowerCase()];
    if (unit && u !== unit) {
      if (u === "mg" && unit === "mcg") n *= 1000; else if (u === "mcg" && unit === "mg") n /= 1000; else return;
    }
    steps.push({ from_day: from, dose: +n.toFixed(4), freq: lineFreq(line), ...(to && !openEnd ? { to_day: to } : {}), _src: src });
    prevEnd = to || from;
  });
  steps.sort((a, b) => a.from_day - b.from_day);
  return steps.filter((x, i) => !i || x.from_day !== steps[i - 1].from_day);
}
function parsePhases(text, unit) {
  const uniq = rawSteps(text, unit).map(x => { const y = { ...x }; delete y._src; return y; });
  uniq.forEach((x, i) => { if (i < uniq.length - 1) delete x.to_day; });
  return uniq.length >= 2 ? uniq : [];
}
const FREQ_WORDS = { daily: "every day", twice: "twice a day", thrice: "3 times a day", eod: "every other day", w1: "once a week", w2: "twice a week", w3: "3 days a week", w4: "4 days a week", w5: "5 days a week" };
/* "Weeks 1–4" when a step lines up with whole weeks, otherwise "Days 1–4" */
function stepLabel(x, nx) {
  const end = x.to_day || (nx ? nx.from_day - 1 : null);
  if ((x.from_day - 1) % 7 === 0 && (end == null || end % 7 === 0)) {
    const a = (x.from_day - 1) / 7 + 1, b = end == null ? null : end / 7;
    return b == null ? `Week ${a}+` : b === a ? `Week ${a}` : `Weeks ${a}–${b}`;
  }
  return end == null ? `Day ${x.from_day}+` : end === x.from_day ? `Day ${x.from_day}` : `Days ${x.from_day}–${end}`;
}
function stepSummary(steps, unit) {
  return steps.map((x, i) => `${stepLabel(x, steps[i + 1])}: ${+(+x.dose).toFixed(4)} ${unit}${FREQ_WORDS[x.freq] ? ", " + FREQ_WORDS[x.freq] : ""}`);
}
/* what to save as the plan: a step only stores its own schedule when it differs from the medication's */
function stepsPayload(found, base) {
  const FR = freqPresets(base), norm = x => JSON.stringify([x.type, x.every || null, (x.days || []).slice().sort(), x.times || null]);
  return found.map(x => { const st = { from_day: x.from_day, dose: x.dose }; if (x.to_day) st.to_day = x.to_day;
    const sc = (FR.find(f => f[0] === x.freq) || [])[2];
    if (sc && norm(sc) !== norm({ ...base, times: base.times && sc.times ? base.times : null })) st.schedule = sc;
    return st; });
}
/* How the app reads a reference sheet: what it understood, and what it couldn't (so the sheet can be fixed once) */
function analyzeSheet(it) {
  const g = guessFromItem(it), unit = g.dose_unit || "mg", text = it.dosage || "";
  const raw = rawSteps(text, unit), steps = parsePhases(text, unit);
  const lines = text.split("\n").map(x => x.trim()).filter(x => x && !/reconstitut/i.test(x));
  const used = new Set(raw.map(x => x._src));
  const weekish = lines.filter(l => /\b(weeks?|wks?|months?|days?)\s*#?\d|\bfirst\s+\d+\s*weeks?/i.test(l) && !/per\s*kg|\/\s*kg/i.test(l));
  const unread = weekish.filter(l => !used.has(l));
  const warn = [], info = [];
  unread.forEach(l => warn.push(/\+\s*\d/.test(l) ? `Skipped, because it combines two medications: “${l.slice(0, 90)}”. Write this medication's own steps on separate lines if you want a plan.`
    : `Couldn't turn this into a dose step: “${l.slice(0, 90)}”. Write it like “Weeks 1-4: 250mcg daily”.`));
  if (steps.length === 1 || (raw.length === 1 && !steps.length)) info.push("Only one week-by-week step found, so it won't make a plan. That's fine for a steady dose.");
  g.hints.forEach(h => warn.push(h.charAt(0).toUpperCase() + h.slice(1) + "."));
  if (lines.some(l => /\d+(?:\.\d+)?\s*[-–]\s*\d+(?:\.\d+)?\s*(mcg|µg|ug|mg|iu|units?)\b/i.test(l))) info.push("For ranges like 250–500 mcg the lower amount is used to start. Change it if you like.");
  // cycle and shelf life: what was read, and lines that look like one but couldn't be read
  const cycle = sheetCycle(it), maxc = sheetMaxCycle(it), within = sheetUseWithin(it);
  if (cycle && !cycle.on && !maxc && !/not standardi[sz]ed|no (?:set|standard|fixed)|varies/i.test(cycle.line)) warn.push(`Couldn't read a cycle from: “${cycle.line.slice(0, 90)}”. Write it like “Cycle 8 weeks on, 4 weeks off”.`);
  const mixedLine = String(it.storage || "").split("\n").map(x => x.trim()).find(x => /reconstitut|once mixed|after mixing/i.test(x));
  if (mixedLine && !within) warn.push(`Couldn't read how long it lasts once mixed: “${mixedLine.slice(0, 90)}”. Write it like “Reconstituted 2-8ºC for 28 days”.`);
  else if (!mixedLine && (hasText(it.reconstitute) || /bac water|acetic acid|bacteriostatic/i.test(it.solubility || ""))) info.push("The storage line doesn't say how long it lasts once mixed, so “use within” stays blank.");
  return { g, unit, steps, warn, info, cycle: cycle && cycle.on ? cycle : null, maxc: cycle && cycle.on ? null : maxc, within };
}

/* ---- every dose amount the sheet mentions, as tap-to-use choices ("10-20mg daily" -> 10 mg, 20 mg) */
function doseOptions(text, unit) {
  const out = [];
  String(text || "").split("\n").forEach(line => {
    if (/reconstitut|per\s*kg|\/\s*kg|diluent/i.test(line)) return;
    const re = /(\d+(?:\.\d+)?)(?:\s*[-–]\s*(\d+(?:\.\d+)?))?\s*(mcg|µg|ug|mg|iu|units?)\b/gi; let m;
    while ((m = re.exec(line))) {
      const u = UNIT_MAP[m[3].toLowerCase()];
      [m[1], m[2]].filter(Boolean).forEach(v => {
        let n = parseFloat(v);
        if (u !== unit) { if (u === "mg" && unit === "mcg") n *= 1000; else if (u === "mcg" && unit === "mg") n /= 1000; else return; }
        n = +n.toFixed(4); if (n > 0 && !out.includes(n)) out.push(n);
      });
    }
  });
  return out.sort((a, b) => a - b).slice(0, 7);
}

function stepsModal(m, after) {
  const ref = m.reference_obj, plan = m.plan;
  const found = !plan && ref ? parsePhases(ref.dosage, m.dose_unit) : [];
  const base = m.schedule_obj || { type: "daily" }, FR = freqPresets(base);
  const norm = x => JSON.stringify([x.type, x.every || null, (x.days || []).slice().sort(), x.times || null]);
  const keyOf = sc => { if (!sc) return "keep"; const f = FR.find(r => r[2] && norm(r[2]) === norm(sc)); return f ? f[0] : "custom"; };
  const start = (plan ? plan.steps.map(x => ({ ...x, freq: keyOf(x.schedule) })) : (found.length ? found : [{ from_day: 1, dose: m.dose || "", freq: "keep" }, { from_day: 29, dose: "", freq: "keep" }]));
  const row = (x) => `<div class="row wrap" style="gap:8px;margin-bottom:8px" data-st ${x.freq === "custom" ? `data-custom='${esc(JSON.stringify(x.schedule))}'` : ""}><span class="small muted">From</span><select data-u style="width:auto"><option value="w" ${(x.from_day - 1) % 7 === 0 ? "selected" : ""}>week</option><option value="d" ${(x.from_day - 1) % 7 === 0 ? "" : "selected"}>day</option></select><input type="number" min="1" step="1" value="${(x.from_day - 1) % 7 === 0 ? (x.from_day - 1) / 7 + 1 : x.from_day}" style="width:80px" data-w>
    <input type="number" step="any" min="0" value="${x.dose}" style="width:100px" data-d><span class="small muted">${esc(m.dose_unit)}</span>
    <select data-f style="width:auto">${FR.map(([k, l]) => `<option value="${k}" ${x.freq === k ? "selected" : ""}>${l}</option>`).join("")}${x.freq === "custom" ? `<option value="custom" selected>As you set it</option>` : ""}</select>
    <button type="button" class="btn ghost sm" data-rm title="Remove">✕</button></div>`;
  modal(`<h2>📈 Dose steps — ${esc(m.name)}</h2>
    ${found.length ? `<div class="alert info" style="margin-bottom:10px">Read from the reference sheet. Sheets word these differently, so please check each step before saving.</div>`
      : plan ? "" : `<p class="muted" style="margin-top:0">${ref ? "Couldn't find week-by-week steps in the sheet" : "No reference sheet attached"} — type them in below.</p>`}
    <p class="small muted" style="margin:0 0 8px">Each step starts on the week or day shown and lasts until the next one — use “day” for plans like “days 1-4, then days 5-21”. The dose, and how often you take it, change by themselves as time passes (and the units to draw or dial follow). "Keep my schedule" leaves how often alone.</p>
    <div id="steps">${start.map(row).join("")}</div>
    <button type="button" class="btn sm" id="addst">＋ Add a step</button>
    <div class="row wrap" style="gap:12px;margin-top:12px">
      <label class="f">Plan started on <span class="muted">(day 1)</span><input type="date" id="pst" value="${esc((plan && plan.start) || m.start_date)}"></label>
      <label class="f">Plan ends after <span class="muted">(blank = keeps going)</span><span class="row" style="gap:6px"><select id="pendu" style="width:auto"><option value="w" ${((start[start.length - 1] || {}).to_day || 7) % 7 === 0 ? "selected" : ""}>week</option><option value="d" ${((start[start.length - 1] || {}).to_day || 7) % 7 === 0 ? "" : "selected"}>day</option></select><input type="number" min="1" id="pend" value="${(start[start.length - 1] || {}).to_day ? ((start[start.length - 1].to_day % 7 === 0) ? start[start.length - 1].to_day / 7 : start[start.length - 1].to_day) : ""}" style="width:110px"></span></label></div>
    <div class="actions"><button type="button" class="btn" data-close>Cancel</button>${plan ? `<button type="button" class="btn danger" id="stoff">Stop using steps</button>` : ""}<button class="btn primary" id="stsave">Save steps</button></div>`, {
    onMount: (el, close) => {
      const wire = () => $$("[data-rm]", el).forEach(b => b.onclick = () => { if ($$("[data-st]", el).length > 1) b.closest("[data-st]").remove(); });
      wire();
      const fromDay = r => { const n = +$("[data-w]", r).value; return $("[data-u]", r).value === "w" ? (n - 1) * 7 + 1 : n; };
      $("#addst", el).onclick = () => { const all = $$("[data-st]", el).map(fromDay);
        $("#steps", el).insertAdjacentHTML("beforeend", row({ from_day: (Math.max(0, ...all) || 0) + 28, dose: "", freq: "keep" })); wire(); };
      const off = $("#stoff", el);
      if (off) off.onclick = async () => { await api(`/meds/${m.id}/phases`, "PUT", { steps: null }); close(); toast("Dose steps off"); after ? after() : Router.render(); };
      $("#stsave", el).onclick = async () => {
        const steps = $$("[data-st]", el).map(r => {
          const k = $("[data-f]", r).value, st = { from_day: fromDay(r), dose: +$("[data-d]", r).value };
          const sc = k === "custom" ? JSON.parse(r.dataset.custom) : (FR.find(f => f[0] === k) || [])[2];
          if (sc && norm(sc) !== norm({ ...base, times: base.times && sc.times ? base.times : null })) st.schedule = sc;      // same as your own schedule = nothing to store
          return st;
        });
        if (steps.some(x => !(x.from_day >= 1) || !(x.dose > 0))) return toast("Give every step a start (week or day 1 or more) and a dose", true);
        const endN = +$("#pend", el).value || 0, end = endN ? ($("#pendu", el).value === "w" ? endN * 7 : endN) : 0;
        if (end) { const top = steps.reduce((a, b) => (b.from_day > a.from_day ? b : a)); if (end < top.from_day) return toast("The end must come after the last step starts", true); top.to_day = end; }
        await run($("#stsave", el), async () => { await api(`/meds/${m.id}/phases`, "PUT", { steps, start: $("#pst", el).value }); close(); toast("Dose steps saved"); after ? after() : Router.render(); });
      };
    },
  });
}

/* ---- best-guess dose / route / schedule from the free-text "Dosage" lines (always shown for you to confirm) */
const UNIT_MAP = { mcg: "mcg", ug: "mcg", "µg": "mcg", mg: "mg", g: "g", iu: "IU", ml: "mL", unit: "units", units: "units",
  tablet: "tablet", tablets: "tablet", cap: "capsule", caps: "capsule", capsule: "capsule", capsules: "capsule", spray: "sprays", sprays: "sprays", drop: "drops", drops: "drops" };
const WK = { 1: [0], 2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 4], 5: [0, 1, 2, 3, 4], 6: [0, 1, 2, 3, 4, 5] };
function guessFromItem(it) {
  const lines = (it.dosage || "").split("\n").map(x => x.trim()).filter(x => x && !/reconstitut/i.test(x));
  const first = (lines[0] || "").replace(/^[A-Za-z ]{3,20}:\s*/, "");      // drop labels like "Beginner:"
  const all = [(it.dosage || ""), it.notes || "", it.reconstitute || ""].join("\n");
  const out = { dose: "", dose_unit: null, route_type: null, schedule: { type: "daily", times: ["08:00"] }, hints: [] };
  const m = first.match(/(\d+(?:\.\d+)?)(?:\s*[-–]\s*\d+(?:\.\d+)?)?\s*(mcg|µg|ug|mg|g|iu|ml|units?|tablets?|capsules?|caps?|sprays?|drops?)\b/i);
  if (m) {
    let n = parseFloat(m[1]), u = UNIT_MAP[m[2].toLowerCase()];
    if (u === "g") { n *= 1000; u = "mg"; }
    out.dose = n; out.dose_unit = u;
  }
  const pickRoute = t => /sub-?\s?q|subcut|subq/i.test(t) ? "subq" : /\bIM\b|intramuscular/i.test(t) ? "im"
    : /intranasal|nasal|\bIN\b/.test(t) ? "nasal" : /sublingual/i.test(t) ? "sublingual" : /topical|transdermal/i.test(t) ? "topical"
    : /oral (liquid|solution)/i.test(t) ? "oral_liquid" : /oral|tablet|capsule|pill/i.test(t) ? "oral_tablet" : null;
  out.route_type = pickRoute(first) || pickRoute(lines.slice(1).join("\n")) || (/bac water/i.test(mixLiquid(it)) ? "subq" : null);
  if (!out.route_type) out.hints.push("the sheet doesn't say how it's taken, so check “How do you take it?”");
  if (!m) out.hints.push("no dose amount found");
  const f = first;
  let k;
  if (/as[- ]needed|\bprn\b/i.test(f)) out.schedule = { type: "prn", times: [] };
  else if ((k = f.match(/(\d)\s*x?\s*[-–]\s*\d\s*x\s*(?:a |per )?(?:day|daily)/i)) || /\bonce (?:to|or) twice\s*(?:a |per )?(?:day|daily)/i.test(f)) {     // a range: the lower number
    const n = k ? +k[1] : 1; if (n > 1) out.schedule.times = n === 2 ? ["08:00", "20:00"] : ["08:00", "14:00", "20:00"];
  }
  else if (/(three|3)\s*(times|x)\s*(a |per )?(day|daily)|\btid\b/i.test(f) || /\b3x daily\b/i.test(f)) out.schedule.times = ["08:00", "14:00", "20:00"];
  else if (/twice\s*(a |per )?(day|daily)|2\s*x\s*(per |a )?(day|daily)|\bbid\b|2x daily/i.test(f)) out.schedule.times = ["08:00", "20:00"];
  else if (/twice\s*(a |per )?week|twice weekly|2\s*x\s*(a |per )?week/i.test(f)) out.schedule = { type: "weekdays", days: WK[2], times: ["08:00"] };
  else if (/(three|3)\s*times\s*(a |per )?week/i.test(f)) out.schedule = { type: "weekdays", days: WK[3], times: ["08:00"] };
  else if ((k = f.match(/(\d)\s*(?:x|times)\s*(?:per|a|\/)?\s*(?:week|wk)/i)) && WK[+k[1]]) out.schedule = { type: "weekdays", days: WK[+k[1]], times: ["08:00"] };
  else if (/every other day|\beod\b/i.test(f)) out.schedule = { type: "interval", every: 2, times: ["08:00"] };
  else if ((k = f.match(/every (\d+) days/i))) out.schedule = { type: "interval", every: +k[1], times: ["08:00"] };
  else if (/weekly|once (a|per) week|per week/i.test(f) && !/daily/i.test(f)) out.schedule = { type: "weekdays", days: [0], times: ["08:00"] };
  else if (/(bed ?time|at night|nightly|before bed)/i.test(f)) out.schedule.times = ["21:00"];
  else if (!/daily|per day|every day|once a day/i.test(f)) out.hints.push("the sheet doesn't say how often, so check the schedule");
  return out;
}
/* vial size and water added, from the sheet: an "Adding 4mL BAC to 50mg vial" line wins (Notes, Dosage or Reconstitute);
   otherwise the vial size from Pricing, and the water is left for you to pick (the BAC bottle size in Pricing is not the water added) */
function sheetMix(it) {
  const txt = [it.notes, it.dosage, it.reconstitute].map(x => x || "").join("\n"), f = {};
  let w;
  if ((w = txt.match(/adding\s*(\d+(?:\.\d+)?)\s*ml[^\n]*?to (?:a |each |the )?(\d+(?:\.\d+)?)\s*(mg|mcg|iu)\b/i))) { f.diluent_ml = +w[1]; f.vial_amount = +w[2]; f.vial_unit = /iu/i.test(w[3]) ? "IU" : w[3].toLowerCase(); }
  else if ((w = txt.match(/(\d+(?:\.\d+)?)\s*ml\s*\/\s*(\d+(?:\.\d+)?)\s*mg/i))) { f.diluent_ml = +w[1]; f.vial_amount = +w[2]; f.vial_unit = "mg"; }
  else if ((w = txt.match(/\b(?:add(?:ing)?|reconstitute\b[^\n]*?\bwith)\s*(\d+(?:\.\d+)?)\s*ml\b/i))) f.diluent_ml = +w[1];   // "add 1mL BAC to each vial"
  const v = sheetVial(it);
  if (!f.vial_amount && v) { f.vial_amount = v.amount; f.vial_unit = v.unit; }
  const vt = f.vial_amount ? `${num(f.vial_amount, 3)} ${f.vial_unit} vial` : "";
  const text = f.diluent_ml ? `${num(f.diluent_ml, 2)} mL ${mixLiquid(it) || "water"} ${vt ? "to a " + vt : "per vial"}` : vt;
  return { fields: f, text };
}
function prefillFromItem(it) {
  const g = guessFromItem(it), groups = it.groups || [];
  const R = App.routes, rt = g.route_type || "other";
  const fields = { name: it.name, kind: groups.some(x => /Anabolic|PCT|Post-Cycle|Analgesic/.test(x)) ? "medication" : "peptide",
    route_type: rt, dose: g.dose, dose_unit: g.dose_unit || R[rt].unit, schedule_obj: g.schedule, container: "vial" };
  const mixed = sheetMix(it);
  Object.assign(fields, mixed.fields);
  const filled = [], cyc = sheetCycle(it), uw = sheetUseWithin(it);      // ranges use the lower number
  if (cyc && cyc.on) { fields.cycle_on = cyc.on; fields.cycle_off = cyc.off; filled.push(`cycle ${fmtSpan(cyc.on)} on, ${fmtSpan(cyc.off)} off`); }
  if (uw) { fields.use_within_days = uw.days; filled.push(`use within ${uw.days} days once mixed`); }
  if (mixed.text) filled.push(mixed.text);
  const maxCycle = cyc && cyc.on ? null : sheetMaxCycle(it);
  const first = (it.dosage || "").split("\n").map(x => x.trim()).filter(x => x && !/reconstitut/i.test(x))[0];
  const an = analyzeSheet(it), found = parsePhases(it.dosage, fields.dose_unit);
  if (found.length) fields.dose = found[0].dose;
  const hint = (first ? `From your sheet: “${first}”. Other lines are in the Reference card after you save.` : "");
  return { fields, reference: it, openMore: true, hint, found, warn: an.warn, info: an.info, filled, maxCycle };
}

/* ---- the picker */
async function quickAddModal() {
  let items = (await api("/library")).filter(i => !((i.groups || []).length && (i.groups || []).every(g => g === "Diluents & Additives"))), q = "", grp = "";
  const groups = [...new Set(items.flatMap(i => i.groups || []))].sort();
  modal(`<h2>⚡ Quick add</h2>
    <p class="muted" style="margin-top:0">Pick one from your saved list. The Add form opens pre-filled and you choose vial or pen and your supplies.</p>
    <div class="row" style="gap:8px"><input id="qs" class="grow" placeholder="Search…" autocomplete="off"><button class="btn sm" id="qnew">+ New item</button></div>
    <div class="row wrap" id="qg" style="gap:6px;margin:10px 0"></div>
    <div id="ql" class="list" style="max-height:48vh;overflow:auto"></div>`, {
    onMount: (el, close) => {
      const draw = () => {
        $("#qg", el).innerHTML = ["", ...groups].map(g => `<button type="button" class="btn sm ${g === grp ? "primary" : ""}" data-g="${esc(g)}">${g ? esc(g) : "All"}</button>`).join("");
        $$("[data-g]", el).forEach(b => b.onclick = () => { grp = b.dataset.g; draw(); });
        const shown = items.filter(i => (!grp || (i.groups || []).includes(grp)) && (!q || (i.name + " " + (i.names || "")).toLowerCase().includes(q)));
        $("#ql", el).innerHTML = shown.length ? shown.map(i => `<div class="li" style="cursor:pointer" data-pick="${i.id}">
            <div class="grow"><div class="t">${esc(i.name)}</div><div class="m">${esc((i.groups || []).join(" · "))}${i.dosage ? " — " + esc(i.dosage.split("\n")[0].slice(0, 60)) : ""}</div></div>
            <button class="btn sm ghost" data-edit="${i.id}" title="Edit this saved item">✎</button></div>`).join("")
          : '<div class="empty small">Nothing matches. Use “+ New item” to add one.</div>';
        $$("[data-pick]", el).forEach(r => r.onclick = e => {
          if (e.target.closest("[data-edit]")) return;
          const it = items.find(x => x.id === +r.dataset.pick); close(); medForm(null, prefillFromItem(it));
        });
        $$("[data-edit]", el).forEach(b => b.onclick = e => { e.stopPropagation(); close(); libEditModal(items.find(x => x.id === +b.dataset.edit)); });
      };
      $("#qs", el).oninput = e => { q = e.target.value.trim().toLowerCase(); draw(); };
      $("#qnew", el).onclick = () => { close(); libEditModal(null); };
      draw(); $("#qs", el).focus();
    },
  });
}

/* ---- add / edit / delete a saved item */
function libEditModal(it, after) {
  const v = it || { name: "", groups: [] };
  modal(`<h2>${it ? "Edit" : "New"} quick-add item</h2>
    <form id="f" class="form-grid">
      <label class="f full">Name<input name="name" required value="${esc(v.name)}"></label>
      <label class="f full">Group(s) <span class="muted">(separate with commas)</span><input name="groups" value="${esc((v.groups || []).join(", "))}"></label>
      <label class="f full">Also known as<input name="names" value="${esc(v.names || "")}"></label>
      ${LIB_FIELDS.map(([k, l]) => `<label class="f full">${l}<textarea name="${k}" rows="${k === "dosage" || k === "notes" ? 3 : 2}">${esc(v[k] || "")}</textarea></label>`).join("")}
      <div class="actions full">${it ? '<button type="button" class="btn" id="del" style="margin-right:auto">Delete</button>' : ""}<button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div>
    </form>`, {
    wide: true,
    onMount: (el, close) => {
      const dl = $("textarea[name=dosage]", el).closest("label");
      dl.insertAdjacentHTML("afterend", '<div class="full" id="readout"></div>');
      const readout = () => {
        const f = Object.fromEntries(new FormData($("#f", el))), a = analyzeSheet({ ...f, groups: [] });
        const got = [];
        if (a.g.dose) got.push(`dose <b>${+(+a.g.dose).toFixed(4)} ${esc(a.g.dose_unit || "")}</b>`);
        if (a.g.route_type) got.push(`taken <b>${esc((App.routes[a.g.route_type] || {}).label || a.g.route_type)}</b>`);
        got.push(`schedule <b>${esc(a.g.schedule.type === "prn" ? "as needed" : a.g.schedule.type === "daily" ? ((a.g.schedule.times || []).length > 1 ? (a.g.schedule.times.length + " times a day") : "every day") : a.g.schedule.type === "weekdays" ? (a.g.schedule.days.length + " day(s) a week") : "every " + a.g.schedule.every + " days")}</b>`);
        if (a.cycle) got.push(`cycle <b>${fmtSpan(a.cycle.on)} on, ${fmtSpan(a.cycle.off)} off</b>`);
        if (a.maxc) got.push(`longest cycle <b>${fmtSpan(a.maxc.days)}</b>`);
        if (a.within) got.push(`use within <b>${a.within.days} days</b> once mixed`);
        $("#readout", el).innerHTML = `<div class="alert info" style="margin-top:2px"><b>📖 How the app reads this</b><div class="small" style="margin-top:4px">${got.join(" · ")}</div>
          ${a.steps.length ? `<div class="small" style="margin-top:4px">📈 ${a.steps.length} weekly steps: ${esc(stepSummary(a.steps, a.unit).join("  →  "))}</div>` : ""}
          ${a.info.map(x => `<div class="small muted" style="margin-top:4px">${esc(x)}</div>`).join("")}
          ${a.warn.map(x => `<div class="small err2" style="margin-top:4px">⚠ ${esc(x)}</div>`).join("")}</div>`;
      };
      $("#f", el).addEventListener("input", readout); readout();
      $("#f", el).onsubmit = async e => {
        e.preventDefault();
        const b = Object.fromEntries(new FormData(e.target)); b.groups = (b.groups || "").split(",").map(x => x.trim()).filter(Boolean);
        await run($(".primary", el), async () => {
          if (it) await api("/library/" + it.id, "PUT", b); else await api("/library", "POST", b);
          close(); toast("Saved"); after ? after() : quickAddModal();
        });
      };
      const d = $("#del", el);
      if (d) d.onclick = async () => { if (await confirmBox(`Remove ${it.name} from your quick-add list? Medications already added keep their info.`)) { await api("/library/" + it.id, "DELETE"); close(); toast("Removed"); after ? after() : quickAddModal(); } };
    },
  });
}

/* ---- browse every saved reference sheet (also reachable from Inventory and Medication) */
async function refBrowser(group) {
  const items = await api("/library"), groups = [...new Set(items.flatMap(i => i.groups || []))].sort();
  let q = "", grp = group || "";
  modal(`<h2>📖 Reference sheets</h2>
    <input id="rq" placeholder="Search…" autocomplete="off" style="width:100%">
    <div class="row wrap" id="rg" style="gap:6px;margin:10px 0"></div>
    <div id="rl" class="list" style="max-height:52vh;overflow:auto"></div>
    <div class="actions"><button type="button" class="btn sm" id="rnew2" style="margin-right:auto">+ New sheet</button><button type="button" class="btn" data-close>Close</button></div>`, {
    onMount: (el, close) => {
      const draw = () => {
        $("#rg", el).innerHTML = ["", ...groups].map(g => `<button type="button" class="btn sm ${g === grp ? "primary" : ""}" data-g="${esc(g)}">${g ? esc(g) : "All"}</button>`).join("");
        $$("[data-g]", el).forEach(b => b.onclick = () => { grp = b.dataset.g; draw(); });
        const shown = items.filter(i => (!grp || (i.groups || []).includes(grp)) && (!q || (i.name + " " + (i.names || "")).toLowerCase().includes(q)));
        $("#rl", el).innerHTML = shown.length ? shown.map(i => `<div class="li" style="cursor:pointer" data-s="${i.id}"><div class="grow"><b>${esc(i.name)}</b><div class="small muted">${esc((i.groups || []).join(" · "))}</div></div></div>`).join("") : '<div class="empty small">No sheets match.</div>';
        $$("[data-s]", el).forEach(r => r.onclick = () => { close(); refSheetModal(items.find(x => x.id === +r.dataset.s), () => refBrowser(grp)); });
      };
      $("#rq", el).oninput = e => { q = e.target.value.trim().toLowerCase(); draw(); };
      $("#rnew2", el).onclick = () => { close(); libEditModal(null, () => refBrowser(grp)); };
      draw(); $("#rq", el).focus();
    },
  });
}

function refSheetModal(it, back) {
  const rows = [["names", "Also known as"], ...LIB_FIELDS].filter(([k]) => it[k] && it[k].trim());
  const diluent = (it.groups || []).length && (it.groups || []).every(g => g === "Diluents & Additives");
  modal(`<h2>${esc(it.name)}</h2>
    <div class="row wrap" style="gap:6px;margin-bottom:10px">${(it.groups || []).map(g => `<span class="badge">${esc(g)}</span>`).join("")}</div>
    <dl class="kv ref" style="max-height:52vh;overflow:auto">${rows.map(([k, l]) => `<dt>${l}</dt><dd style="white-space:pre-line">${esc(it[k])}</dd>`).join("")}</dl>
    <p class="small muted" style="margin:8px 0 0">Information from your saved reference list, not advice.</p>
    <div class="actions"><button type="button" class="btn sm" id="redit" style="margin-right:auto">✎ Edit</button>${back ? '<button type="button" class="btn" id="rback">← Back</button>' : ""}
      <button type="button" class="btn" id="rinv">＋ Inventory</button>${diluent ? "" : '<button type="button" class="btn primary" id="rmed">＋ Add as medication</button>'}<button type="button" class="btn" data-close>Close</button></div>`, {
    wide: true,
    onMount: (el, close) => {
      $("#rinv", el).onclick = () => { close(); invAddFromRef(it); };
      const m = $("#rmed", el); if (m) m.onclick = () => { close(); medForm(null, prefillFromItem(it)); };
      $("#redit", el).onclick = () => { close(); libEditModal(it, () => { Router.render(); }); };
      const b = $("#rback", el); if (b) b.onclick = () => { close(); back(); };
    },
  });
}
