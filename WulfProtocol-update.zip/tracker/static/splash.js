/* Moonrise launch screen: shown on every full page load, hidden as soon as the app is ready (never trapping you). */
window.Splash = (function () {
  const el = document.getElementById("splash");
  if (!el) return { ready() {}, hide() {} };
  const reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const t0 = Date.now(), MIN = 900, MAX = 6000;
  let done = false;
  function hide() {
    if (done) return; done = true;
    el.setAttribute("aria-hidden", "true"); el.classList.add("out");
    setTimeout(() => el.remove(), reduce ? 0 : 400);
  }
  function ready() { setTimeout(hide, reduce ? 0 : Math.max(0, MIN - (Date.now() - t0))); }
  ["click", "touchstart"].forEach(e => el.addEventListener(e, hide, { once: true }));
  document.addEventListener("keydown", hide, { once: true });
  setTimeout(hide, MAX);                 // fail-safe: never hide the app behind the splash
  if (window.__appReady) ready();
  return { ready, hide };
})();
