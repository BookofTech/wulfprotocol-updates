var Pages = window.Pages || (window.Pages = {});
const PriceState = { q: "", attn: false, sel: new Map(), plannerOpen: false, open: new Set(), view: (() => { try { return localStorage.getItem("wp_price_view") === "list" ? "list" : "grid"; } catch (e) { return "grid"; } })() };
const SERIES_COLORS = ["#0e8a8c", "#e07a3f", "#b05fd0", "#2f7dd1", "#d9a521", "#d9534f", "#3aa675"];

/* Category dropdown: the usual categories + any you've used before + "New category…". Writes the chosen value into a hidden "category" field. */
const CATEGORIES_BASE = ["Peptides", "Medications", "Supplements", "Supplies", "Equipment", "Other"];
function catField(current, items) {
  const used = [...new Set([...CATEGORIES_BASE, ...items.map(i => i.category).filter(Boolean), ...(current ? [current] : [])])];
  return `<label class="f">Category<select data-cat><option value="">No category</option>${used.map(c => `<option ${c === current ? "selected" : ""}>${esc(c)}</option>`).join("")}<option value="__new__">➕ New category…</option></select>
    <input data-catnew placeholder="Type the new category" style="display:none;margin-top:6px"><input type="hidden" name="category" value="${esc(current || "")}"></label>`;
}
function bindCat(root) {
  const sel = $("[data-cat]", root); if (!sel) return;
  const nw = $("[data-catnew]", root), hid = $("input[name=category]", root);
  const sync = () => { const isNew = sel.value === "__new__"; nw.style.display = isNew ? "" : "none"; hid.value = isNew ? nw.value.trim() : sel.value; if (isNew) nw.focus(); };
  sel.onchange = sync; nw.oninput = () => { hid.value = nw.value.trim(); };
}

function deltaHtml(now, then, cur) {
  if (now == null || then == null || Math.abs(now - then) < 0.005) return "";
  const d = now - then;
  return `<span class="${d < 0 ? "down" : "up"}">${d < 0 ? "▼" : "▲"} ${money(Math.abs(d), cur)}</span> <span class="small muted">vs last week</span>`;
}

Pages.prices = async function (view) {
  const [items, stockEv] = await Promise.all([api("/items"), api("/stock-events").catch(() => [])]);
  PriceState.items = items;
  const q = PriceState.q.toLowerCase();
  const attn = items.flatMap(i => i.attention.map(a => ({ it: i, ...a })));
  if (!attn.length) PriceState.attn = false;
  const shown = items.filter(i => (!q || (i.name + " " + (i.category || "")).toLowerCase().includes(q)) && (!PriceState.attn || i.attention.length));
  view.innerHTML = `
    <div class="page-head"><div><h1>Price watch</h1><p>Track the same item across stores. Prices re-check automatically.</p></div>
      <div class="row"><input id="search" placeholder="Filter items…" value="${esc(PriceState.q)}" style="width:180px">
        <span class="seg" role="group" aria-label="View"><button type="button" data-view="grid" class="${PriceState.view === "grid" ? "on" : ""}" title="Grid view">▦ Grid</button><button type="button" data-view="list" class="${PriceState.view === "list" ? "on" : ""}" title="List view">☰ List</button></span><button class="btn" id="checkall">↻ Check all now</button><button class="btn" id="bulk" title="Add many links at once, or import a CSV file">⬆ Bulk add / import</button><button class="btn" id="sitesfile" title="Your stores are saved to a spreadsheet file in your data folder after every change">📁 Saved list</button></div></div>
    <div class="card" style="margin-bottom:18px">
      <form id="add"><div class="addbar"><input class="grow" name="url" type="url" required placeholder="Paste a product link and press Add…" autocomplete="off"><button class="btn primary">Add item</button></div>
        <details style="margin-top:10px"><summary class="small muted" style="cursor:pointer">More options (name, target price, category, sign-in)</summary>
          <div class="form-grid" style="margin-top:10px">
            <label class="f">Name (auto-detected if blank)<input name="name"></label>
            <label class="f">Alert when at or below<input name="target_price" type="number" step="0.01" placeholder="target price"></label>
            ${catField("", items)}
            <label class="chk full"><input type="checkbox" name="needs_login"> This page needs me to be signed in (opens a browser window once so you can log in yourself)</label>
          </div></details></form></div>
    ${stockCard(stockEv)}${attentionCard(attn)}
    ${items.length ? plannerCard(items) : ""}
    ${shown.length ? (PriceState.view === "list" ? `<div class="price-list">${shown.map(itemRow).join("")}</div>` : `<div class="price-grid">${shown.map(itemCard).join("")}</div>`) :
      `<div class="card empty"><b>${items.length ? "No matches" : "No items yet"}</b>${items.length ? "" : "Paste a product link above — the name, image and price are detected automatically."}</div>`}`;

  $$("[data-view]", view).forEach(b => b.onclick = () => { PriceState.view = b.dataset.view; try { localStorage.setItem("wp_price_view", PriceState.view); } catch (e) {} Router.render(); });
  $("#search", view).oninput = e => { PriceState.q = e.target.value; clearTimeout(PriceState.t); PriceState.t = setTimeout(() => { Router.render(); const s = $("#search"); s.focus(); s.setSelectionRange(99, 99); }, 250); };
  $("#checkall", view).onclick = async e => { await run(e.target, () => api("/check-all", "POST")); toast("Checking all prices in the background…"); setTimeout(() => Router.render(), 15000); };
  bindCat($("#add", view));
  $("#add", view).onsubmit = async e => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target)); f.needs_login = !!f.needs_login;
    if (f.needs_login && !App.settings.playwright) return toast("Install sign-in mode first (Settings → Price tracking)", true);
    const btn = $(".primary", e.target); btn.textContent = "Fetching…";
    await run(btn, async () => {
      const r = await api("/items", "POST", f);
      if (r.check && r.check.ok) toast("Added — " + money(r.check.price, r.check.currency));
      else toast("Added, but: " + ((r.check && r.check.error) || "no price found") + " — fix it on the card", true);
      Router.render();
    });
    btn.textContent = "Add item";
  };
  bindItemActions(view, items);
  bindAttention(view);
  bindStockCard(view);
  $("#bulk", view).onclick = () => bulkModal(items);
  $("#sitesfile", view).onclick = async () => {
    let f = {}; try { f = await api("/sites-file"); } catch (e) { return toast(e.message, true); }
    modal(`<h2>Your saved list of stores</h2>
      <p class="small" style="margin:0 0 10px">Every item and store link is saved to a spreadsheet file after each add, edit or delete — so if something is ever lost, you can see exactly which sites to add again.</p>
      <div class="card" style="padding:10px;margin-bottom:10px"><div class="small muted">Saved at</div><div style="word-break:break-all"><b>${esc(f.path || "")}</b></div></div>
      <p class="small muted" style="margin:0 0 10px">Open it in Excel any time. It also works with <b>Bulk add / import</b> to put the sites back.</p>
      <div class="actions"><button class="btn" data-close>Close</button><a class="btn primary" href="/api/sites-file/download" download>⬇ Download a copy</a></div>`);
  };
  if (items.length) bindPlanner(view, items);
};

function itemCard(it) {
  const b = it.best, bestSrc = b && it.sources.find(s => s.id === b.source_id);
  const hist = bestSrc ? bestSrc.history : [];
  return `<div class="card pitem" data-item="${it.id}">
    <div class="head">
      <div class="grow"><div class="row spread" style="align-items:flex-start"><b style="line-height:1.25">${esc(it.name)}</b>
        <span class="row" style="gap:2px"><button class="btn ghost sm" data-act="edit" title="Edit">✎</button><button class="btn ghost sm" data-act="del" title="Delete">✕</button></span></div>
        <div class="row wrap" style="margin-top:4px">${it.category ? `<span class="badge">${esc(it.category)}</span>` : ""}
          ${it.at_target ? '<span class="badge ok">🎯 at target</span>' : it.target_price ? `<span class="badge">target ${money(it.target_price, b?.currency)}</span>` : ""}
          ${b && b.is_lowest && bestSrc.history.length > 1 && !(it.trend && it.trend.low30) ? '<span class="badge acc">lowest seen</span>' : ""}${trendBadges(it)}</div></div></div>
    <div class="row spread"><div><div class="price">${b ? money(b.price, b.currency) : "–"}</div>
        <div class="small">${b ? `<span class="muted">at ${esc(b.site)}</span> ${deltaHtml(b.price, b.price_7d_ago, b.currency)}` : '<span class="muted">no price yet</span>'}</div></div>
      <a href="javascript:void 0" data-act="chart" title="Open price history">${Charts.spark(hist, "var(--accent)", 120, 40) || '<span class="small muted">history builds over time</span>'}</a></div>
    <div>${it.sources.map(s => srcRow(s, b)).join("")}</div>
    <div class="row wrap"><button class="btn sm" data-act="addsrc">+ Add another store</button><button class="btn sm" data-act="chart">Price history</button></div></div>`;
}

function itemRow(it) {
  const b = it.best, bestSrc = b && it.sources.find(s => s.id === b.source_id);
  const hist = bestSrc ? bestSrc.history : [], open = PriceState.open.has(it.id);
  return `<div class="card pitem prow" data-item="${it.id}">
    <div class="rmain">
      
      <div class="rname"><b>${esc(it.name)}</b>
        <div class="row wrap" style="margin-top:2px;gap:6px">${it.category ? `<span class="badge">${esc(it.category)}</span>` : ""}
          ${it.at_target ? '<span class="badge ok">🎯 at target</span>' : it.target_price ? `<span class="badge">target ${money(it.target_price, b?.currency)}</span>` : ""}
          ${b && b.is_lowest && bestSrc.history.length > 1 && !(it.trend && it.trend.low30) ? '<span class="badge acc">lowest seen</span>' : ""}${trendBadges(it)}
          <span class="small muted">${it.sources.length} store${it.sources.length === 1 ? "" : "s"}</span></div></div>
      <div class="rprice"><div class="price">${b ? money(b.price, b.currency) : "–"}</div>
        <div class="small">${b ? `<span class="muted">${esc(b.site)}</span> ${deltaHtml(b.price, b.price_7d_ago, b.currency)}` : '<span class="muted">no price yet</span>'}</div></div>
      <a class="rspark" href="javascript:void 0" data-act="chart" title="Open price history">${Charts.spark(hist, "var(--accent)", 90, 32) || ""}</a>
      <span class="row" style="gap:2px"><button class="btn ghost sm" data-act="expand" title="Show stores">${open ? "▾" : "▸"} Stores</button><button class="btn ghost sm" data-act="edit" title="Edit">✎</button><button class="btn ghost sm" data-act="del" title="Delete">✕</button></span></div>
    <div class="rsrc" ${open ? "" : "hidden"}>${it.sources.map(s => srcRow(s, b)).join("")}
      <div class="row wrap" style="margin-top:8px"><button class="btn sm" data-act="addsrc">+ Add another store</button><button class="btn sm" data-act="chart">Price history</button></div></div></div>`;
}

function trendBadges(it) {
  const t = it.trend; if (!t) return "";
  let h = "";
  if (t.low30) h += '<span class="badge acc" title="Cheapest price seen in the last 30 days">⭐ lowest in 30 days</span>';
  else if (t.high30) h += '<span class="badge warn" title="Most expensive price seen in the last 30 days">⬆ 30-day high</span>';
  if (t.pct_week != null && Math.abs(t.pct_week) >= 2) h += `<span class="badge ${t.pct_week < 0 ? "ok" : "bad"}" title="Change versus a week ago">${t.pct_week < 0 ? "▼" : "▲"} ${Math.abs(Math.round(t.pct_week))}% this week</span>`;
  return h;
}

const STATUS_FIX = { signin: ["login", "🔑 Sign in"], noprice: ["pick", "🎯 Pick the price"], error: ["check", "↻ Re-check"], stale: ["check", "↻ Check now"] };

function srcRow(s, b) {
  const isBest = b && b.source_id === s.id;
  return `<div class="src ${isBest ? "best" : ""}" data-src="${s.id}">
    <div class="grow"><i class="sdot ${s.status}" title="${esc(s.status === "ok" ? "Working" : s.status_msg)}"></i><a class="site" href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.site)}</a>
      ${s.needs_login ? ' <span class="badge" title="Uses your saved browser sign-in">🔒 sign-in</span>' : ""}${s.in_stock === 0 ? ' <span class="badge bad">out of stock</span>' : s.in_stock === 1 ? ' <span class="badge ok">in stock</span>' : ""}${s.stock_since ? ` <span class="small muted">since ${esc(fmtDate(s.stock_since.slice(0, 10)))}</span>` : ""}
      ${s.promo_note || s.promo ? `<div class="small"><span class="badge acc" title="${s.promo_note ? "Sale note you added" : "Spotted on the page during the last check (pop-up or banner). It is not included in the price."}">🏷 ${esc(s.promo_note || s.promo)}</span></div>` : ""}
      ${s.last_checked ? `<div class="small muted">checked ${rel(s.last_checked.slice(0, 16))}</div>` : ""}</div>
    <b>${s.last_price != null ? money(s.last_price, s.currency) : "–"}</b>
    <span class="row" style="gap:0"><button class="btn ghost sm" data-sact="check" title="Check now">↻</button>
      <button class="btn ghost sm" data-sact="open" title="Open this page in the browser you normally use (your saved logins and password manager work there)">🌐</button><button class="btn ghost sm" data-sact="login" title="Sign in inside the app's own window so it can read prices that need a login">🔑</button><button class="btn ghost sm" data-sact="pick" title="Wrong price? Open the page and click the price yourself">🎯</button><button class="btn ghost sm" data-sact="find" title="See every price found on the page and pick from a list">🔍</button><button class="btn ghost sm" data-sact="edit" title="Edit link">⚙</button><button class="btn ghost sm" data-sact="del" title="Remove store">✕</button></span>
    ${s.last_error ? `<div class="err">⚠ ${esc(s.last_error)}</div>` : ""}</div>`;
}

/* One-click fixes, shared by the store buttons and the Needs-attention list */
async function startLogin(sid, btn) {
  await run(btn, async () => {
    const open = () => api(`/sources/${sid}/login`, "POST");
    try { await open(); }
    catch (e) {
      if (!/already open/i.test(e.message)) throw e;
      if (!(await confirmBox("A browser window is already open. It may be hidden behind other windows, or stuck. Close it and open a fresh one?", "Close & reopen"))) return;
      await api("/login-window/close", "POST");
      for (let i = 0; ; i++) { await new Promise(r => setTimeout(r, 1500)); try { await open(); break; } catch (e2) { if (i >= 4 || !/already open/i.test(e2.message)) throw e2; } }
    }
    await api(`/sources/${sid}`, "PUT", { needs_login: true });
    toast("A browser window opened — sign in (tick “remember me” if it's offered), then close the window. I'll check the price for you and tell you if it worked.");
    watchLogin();
  });
}

async function startPick(sid, btn) {
  await run(btn, async () => {
    const open = () => api(`/sources/${sid}/pick`, "POST");
    try { await open(); }
    catch (e) {
      if (!/already open/i.test(e.message)) throw e;
      if (!(await confirmBox("A browser window is already open. It may be hidden behind other windows, or stuck. Close it and open a fresh one?", "Close & reopen"))) return;
      await api("/login-window/close", "POST");
      for (let i = 0; ; i++) { await new Promise(r => setTimeout(r, 1500)); try { await open(); break; } catch (e2) { if (i >= 4 || !/already open/i.test(e2.message)) throw e2; } }
    }
    toast("A browser window opened — choose the size/option you want if there is one, then CLICK THE PRICE. The window closes by itself.");
    watchLogin();
  });
}

async function recheck(sid, btn) {
  await run(btn, async () => { const r = await api(`/sources/${sid}/check`, "POST"); toast(r.ok ? "Updated — " + money(r.price, r.currency) : r.error, !r.ok); Router.render(); });
}

function attentionCard(attn) {
  if (!attn.length) return "";
  return `<div class="card attn" id="attn"><div class="row spread wrap"><b>⚠ ${attn.length} store${attn.length === 1 ? "" : "s"} need${attn.length === 1 ? "s" : ""} attention</b>
    <span class="row"><button class="btn sm ${PriceState.attn ? "primary" : ""}" id="attn-filter">${PriceState.attn ? "Showing only these — show all" : "Show only these items"}</button></span></div>
    ${attn.map(a => { const f = STATUS_FIX[a.status] || STATUS_FIX.error; return `<div class="src" data-fix="${a.source_id}"><div class="grow"><i class="sdot ${a.status}"></i><b>${esc(a.it.name.slice(0, 60))}</b> <span class="muted">· ${esc(a.site)}</span>
      <div class="small ${a.status === "stale" ? "muted" : "err2"}">${esc(a.msg.slice(0, 140))}</div></div>
      <button class="btn sm primary" data-fixact="${f[0]}">${f[1]}</button>${f[0] !== "pick" ? `<button class="btn sm" data-fixact="pick" title="Open the page and click the price yourself">🎯 Pick</button>` : "<span></span>"}</div>`; }).join("")}</div>`;
}

function bindAttention(view) {
  const f = $("#attn-filter", view); if (f) f.onclick = () => { PriceState.attn = !PriceState.attn; Router.render(); };
  $$("[data-fixact]", view).forEach(b => b.onclick = () => {
    const sid = +b.closest("[data-fix]").dataset.fix, a = b.dataset.fixact;
    if (a === "login") startLogin(sid, b); else if (a === "pick") startPick(sid, b); else recheck(sid, b);
  });
}

function stockCard(ev) {
  if (!ev.length) return "";
  return `<div class="card" id="stockcard"><div class="row spread wrap"><b>🔔 Stock changes</b><button class="btn sm" id="stock-clear">Dismiss all</button></div>
    ${ev.slice(0, 10).map(e => `<div class="src" data-ev="${e.id}"><div class="grow">${e.kind === "back_in_stock" ? "🟢" : "🔴"} <b>${esc(e.name.slice(0, 60))}</b>
      <span class="${e.kind === "back_in_stock" ? "down" : "up"}">${e.kind === "back_in_stock" ? "is back in stock" : "went out of stock"}</span> <span class="muted">at ${esc(e.site)}</span>
      <div class="small muted">${rel(e.ts.slice(0, 16))}${e.kind === "back_in_stock" && e.price != null ? " · " + money(e.price, e.currency) : ""}</div></div>
      ${e.kind === "back_in_stock" ? `<a class="btn sm" href="${esc(e.url)}" target="_blank" rel="noopener">Open store</a>` : "<span></span>"}<button class="btn ghost sm" data-evx title="Dismiss">✕</button></div>`).join("")}
    ${ev.length > 10 ? `<div class="small muted" style="margin-top:6px">+${ev.length - 10} more</div>` : ""}</div>`;
}

function bindStockCard(view) {
  const c = $("#stock-clear", view); if (!c) return;
  c.onclick = async () => { await api("/stock-events/seen", "POST", {}); Router.render(); };
  $$("[data-evx]", view).forEach(b => b.onclick = async () => { await api("/stock-events/seen", "POST", { ids: [+b.closest("[data-ev]").dataset.ev] }); Router.render(); });
}

function bindItemActions(view, items) {
  const find = id => items.find(i => i.id === +id);
  $$(".pitem", view).forEach(card => {
    const it = find(card.dataset.item);
    card.addEventListener("click", async e => {
      const a = e.target.closest("[data-act]"), sa = e.target.closest("[data-sact]");
      if (a) {
        const act = a.dataset.act;
        if (act === "del") { if (await confirmBox(`Stop tracking "${it.name}" and delete its price history?`)) { await api("/items/" + it.id, "DELETE"); Router.render(); } }
        if (act === "edit") itemModal(it);
        if (act === "addsrc") sourceModal(it);
        if (act === "chart") historyModal(it);
        if (act === "expand") {
          const box = $(".rsrc", card), o = box.hidden; box.hidden = !o;
          o ? PriceState.open.add(it.id) : PriceState.open.delete(it.id);
          a.textContent = (o ? "▾" : "▸") + " Stores";
        }
      }
      if (sa) {
        const sid = +sa.closest("[data-src]").dataset.src, s = it.sources.find(x => x.id === sid), act = sa.dataset.sact;
        if (act === "check") await run(sa, async () => { sa.textContent = "…"; const r = await api(`/sources/${sid}/check`, "POST"); toast(r.ok ? "Updated — " + money(r.price, r.currency) : r.error, !r.ok); Router.render(); });
        if (act === "del") { if (await confirmBox(`Remove ${s.site} from this item?`, "Remove")) { await api("/sources/" + sid, "DELETE"); Router.render(); } }
        if (act === "edit") sourceModal(it, s);
        if (act === "find") candidatesModal(it, s);
        if (act === "open") { try { const r = await api(`/sources/${sid}/open`, "POST"); if (!r.ok) throw 0; } catch (e) { window.open(s.url, "_blank", "noopener"); } }
        if (act === "login") await startLogin(sid, sa);
        if (act === "pick") await startPick(sid, sa);
      }
    });
  });
}

async function itemModal(it) {
  modal(`<h2>Edit item</h2><form id="f" class="form-grid">
    <label class="f full">Name<input name="name" value="${esc(it.name)}" required></label>
    ${catField(it.category || "", PriceState.items || [it])}
    <label class="f">Alert at or below<input type="number" step="0.01" name="target_price" value="${it.target_price ?? ""}"></label>
    <label class="f full">Image URL<input name="image" value="${esc(it.image || "")}"></label>
    <label class="f full">Notes<textarea name="notes">${esc(it.notes || "")}</textarea></label>
    <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div></form>`, {
    onMount: (el, close) => { bindCat(el); $("#f", el).onsubmit = async e => { e.preventDefault(); await run(null, async () => { await api("/items/" + it.id, "PUT", Object.fromEntries(new FormData(e.target))); close(); Router.render(); }); }; },
  });
}

function sourceModal(it, s) {
  modal(`<h2>${s ? "Edit store link" : "Add another store for " + esc(it.name)}</h2><form id="f" class="form-grid">
    <label class="f full">Product link<input type="url" name="url" required value="${esc(s?.url || "")}" placeholder="https://…"></label>
    <label class="chk full"><input type="checkbox" name="needs_login" ${s?.needs_login ? "checked" : ""}> Needs me to be signed in</label>
    ${s ? `<label class="f full">Sale note <span class="muted small">(optional — shown next to the price; leave blank to use what the app spots on the page)</span><input name="promo_note" value="${esc(s.promo_note || "")}" placeholder="e.g. 15% off with code SAVE15"></label>` : ""}
    ${s ? '<div class="full small muted">Getting the wrong price? Close this and press 🎯 on the store, then click the price on the page. Or press 🔍 to pick from a list.</div>' : ""}
    <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">${s ? "Save & re-check" : "Add & check"}</button></div></form>`, {
    onMount: (el, close) => $("#f", el).onsubmit = async e => {
      e.preventDefault();
      const f = Object.fromEntries(new FormData(e.target)); f.needs_login = !!f.needs_login;
      const btn = $(".primary", el), label = btn.textContent; btn.textContent = "Checking…";
      await run(btn, async () => {
        let r;
        if (s) { await api("/sources/" + s.id, "PUT", f); r = await api(`/sources/${s.id}/check`, "POST"); }
        else { const x = await api(`/items/${it.id}/sources`, "POST", f); r = x.check; }
        close(); toast(r && r.ok ? "Price found — " + money(r.price, r.currency) : (r && r.error) || "Saved", !(r && r.ok)); Router.render();
      });
      btn.textContent = label;
    },
  });
}

function historyModal(it) {
  const series = it.sources.map((s, i) => ({ name: s.site, color: SERIES_COLORS[i % SERIES_COLORS.length], points: s.history.map(([ts, p]) => [new Date(ts).getTime(), p]) }));
  const m = modal(`<div class="row" style="gap:12px;align-items:center;margin-bottom:8px"><h2 style="margin:0">${esc(it.name)}</h2></div><div class="chart-host" id="hc"></div>
    <div class="legend">${series.map(s => `<span><i style="background:${s.color}"></i>${esc(s.name)}</span>`).join("")}</div>
    <div class="scroll-x" style="margin-top:12px"><table><thead><tr><th>Store</th><th class="r">Now</th><th class="r">Lowest</th><th class="r">Highest</th></tr></thead><tbody>
      ${it.sources.map(s => `<tr><td>${esc(s.site)}</td><td class="r">${money(s.last_price, s.currency)}</td><td class="r">${money(s.low, s.currency)}</td><td class="r">${money(s.high, s.currency)}</td></tr>`).join("")}</tbody></table></div>
    <div class="actions"><button class="btn" data-close>Close</button></div>`, { wide: true });
  Charts.line($("#hc", m.el), series, { yFmt: v => money(v, it.sources[0]?.currency), height: 280 });
}


/* ================= Order planner ================= */
const shipGet = () => { try { return JSON.parse(localStorage.getItem("wp_ship") || "{}"); } catch (e) { return {}; } };
const shipSet = (site, v) => { try { const o = shipGet(); if (v > 0) o[site] = v; else delete o[site]; localStorage.setItem("wp_ship", JSON.stringify(o)); } catch (e) { /* ignore */ } };

function plannerCard(items) {
  return `<details class="card" id="planner" style="margin-bottom:18px" ${PriceState.plannerOpen ? "open" : ""}>
    <summary style="cursor:pointer;font-weight:700">🛒 Order planner <span class="small muted" style="font-weight:400">— pick what you need and see which store has it all, and for how much</span></summary>
    <div style="margin-top:12px"><div class="row spread wrap" style="margin-bottom:8px"><span class="small muted">Tick the items you need and set the quantity.</span>
      <span class="row"><button type="button" class="btn sm" id="pl-all">Select all</button><button type="button" class="btn sm" id="pl-none">Clear</button></span></div>
      <div class="pl-items">${items.map(it => { const q = PriceState.sel.get(it.id); return `<label class="pl-item ${q ? "on" : ""}" data-pl="${it.id}">
        <input type="checkbox" ${q ? "checked" : ""}><span class="grow">${esc(it.name)}</span>
        <input class="pl-qty" type="number" min="1" step="1" value="${q || 1}" title="Quantity" ${q ? "" : "disabled"}></label>`; }).join("")}</div>
      <div id="pl-out" style="margin-top:14px"></div></div></details>`;
}

function planOrder(items) {
  const chosen = items.filter(i => PriceState.sel.has(i.id)).map(i => ({ it: i, qty: PriceState.sel.get(i.id) }));
  const ship = shipGet(), sites = {}, noPrice = [];
  chosen.forEach(({ it, qty }) => {
    const ok = it.sources.filter(s => s.last_price != null && s.in_stock !== 0);
    if (!ok.length) noPrice.push(it.name);
    ok.forEach(s => {
      const cur = sites[s.site] = sites[s.site] || { site: s.site, offers: {}, currency: s.currency };
      const prev = cur.offers[it.id];
      if (!prev || s.last_price < prev.price) cur.offers[it.id] = { price: s.last_price, url: s.url, qty, name: it.name, currency: s.currency, low: s.low, stock: s.in_stock };
    });
  });
  const list = Object.values(sites).map(st => {
    const have = chosen.filter(c => st.offers[c.it.id]), missing = chosen.filter(c => !st.offers[c.it.id]).map(c => c.it.name);
    const sub = have.reduce((a, c) => a + st.offers[c.it.id].price * c.qty, 0), sh = ship[st.site] || 0;
    return { ...st, have, missing, sub, ship: sh, total: sub + (have.length ? sh : 0) };
  });
  const full = list.filter(s => !s.missing.length).sort((a, b) => a.total - b.total);
  const partial = list.filter(s => s.missing.length).sort((a, b) => b.have.length - a.have.length || a.total - b.total);
  // cheapest-per-item cart across all stores
  const split = {}; let splitSub = 0, splitMissing = [];
  chosen.forEach(c => {
    let best = null;
    list.forEach(st => { const o = st.offers[c.it.id]; if (o && (!best || o.price < best.o.price)) best = { st, o }; });
    if (!best) return splitMissing.push(c.it.name);
    (split[best.st.site] = split[best.st.site] || { site: best.st.site, lines: [] }).lines.push({ c, o: best.o });
    splitSub += best.o.price * c.qty;
  });
  const splitShip = Object.keys(split).reduce((a, k) => a + (ship[k] || 0), 0);
  return { chosen, full, partial, split: Object.values(split), splitTotal: splitSub + splitShip, splitSub, splitShip, noPrice };
}

function priceTag(o) {
  if (o.low == null || !(o.low > 0)) return "";
  const pct = (o.price - o.low) / o.low * 100;
  return pct <= 0.5 ? '<span class="badge ok">lowest seen</span>' : pct <= 5 ? '<span class="badge">near its low</span>' : `<span class="badge bad">${Math.round(pct)}% above its low</span>`;
}
const stockTag = o => o.stock === 1 ? '<span class="badge ok">in stock</span>' : '<span class="badge">stock unknown</span>';

function bindPlanner(view, items) {
  const box = $("#planner", view), out = $("#pl-out", view);
  box.addEventListener("toggle", () => { PriceState.plannerOpen = box.open; });
  const cur = items.flatMap(i => i.sources.map(s => s.currency)).find(Boolean);
  const m = v => money(v, cur);
  function show() {
    const r = planOrder(items);
    if (!r.chosen.length) { out.innerHTML = '<div class="muted small">Nothing selected yet.</div>'; return; }
    let h = "";
    if (r.noPrice.length) h += `<div class="err small" style="margin-bottom:8px">⚠ No in-stock price yet for: ${r.noPrice.map(esc).join(", ")} — they can't be included until a store has a price.</div>`;
    const bestFull = r.full[0];
    const allStockKnown = bestFull && bestFull.have.every(c => bestFull.offers[c.it.id].stock === 1);
    if (bestFull) h += `<div class="pl-rec"><div class="small muted">Best option</div><div class="row spread wrap"><b style="font-size:1.25rem">${esc(bestFull.site)}</b><b style="font-size:1.25rem">${m(bestFull.total)}</b></div>
      <div class="small">Has all ${r.chosen.length} item${r.chosen.length === 1 ? "" : "s"} ${allStockKnown ? "in stock" : "(in stock where the store reports it)"} at the lowest combined price${bestFull.have.every(c => { const o = bestFull.offers[c.it.id]; return o.low > 0 && o.price <= o.low * 1.05; }) ? ", and every price is at or near its lowest seen" : ""}. Open the links below to buy it yourself — nothing is ordered from here.</div>
      <div class="row" style="margin-top:8px"><button type="button" class="btn sm primary" data-ofull="0">📦 I ordered these — mark as ordered</button></div></div>`;
    else if (r.partial.length || r.split.length) h += `<div class="pl-rec"><div class="small muted">Best option</div><div><b>No single store has everything in stock.</b></div><div class="small">The best split and closest stores are below. Nothing is ordered from here.</div></div>`;
    if (r.full.length) {
      h += `<h3 style="margin:12px 0 8px">✅ Stores that have everything</h3>
        <div class="scroll-x"><table><thead><tr><th>Store</th><th class="r">Items</th><th class="r">Shipping</th><th class="r">Total</th></tr></thead><tbody>
        ${r.full.map((s, i) => `<tr><td><b>${esc(s.site)}</b> ${i === 0 ? '<span class="badge ok">cheapest</span>' : `<span class="small muted">+${m(s.total - bestFull.total)}</span>`} <button type="button" class="btn sm" data-ofull="${i}">Mark as ordered</button>
          <div class="small">${s.have.map(c => { const o = s.offers[c.it.id]; return `<div class="row" style="gap:6px;flex-wrap:wrap">${c.qty > 1 ? c.qty + "× " : ""}<a href="${esc(o.url)}" target="_blank" rel="noopener">${esc(c.it.name)}</a> — ${m(o.price)} ${stockTag(o)} ${priceTag(o)}</div>`; }).join("")}</div></td>
          <td class="r">${m(s.sub)}</td><td class="r"><input class="pl-ship" data-site="${esc(s.site)}" type="number" min="0" step="0.01" placeholder="0" value="${s.ship || ""}" title="Shipping cost for ${esc(s.site)} (optional)"></td>
          <td class="r"><b>${m(s.total)}</b></td></tr>`).join("")}</tbody></table></div>`;
    } else {
      h += `<div class="card" style="background:var(--bg);margin-bottom:10px"><b>No single store has everything you picked.</b><div class="small muted">See the closest stores and the best split order below.</div></div>`;
    }
    if (r.split.length > 1 || !r.full.length) {
      const diff = bestFull ? r.splitTotal - bestFull.total : null;
      h += `<h3 style="margin:16px 0 8px">💸 Best price per item (split across stores)</h3>
        ${r.split.map((g, gi) => `<div class="src"><div class="grow"><b>${esc(g.site)}</b> <button type="button" class="btn sm" data-osplit="${gi}">Mark as ordered</button><div class="small">${g.lines.map(l => `<div class="row" style="gap:6px;flex-wrap:wrap">${l.c.qty > 1 ? l.c.qty + "× " : ""}<a href="${esc(l.o.url)}" target="_blank" rel="noopener">${esc(l.c.it.name)}</a> — ${m(l.o.price)} ${stockTag(l.o)} ${priceTag(l.o)}</div>`).join("")}</div></div>
          <span>${m(g.lines.reduce((a, l) => a + l.o.price * l.c.qty, 0))}</span><span class="small muted">${shipGet()[g.site] ? "+ " + m(shipGet()[g.site]) + " ship" : ""}</span></div>`).join("")}
        <div class="row spread" style="margin-top:8px"><b>Total across ${r.split.length} store${r.split.length === 1 ? "" : "s"}</b><b>${m(r.splitTotal)}</b></div>
        ${diff == null ? "" : diff < -0.004 ? `<div class="small"><span class="down">▼ ${m(-diff)} cheaper</span> than the best single store, but means ${r.split.length} separate orders.</div>`
          : `<div class="small muted">The single store above is ${diff > 0.004 ? m(diff) + " cheaper" : "the same price"} and only one order.</div>`}`;
    }
    if (!r.full.length && r.partial.length) {
      h += `<h3 style="margin:16px 0 8px">Closest single stores</h3>${r.partial.slice(0, 4).map(s => `<div class="src"><div class="grow"><b>${esc(s.site)}</b> <span class="small muted">has ${s.have.length} of ${r.chosen.length}</span>
        <div class="small muted">missing: ${s.missing.map(esc).join(", ")}</div></div><b>${m(s.total)}</b><span></span></div>`).join("")}`;
    }
    if (!r.full.length && !r.partial.length) h += '<div class="muted small">None of the selected items has a current price.</div>';
    h += '<p class="small muted" style="margin-top:10px">Only counts listings that are not marked out of stock, using the latest checked prices; "lowest seen" compares to the price history this app has recorded. Shipping is optional: type it in per store and it\'s remembered.</p>';
    out.innerHTML = h;
    const linesFor = (site, rows) => rows.map(x => ({ price_item_id: x.c.it.id, name: x.c.it.name, qty: x.c.qty, unit_price: x.o.price, url: x.o.url, currency: x.o.currency, site }));
    $$("[data-ofull]", out).forEach(b => b.onclick = () => { const s = r.full[+b.dataset.ofull]; orderModal(s.site, linesFor(s.site, s.have.map(c => ({ c, o: s.offers[c.it.id] })))); });
    $$("[data-osplit]", out).forEach(b => b.onclick = () => { const g = r.split[+b.dataset.osplit]; orderModal(g.site, linesFor(g.site, g.lines)); });
    $$(".pl-ship", out).forEach(i => i.onchange = () => { shipSet(i.dataset.site, parseFloat(i.value) || 0); show(); });
  }
  $$(".pl-item", box).forEach(row => {
    const id = +row.dataset.pl, cb = $("input[type=checkbox]", row), q = $(".pl-qty", row);
    cb.onchange = () => { q.disabled = !cb.checked; row.classList.toggle("on", cb.checked); cb.checked ? PriceState.sel.set(id, Math.max(1, parseInt(q.value) || 1)) : PriceState.sel.delete(id); show(); };
    q.oninput = () => { if (cb.checked) { PriceState.sel.set(id, Math.max(1, parseInt(q.value) || 1)); show(); } };
  });
  $("#pl-all", box).onclick = () => { items.forEach(i => PriceState.sel.set(i.id, PriceState.sel.get(i.id) || 1)); PriceState.plannerOpen = true; Router.render(); };
  $("#pl-none", box).onclick = () => { PriceState.sel.clear(); PriceState.plannerOpen = true; Router.render(); };
  show();
}

/* "I ordered these": records the order in Inventory → On order. Nothing is bought from here. */
async function orderModal(site, lines) {
  const open = await api("/orders").then(r => r.open).catch(() => []);
  const dup = lines.filter(l => open.some(o => o.price_item_id === l.price_item_id));
  const cur = lines.find(l => l.currency)?.currency;
  const m = modal(`<h2>Mark as ordered</h2><p class="muted small" style="margin:0 0 10px">This only saves a note in your Inventory so you can tick it off when it arrives. Nothing is ordered from this app. Change anything that differs from what you actually paid.</p>
    <form id="f" class="form-grid">
      <label class="f">Store<input name="site" value="${esc(site)}" required></label>
      <label class="f">Expected by <span class="muted">(optional)</span><input type="date" name="expected_by"></label>
      <div class="full">${lines.map((l, i) => `<div class="row" style="gap:8px;padding:6px 0;border-top:1px solid var(--line)">
        <label class="chk grow"><input type="checkbox" data-i="${i}" checked> ${esc(l.name)}${open.some(o => o.price_item_id === l.price_item_id) ? ' <span class="badge warn">already on order</span>' : ""}</label>
        <input type="number" min="1" step="1" data-q="${i}" value="${l.qty}" style="width:70px" title="Quantity"><span class="small muted">×</span>
        <input type="number" min="0" step="0.01" data-p="${i}" value="${l.unit_price ?? ""}" style="width:90px" title="Price each (${esc(cur || "")})"></div>`).join("")}</div>
      ${dup.length ? `<div class="small full" style="color:var(--warn)">⚠ ${dup.map(d => esc(d.name)).join(", ")} ${dup.length === 1 ? "is" : "are"} already on order. Untick ${dup.length === 1 ? "it" : "them"} if this would be a duplicate.</div>` : ""}
      <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save order</button></div></form>`, {
    onMount: (el, close) => $("#f", el).onsubmit = async e => {
      e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
      const picked = $$("[data-i]:checked", el).map(c => { const i = +c.dataset.i; return { ...lines[i], site: f.site.trim() || site, qty: parseFloat($(`[data-q="${i}"]`, el).value) || 0, unit_price: $(`[data-p="${i}"]`, el).value }; }).filter(l => l.qty > 0);
      if (!picked.length) return toast("Tick at least one item", true);
      await run($(".primary", el), async () => {
        await api("/orders", "POST", { lines: picked, expected_by: f.expected_by || null });
        picked.forEach(l => PriceState.sel.delete(l.price_item_id)); close();
        toast(`Saved — ${picked.length} item${picked.length === 1 ? "" : "s"} now under Inventory → On order`); Router.render();
      });
    },
  });
}

/* After a sign-in window opens: wait for it to close, then report whether the price could be read (= the sign-in worked). */
async function watchLogin() {
  for (let i = 0; i < 700; i++) {
    await new Promise(r => setTimeout(r, 2000));
    let s; try { s = await api("/login-window/status"); } catch (e) { return; }
    if (s.state === "error") return toast("Couldn't open the browser: " + s.error, true);
    if (s.state === "idle" && s.result) {
      const r = s.result;
      if (r.mode === "pick") {
        if (r.cancelled) toast("Cancelled — nothing was changed.");
        else if (r.ok) toast(`Price saved ✓ — ${money(r.price, r.currency)}${r.url_updated ? " (using the option you chose)" : ""}${r.browser ? " · this store is read with your browser" : ""}`);
        else toast(r.error || "Couldn't save that price", true);
      } else toast(r.ok ? `Sign-in saved ✓ — price found: ${money(r.price, r.currency)}` : `Checked after sign-in, but: ${r.error || "no price found"}`, !r.ok);
      if (location.hash.startsWith("#/prices")) Router.render();
      return;
    }
  }
}

/* Wrong price? Show every price found on the page and let the person pick the right one. */
async function candidatesModal(it, s) {
  const m = modal(`<h2>Find the right price</h2><p class="muted small" style="margin:0 0 10px">${esc(s.site)} — ${esc(it.name)}</p><div id="cand"><div class="muted">Loading the page${s.needs_login ? " in your browser (this can take ~15 seconds)" : ""}…</div></div>
    <div class="actions"><button class="btn" data-close>Close</button></div>`, { wide: true });
  let r;
  try { r = await api(`/sources/${s.id}/candidates`, "POST"); }
  catch (e) { $("#cand", m.el).innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; return; }
  const cur = it.sources.find(x => x.id === s.id)?.currency;
  const rows = r.candidates.map((c, i) => `<div class="li" style="align-items:flex-start">
      <div style="min-width:120px"><b style="font-size:1.1rem">${money(c.price, cur)}</b>${c.current ? '<div class="badge acc" style="margin-top:2px">in use now</div>' : ""}</div>
      <div class="grow"><div class="small"><b>${esc(c.where)}</b>${c.text ? ` — “${esc(c.text)}”` : ""}</div>
        ${c.note ? `<div class="small muted">${esc(c.note)}</div>` : ""}</div>
      ${c.selector ? `<button class="btn sm primary" data-pick="${i}">Use this</button>` : ""}</div>`).join("");
  $("#cand", m.el).innerHTML = `<div class="row spread wrap" style="margin-bottom:10px"><span class="small muted">Easier: open the page and click the price yourself.</span><button class="btn sm primary" id="cand-pick">🎯 Point &amp; click instead</button></div>` + (r.signed_out ? '<div class="alert" style="margin-bottom:8px">The page looks signed out, so prices may be placeholders. Press the 🔑 and sign in first.</div>' : "")
    + (r.current != null ? `<div class="small" style="margin-bottom:8px">Currently reading <b>${money(r.current, cur)}</b>${r.selector ? ` from the spot you picked earlier` : " automatically"}. Pick the price that matches what you see on the page:</div>` : '<div class="small" style="margin-bottom:8px">No price could be read automatically. Pick one below if it is listed:</div>')
    + (rows ? `<div class="list">${rows}</div>` : '<div class="empty small">No price-like values were found on the page. It may be signed out, or the price loads late. Try the 🔑 sign-in, or press 🎯 and click the price on the page yourself.</div>')
    + `<p class="small muted" style="margin-top:10px">“Use this” remembers that spot on the page as the price for this store. Prices marked as old / crossed-out are usually not what you pay.</p>`;
  $("#cand-pick", m.el).onclick = () => { m.close(); startPick(s.id, null); };
  $$("[data-pick]", m.el).forEach(b => b.onclick = async () => {
    const c = r.candidates[+b.dataset.pick];
    await run(b, async () => {
      await api("/sources/" + s.id, "PUT", { selector: c.selector });
      const x = await api(`/sources/${s.id}/check`, "POST");
      m.close(); toast(x.ok ? "Saved — price is now " + money(x.price, x.currency) : (x.error || "Saved, but couldn't re-read the price"), !x.ok); Router.render();
    });
  });
}

/* ================= Bulk add / CSV import ================= */
function parseCsv(text) {
  const rows = []; let row = [], cur = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; }
    else if (c === '"') q = true;
    else if (c === "," || c === "\t") { row.push(cur); cur = ""; }
    else if (c === "\n" || c === "\r") { if (c === "\r" && text[i + 1] === "\n") i++; row.push(cur); cur = ""; if (row.some(x => x.trim())) rows.push(row); row = []; }
    else cur += c;
  }
  row.push(cur); if (row.some(x => x.trim())) rows.push(row);
  return rows.map(r => r.map(x => x.trim()));
}

/* Accepts: one link per line, "Name | link", "link | Name", or a CSV (with or without a header row). */
function parseBulk(text) {
  const isUrl = v => /^https?:\/\//i.test(v || "");
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  if (!lines.length) return [];
  const grid = lines.some(l => l.includes("|")) ? lines.map(l => l.includes("|") ? l.split("|").map(x => x.trim()) : (parseCsv(l)[0] || [])) : parseCsv(text);
  const head = grid[0].map(h => h.toLowerCase().replace(/[^a-z]/g, ""));
  const hasHead = !grid[0].some(isUrl) && head.some(h => /^(name|item|product|title|url|link|href|category|target|targetprice|alert|needslogin|login|signin)/.test(h));
  const col = (re) => head.findIndex(h => re.test(h));
  const ix = hasHead ? { name: col(/^(name|item|product|title)/), url: col(/^(url|link|href|producturl|storeurl)/), cat: col(/^category/), tp: col(/^(target|alert)/), nl: col(/^(needslogin|login|signin)/) } : null;
  return (hasHead ? grid.slice(1) : grid).map(r => {
    if (ix) return { name: ix.name >= 0 ? r[ix.name] || "" : "", url: ix.url >= 0 ? r[ix.url] || "" : r.find(isUrl) || "", category: ix.cat >= 0 ? r[ix.cat] || "" : "", target_price: ix.tp >= 0 ? r[ix.tp] || "" : "", needs_login: ix.nl >= 0 ? r[ix.nl] || "" : "" };
    const url = r.find(isUrl) || r[0] || "", name = r.find(v => v && v !== url && !isUrl(v)) || "";
    return { name, url, category: "", target_price: "", needs_login: "" };
  });
}

function bulkModal(items) {
  let rows = [];
  const m = modal(`<h2>Bulk add / import</h2>
    <p class="muted small" style="margin:0 0 10px">Paste product links (one per line), or load a CSV file. Rows with the same name become extra stores for one item, and links you already track are skipped.</p>
    <div class="row wrap" style="margin-bottom:8px"><label class="btn sm" style="cursor:pointer">📄 Choose CSV file<input type="file" id="bf" accept=".csv,.txt,text/csv,text/plain" hidden></label>
      <a href="#" id="btpl" class="small">Download a template</a></div>
    <textarea id="bt" rows="7" style="width:100%" placeholder="https://store-a.com/bpc-157&#10;https://store-b.com/bpc-157&#10;BPC-157 5mg | https://store-c.com/bpc-157&#10;&#10;Or paste CSV rows: name,url,category,target_price"></textarea>
    <div id="bprev" class="small muted" style="margin:10px 0">Nothing yet.</div>
    <div class="actions"><button class="btn" data-close>Close</button><button class="btn primary" id="bgo" disabled>Add</button></div>`, { wide: true });
  const el = m.el, ta = $("#bt", el), prev = $("#bprev", el), go = $("#bgo", el);
  const show = () => {
    rows = parseBulk(ta.value);
    const good = rows.filter(r => /^https?:\/\//i.test(r.url)), bad = rows.length - good.length;
    go.disabled = !good.length; go.textContent = good.length ? `Add ${good.length} link${good.length === 1 ? "" : "s"}` : "Add";
    prev.innerHTML = !rows.length ? "Nothing yet." : `<b>${good.length}</b> link${good.length === 1 ? "" : "s"} ready${bad ? ` · <span class="err2">${bad} row${bad === 1 ? "" : "s"} without a valid link will be skipped</span>` : ""}
      <div class="scroll-x" style="max-height:170px;overflow:auto;margin-top:6px"><table><thead><tr><th>Name</th><th>Link</th><th>Category</th><th>Target</th></tr></thead><tbody>${rows.slice(0, 40).map(r => `<tr><td>${esc(r.name) || '<span class="muted">auto</span>'}</td><td class="small">${esc((r.url || "").slice(0, 60))}</td><td>${esc(r.category)}</td><td>${esc(r.target_price)}</td></tr>`).join("")}</tbody></table></div>${rows.length > 40 ? `<div class="small muted">…and ${rows.length - 40} more</div>` : ""}`;
  };
  ta.oninput = show;
  $("#bf", el).onchange = async e => { const f = e.target.files[0]; if (!f) return; ta.value = await f.text(); show(); };
  $("#btpl", el).onclick = e => {
    e.preventDefault();
    const blob = new Blob(["name,url,category,target_price,needs_login\nBPC-157 5mg,https://example.com/bpc-157,Peptides,15.00,\nBPC-157 5mg,https://another-store.com/bpc-157,Peptides,,\n"], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "price-watch-template.csv"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  };
  go.onclick = async () => {
    if (App.settings && rows.some(r => /^(1|true|yes|y|x)$/i.test(r.needs_login || "")) && !App.settings.playwright) return toast("Some rows need sign-in mode — install it first (Settings → Price tracking), or remove that column", true);
    go.disabled = true; ta.disabled = true;
    let j;
    try { j = await api("/items/bulk", "POST", { rows }); } catch (e) { toast(e.message, true); go.disabled = false; ta.disabled = false; return; }
    const draw = j => {
      const okN = j.results.filter(r => r.ok).length, badN = j.results.length - okN;
      prev.innerHTML = `<div class="small"><b>${j.finished ? "Done" : "Adding…"}</b> ${j.done} of ${j.total} checked · ${okN} priced${badN ? ` · <span class="err2">${badN} need attention</span>` : ""}</div>
        <div style="height:8px;background:var(--bg);border-radius:99px;margin:8px 0;overflow:hidden"><div style="height:100%;width:${j.total ? Math.round(100 * j.done / j.total) : 100}%;background:var(--accent)"></div></div>
        ${j.skipped.length ? `<div class="small muted">Skipped: ${j.skipped.slice(0, 6).map(s => esc(String(s.row).slice(0, 40)) + " (" + esc(s.why) + ")").join("; ")}${j.skipped.length > 6 ? "…" : ""}</div>` : ""}
        ${j.finished && badN ? '<div class="small muted">Stores that couldn\'t be read are listed under “needs attention” — use 🎯 to click the price yourself.</div>' : ""}`;
    };
    const job = j.job; draw(j);
    while (!j.finished) { await new Promise(r => setTimeout(r, 1500)); try { j = await api("/items/bulk/" + job); } catch (e) { break; } draw(j); }
    go.textContent = "Done"; go.disabled = false; go.onclick = () => { m.close(); Router.render(); };
    if (location.hash.startsWith("#/prices")) Router.render();
  };
}
