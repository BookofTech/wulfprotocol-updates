/* Inventory: vials, peptides and supplies on hand. Supplies linked to a medication are used up automatically as you log doses. */
var Pages = window.Pages || (window.Pages = {});
const invLS = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } };
const InvState = { cat: "All", q: "", only: "",
  sort: invLS("wp_inv_sort") || (invLS("wp_inv_az") === "1" ? "az" : "cat"),          // cat | az | low | exp (each person's choice is remembered)
  view: invLS("wp_inv_view") || "cards" };                                              // cards | list
const INV_ICON = { "Peptides & vials": "🧪", Medications: "💊", Supplies: "🩹", Other: "📦", Anabolics: "💪", Analgesics: "💊", Cosmetic: "✨", "Diluents & Additives": "💧",
  "Fat Burning": "🔥", Immune: "🛡️", Nootropics: "🧠", "Post-Cycle Therapy (PCT)": "🔄", "Sexual Health": "❤️", "Tissue Growth & Repair": "🧬", Canine: "🐕" };
const isVialCat = c => (InvState.vial || []).includes(c);
const refMatch = name => {                                      // the saved reference sheet whose name appears in this item's name (longest match wins)
  const n = (name || "").toLowerCase();
  return (InvState.lib || []).filter(r => n.includes(r.name.toLowerCase().replace(/ \(.*\)$/, ""))).sort((a, b) => b.name.length - a.name.length)[0] || null;
};
const invFlag = f => ({ out: '<span class="badge bad">out of stock</span>', low: '<span class="badge warn">low</span>', expiring: '<span class="badge warn">expiring soon</span>', expired: '<span class="badge bad">expired</span>', late: '<span class="badge warn">order is late</span>' }[f] || "");
const invQty = v => num(v, 2);
const isCart = i => /cartridge|pen/i.test(`${i.unit || ""} ${i.name || ""}`);
const INV_ONLY = { low: i => i.flags.includes("low") || i.flags.includes("out"), exp: i => i.flags.includes("expiring") || i.flags.includes("expired") };
const invByName = (a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" });
const INV_SORT = {
  az: invByName,
  low: (a, b) => {                                              // out of stock, then low, then the rest; closest to its alert amount first
    const rank = i => i.flags.includes("out") ? 0 : i.flags.includes("low") ? 1 : 2;
    const ratio = i => i.low_at > 0 ? i.qty / i.low_at : Infinity;
    return rank(a) - rank(b) || ratio(a) - ratio(b) || invByName(a, b);
  },
  exp: (a, b) => (a.expiry_in ?? Infinity) - (b.expiry_in ?? Infinity) || invByName(a, b),
};

Pages.inventory = async function (view) {
  const [D, lib] = await Promise.all([api("/inventory"), api("/library").catch(() => [])]);
  InvState.lib = lib; InvState.vial = D.vial_categories || [];
  const S = D.summary, q = InvState.q.toLowerCase();
  const cats = ["All", ...D.categories.filter(c => D.items.some(i => i.category === c))];
  if (!cats.includes(InvState.cat)) InvState.cat = "All";
  if (!["cat", "az", "low", "exp"].includes(InvState.sort)) InvState.sort = "cat";
  const shown = D.items.filter(i => (InvState.cat === "All" || i.category === InvState.cat) && (!InvState.only || INV_ONLY[InvState.only](i))
    && (!q || (i.name + " " + (i.size || "") + " " + (i.location || "")).toLowerCase().includes(q)));
  const groups = InvState.sort !== "cat"    // one sorted list; or under category headings (A–Z inside each)
    ? (shown.length ? [[null, [...shown].sort(INV_SORT[InvState.sort])]] : [])
    : D.categories.map(c => [c, shown.filter(i => i.category === c).sort(invByName)]).filter(g => g[1].length);
  const reorder = D.items.filter(i => (i.flags.includes("low") || i.flags.includes("out")) && i.price_item_id);
  const tile = (only, cls, inner) => `<button type="button" class="tile pick ${cls} ${InvState.only === only && only ? "on" : ""}" data-only="${only}" aria-pressed="${InvState.only === only && !!only}">${inner}</button>`;
  const list = l => InvState.view === "list" ? `<div class="card inv-list">${l.map(invRow).join("")}</div>` : `<div class="grid inv-grid">${l.map(invCard).join("")}</div>`;

  view.innerHTML = `
    <div class="page-head"><div><h1>Inventory</h1><p>What you have on hand: vials, peptides and the supplies that go with them.</p></div>
      <div class="row wrap"><input id="isearch" placeholder="Search…" value="${esc(InvState.q)}" style="width:160px"><button class="btn" id="iref">📖 Reference</button><button class="btn primary" id="iadd">+ Add item</button></div></div>
    ${D.items.length ? `<div class="grid tiles inv-tiles">
      ${tile("", "", `<div class="k">Items tracked</div><div class="v">${S.count}</div><div class="s">${InvState.only ? "tap to show all" : "all shown"}</div>`)}
      ${tile("low", S.low + S.out ? "warn" : "ok", `<div class="k">Low or out</div><div class="v">${S.low + S.out}</div><div class="s">${InvState.only === "low" ? "showing only these · tap to show all" : S.out ? S.out + " out of stock · tap to show" : S.low ? "running low · tap to show" : "all stocked"}</div>`)}
      ${tile("exp", S.expired ? "bad" : S.expiring ? "warn" : "ok", `<div class="k">Expiring</div><div class="v">${S.expired + S.expiring}</div><div class="s">${InvState.only === "exp" ? "showing only these · tap to show all" : (S.expired ? S.expired + " expired · " : "") + "within 30 days"}</div>`)}
      ${S.on_order ? `<div class="tile ${S.late ? "warn" : ""}"><div class="k">On order</div><div class="v">${S.on_order}</div><div class="s">${S.late ? S.late + " late" : "waiting to arrive"}</div></div>` : ""}
    </div>
    <div class="row spread wrap inv-bar"><div class="seg" id="icats">${cats.map(c => `<button data-c="${esc(c)}" class="${c === InvState.cat ? "on" : ""}">${esc(c)}</button>`).join("")}</div>
      <span class="row wrap" style="gap:8px">
        <label class="inv-sort small muted">Sort <select id="isort" aria-label="Sort items">${[["cat", "By category"], ["az", "A–Z"], ["low", "Lowest first"], ["exp", "Expiring first"]].map(([v, t]) => `<option value="${v}" ${v === InvState.sort ? "selected" : ""}>${t}</option>`).join("")}</select></label>
        <span class="seg" id="iview" role="group" aria-label="Show items as"><button data-v="cards" class="${InvState.view === "list" ? "" : "on"}" title="Cards">▦ Cards</button><button data-v="list" class="${InvState.view === "list" ? "on" : ""}" title="Slim list">☰ List</button></span>
        ${S.low + S.out + S.expired ? `<button class="btn" id="ishop">🖨 Shopping list</button>` : ""}${S.low + S.out ? `<button class="btn" id="ireorder">🛒 Plan reorder for low items</button>` : ""}</span></div>` : `<div class="card empty"><b>Nothing here yet</b>Add your vials, peptides and supplies (syringes, needles, swabs, bacteriostatic water…) to see what's on hand, what's running low and what's about to expire.<br><br>
      <button class="btn primary" id="iadd2">+ Add your first item</button></div>`}
    ${refPanel(lib)}
    ${ordersSection(D)}
    ${groups.map(([c, l]) => `${c ? `<h2 style="margin:18px 0 10px">${INV_ICON[c] || "📦"} ${esc(c)} <span class="small muted" style="font-weight:400">${l.length}</span></h2>` : `<div style="height:6px"></div>`}${list(l)}`).join("")}
    ${D.items.length && !shown.length ? `<div class="card empty small">No items match.${InvState.only ? ' <button class="btn sm" id="ishowall">Show all items</button>' : ""}</div>` : ""}
    ${D.items.length ? `<p class="muted small" style="margin-top:16px">Tip: on the Medication tab, edit a medication and tick the supplies it uses (needles, swabs…). They count down by themselves each time you log a dose, and the app estimates how many days they'll last. Linking a vial or cartridge lets you press <b>Open a vial</b> (or <b>Open a cartridge</b>) to add its contents to that medication's stock.</p>` : ""}`;

  const add = () => addItemFlow(D);
  $("#iadd", view).onclick = add; $("#iref", view).onclick = () => refBrowser();
  const a2 = $("#iadd2", view); if (a2) a2.onclick = add;
  wireRefPanel(view, lib);
  $("#isearch", view).oninput = e => { InvState.q = e.target.value; clearTimeout(InvState.t); InvState.t = setTimeout(() => { Router.render(); const s = $("#isearch"); if (s) { s.focus(); s.setSelectionRange(99, 99); } }, 250); };
  $$("#icats button", view).forEach(b => b.onclick = () => { InvState.cat = b.dataset.c; Router.render(); });
  $$("[data-only]", view).forEach(b => b.onclick = () => { InvState.only = InvState.only === b.dataset.only ? "" : b.dataset.only; Router.render(); });
  const sa = $("#ishowall", view); if (sa) sa.onclick = () => { InvState.only = ""; Router.render(); };
  const so = $("#isort", view); if (so) so.onchange = () => { InvState.sort = so.value; invLS("wp_inv_sort", so.value); Router.render(); };
  $$("#iview button", view).forEach(b => b.onclick = () => { InvState.view = b.dataset.v; invLS("wp_inv_view", b.dataset.v); Router.render(); });
  const sh = $("#ishop", view); if (sh) sh.onclick = () => shoppingModal(D);
  $$("[data-oa]", view).forEach(b => b.onclick = () => {
    const o = D.orders.open.find(x => x.id === +b.dataset.o);
    if (b.dataset.oa === "recv") receiveModal(o, D);
    if (b.dataset.oa === "cancel") confirmBox(`Cancel the order for ${o.name}? Anything already received stays in your stock.`, "Cancel order").then(async ok => { if (ok) { await api(`/orders/${o.id}/cancel`, "POST"); Router.render(); } });
  });
  const ro = $("#ireorder", view);
  if (ro) ro.onclick = () => {
    if (!reorder.length) return toast("Link low items to a Price watch item first (Edit → Reorder link)", true);
    reorder.forEach(i => PriceState.sel.set(i.price_item_id, 1)); PriceState.plannerOpen = true; location.hash = "#/prices";
  };
  wireInv(view, D);
};

/* The buttons on a card or a list row. A tap on a list row (not on its buttons) opens the full card in a window. */
function wireInv(root, D, inModal) {
  $$("[data-inv]", root).forEach(card => {
    const it = D.items.find(i => i.id === +card.dataset.inv);
    if (card.classList.contains("inv-row")) card.addEventListener("keydown", e => { if (e.key === "Enter" && e.target === card) invDetail(it, D); });
    card.addEventListener("click", async e => {
      const b = e.target.closest("[data-a]");
      if (!b) { if (card.classList.contains("inv-row")) invDetail(it, D); return; }
      const a = b.dataset.a, more = b.closest("details.imore"); if (more) more.open = false;
      const after = async () => { if (inModal) await inModal(); Router.render(); };
      if (inModal && !["dec", "inc", "open"].includes(a)) inModal.close();
      if (a === "dec" || a === "inc") return run(b, async () => { await api(`/inventory/${it.id}/adjust`, "POST", { delta: a === "dec" ? -1 : 1 }); await after(); });
      if (a === "adjust") adjustModal(it);
      if (a === "edit") invModal(it, D);
      if (a === "hist") historyModal(it);
      if (a === "ref") { const r = refMatch(it.name); if (r) refSheetModal(r); }
      if (a === "open") return run(b, async () => { const r = await api(`/inventory/${it.id}/open-vial`, "POST");
        toast(r.added_to_med ? `Opened — added ${num(r.added_to_med.qty, 1)} ${r.added_to_med.unit} to ${r.added_to_med.name}'s stock` : (isCart(it) ? "Opened a cartridge" : "Opened a vial")); await after(); });
      if (a === "reorder") { PriceState.sel.set(it.price_item_id, 1); PriceState.plannerOpen = true; location.hash = "#/prices"; }
    });
  });
}
function invDetail(it, D) {
  const m = modal(`<div id="invd">${invCard(it)}</div><div class="actions"><button class="btn" data-close>Close</button></div>`);
  const fill = (i, d) => { $("#invd", m.el).innerHTML = invCard(i); wireInv($("#invd", m.el), d, refresh); };
  const refresh = async () => { const d = await api("/inventory"), i = d.items.find(x => x.id === it.id); if (i) fill(i, d); else m.close(); };
  refresh.close = m.close;
  fill(it, D);
}
// a "⋯ More" menu closes when you tap anywhere else
document.addEventListener("click", e => $$("details.imore[open]").forEach(d => { if (!d.contains(e.target)) d.open = false; }));

function invRow(i) {
  return `<div class="inv-row ${i.flags.includes("out") || i.flags.includes("expired") ? "bad" : i.flags.length ? "flag" : ""}" data-inv="${i.id}" role="button" tabindex="0" title="Show details">
    <div class="grow nm"><b>${esc(i.name)}</b>${i.size ? ` <span class="small muted">${esc(i.size)}</span>` : ""}<div class="row wrap tags">${i.flags.map(invFlag).join("")}</div></div>
    <div class="q"><b>${invQty(i.qty)}</b> <span class="small muted">${esc(i.unit || "")}</span></div>
    <span class="row" style="gap:6px"><button class="btn sm" data-a="dec" title="Use 1" aria-label="Use 1 ${esc(i.name)}">−1</button><button class="btn sm" data-a="inc" title="Add 1" aria-label="Add 1 ${esc(i.name)}">+1</button></span></div>`;
}

function invCard(i) {
  const meta = [i.size, i.location, i.lot ? "lot " + i.lot : ""].filter(Boolean).map(esc).join(" · ");
  const fc = i.days_left != null ? `<div class="small ${i.days_left <= 14 ? "up" : "muted"}">≈ ${i.days_left} day${i.days_left === 1 ? "" : "s"} ${i.basis === "vials" ? "of doses (incl. what's left in the open vial)" : "left at your current schedule"}</div>` : "";
  const ex = i.expiry_in != null ? `<div class="small ${i.expiry_in < 0 ? "up" : i.expiry_in <= 30 ? "up" : "muted"}">${i.expiry_in < 0 ? "Expired " + fmtDate(i.expiry_date, true) : "Expires " + fmtDate(i.expiry_date, true) + " (" + i.expiry_in + " days)"}</div>` : "";
  const pr = i.price && i.price.best ? `<span class="small muted">best ${money(i.price.best.price, i.price.best.currency)} at ${esc(i.price.best.site)}</span>` : "";
  const ref = refMatch(i.name), open = isVialCat(i.category) && i.qty >= 1;
  return `<div class="card inv ${i.flags.length ? "flag" : ""}" data-inv="${i.id}">
    <div class="row spread" style="align-items:flex-start"><div><b style="line-height:1.25">${esc(i.name)}</b>${meta ? `<div class="small muted">${meta}</div>` : ""}</div><button class="btn ghost sm" data-a="edit" title="Edit" aria-label="Edit ${esc(i.name)}">✎</button></div>
    <div class="row spread"><div><span class="price">${invQty(i.qty)}</span> <span class="small muted">${esc(i.unit || "")}</span>
        <div class="row wrap" style="gap:4px;margin-top:4px">${i.flags.map(invFlag).join("")}${i.low_at != null ? `<span class="small muted">alert at ${invQty(i.low_at)}</span>` : ""}</div></div>
      <span class="row" style="gap:6px"><button class="btn sm" data-a="dec" title="Use 1">−1</button><button class="btn sm" data-a="inc" title="Add 1">+1</button></span></div>
    ${fc}${ex}
    ${i.on_order > 0 ? `<div class="small ${i.order_late ? "up" : ""}">📦 ${invQty(i.on_order)} on order${i.order_late ? ` — ${i.order_late} day${i.order_late === 1 ? "" : "s"} late` : ""}</div>` : ""}
    ${i.last_paid ? `<div class="small muted">last paid ${money(i.last_paid.price, i.last_paid.currency)} each${i.last_paid.site ? " at " + esc(i.last_paid.site) : ""} · ${fmtDate(i.last_paid.date, true)}</div>` : ""}
    ${i.uses && i.uses.length ? `<div class="small muted">💉 Used with ${i.uses.map(u => `${esc(u.med_name)} (${invQty(u.per_dose)} per dose)`).join(", ")}</div>` : i.med_name ? `<div class="small muted">💉 ${esc(i.med_name)}</div>` : ""}
    <div class="row wrap inv-acts" style="gap:6px;align-items:center">
      ${open ? `<button class="btn sm" data-a="open">Open a ${isCart(i) ? "cartridge" : "vial"}</button>` : ""}
      <details class="imore"><summary class="btn sm" aria-label="More for ${esc(i.name)}">⋯ More</summary><div class="more-menu">
        <button type="button" data-a="adjust">✏️ Adjust amount…</button>
        ${i.price_item_id ? '<button type="button" data-a="reorder">🛒 Reorder</button>' : ""}
        ${ref ? '<button type="button" data-a="ref">📖 Reference sheet</button>' : ""}
        <button type="button" data-a="hist">🕘 History</button>
        <button type="button" data-a="edit">✎ Edit item</button></div></details>
      ${pr}</div></div>`;
}

function ordersSection(D) {
  const O = D.orders || { open: [], recent: [] };
  if (!O.open.length && !O.recent.length) return "";
  const cur = o => o.currency;
  const row = o => `<div class="card" style="margin-bottom:8px"><div class="row spread wrap" style="gap:10px;align-items:center">
      <div class="grow"><b>${esc(o.name)}</b> <span class="muted">× ${invQty(o.qty)}</span>${o.qty_received ? ` <span class="badge">${invQty(o.qty_received)} received</span>` : ""}${o.late_days > 0 ? ` <span class="badge warn">${o.late_days} day${o.late_days === 1 ? "" : "s"} late</span>` : ""}
        <div class="small muted">${o.site ? esc(o.site) + " · " : ""}ordered ${fmtDate(o.ordered_on, true)}${o.expected_by ? " · expected " + fmtDate(o.expected_by, true) : ""}${o.unit_price != null ? ` · ${money(o.unit_price, cur(o))} each (${money(o.unit_price * o.qty, cur(o))})` : ""}</div></div>
      <span class="row" style="gap:6px"><button class="btn sm primary" data-oa="recv" data-o="${o.id}">✓ Received…</button><button class="btn ghost sm" data-oa="cancel" data-o="${o.id}">Cancel</button></span></div></div>`;
  return `${O.open.length ? `<h2 style="margin:18px 0 10px">📦 On order <span class="small muted" style="font-weight:400">— press Received when it arrives to add it to your stock</span></h2>${O.open.map(row).join("")}` : ""}
    ${O.recent.length ? `<details style="margin-top:12px"><summary class="small muted" style="cursor:pointer">Recently received (${O.recent.length})</summary><div class="scroll-x"><table><tbody>${O.recent.map(o => `<tr><td>${fmtDate(o.received_on || o.ordered_on, true)}</td><td><b>${esc(o.name)}</b> × ${invQty(o.qty_received)}</td><td class="muted">${esc(o.site || "")}</td><td class="r">${o.unit_price != null ? money(o.unit_price * o.qty_received, cur(o)) : ""}</td></tr>`).join("")}</tbody></table></div></details>` : ""}`;
}

function receiveModal(o, D) {
  const nm = o.name.toLowerCase(), guess = o.inv_id || (D.items.find(i => i.name.toLowerCase() === nm) || D.items.find(i => i.name.toLowerCase().includes(nm) || nm.includes(i.name.toLowerCase())) || {}).id;
  const opts = D.items.map(i => `<option value="${i.id}" ${i.id === guess ? "selected" : ""}>${esc(i.name)}${i.size ? " (" + esc(i.size) + ")" : ""}</option>`).join("");
  const pack = (o.name.match(/(\d+)\s*(?:ct|count|pcs|pieces|pack|pk)\b/i) || [])[1] || 1;       // "120Ct Needles" -> 120 per package
  modal(`<h2>Received: ${esc(o.name)}</h2><p class="muted small" style="margin:0 0 8px">You ordered <b>${invQty(o.left)}</b>${o.site ? " from " + esc(o.site) : ""}. If only some arrived, enter fewer and the rest stays on order.</p>
    <form id="f" class="form-grid">
      <label class="f">How many packages arrived?<input type="number" step="any" min="0" name="qty" value="${o.left}" required autofocus><span class="small muted">The number you ordered, e.g. 1 box</span></label>
      <label class="f">How many pieces in each package?<input type="number" step="any" min="0" name="per_item" value="${pack}"><span class="small muted">e.g. 120 for a box of 120 needles. Use 1 if each one is a single item.</span></label>
      <div class="full" id="rsum" style="padding:8px 12px;border-radius:10px;background:var(--bg)"></div>
      <label class="f full">Which inventory item is this for?<select name="inv_id" id="rinv"><option value="">➕ It's not in my inventory yet — create it</option>${opts}</select><span class="small muted">The pieces are added to the item you pick here. Choose “create it” if it isn't listed yet, and name it below.</span></label>
      <div class="full form-grid" id="rnew" style="display:none;padding:0">
        <label class="f">New item name<input name="nname" value="${esc(o.name)}"></label>
        <label class="f">Category<select name="ncat">${D.categories.map(c => `<option ${c === "Supplies" ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label>
        <label class="f">Counted in<input name="nunit" value="pcs"></label></div>
      <label class="f">Arrived on<input type="date" name="received_on" value="${new Date().toLocaleDateString("en-CA")}" max="${new Date().toLocaleDateString("en-CA")}"><span class="small muted">Forgot to add it? Pick the day it really arrived.</span></label>
      <label class="f">Lot # <span class="muted">(optional)</span><input name="lot"></label>
      <label class="f">Expires <span class="muted">(optional)</span><input type="date" name="expiry_date"></label>
      <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Add to stock</button></div></form>`, {
    onMount: (el, close) => {
      const sel = $("#rinv", el), nw = $("#rnew", el), q = $("[name=qty]", el), pi = $("[name=per_item]", el), nu = $("[name=nunit]", el);
      const unitOf = () => sel.value ? (D.items.find(i => i.id === +sel.value)?.unit || "") : nu.value;
      const sum = () => { const n = (parseFloat(q.value) || 0) * (parseFloat(pi.value) || 1);
        $("#rsum", el).innerHTML = `This adds <b>${invQty(n)} ${esc(unitOf())}</b> to your stock.`; };
      const sync = () => { nw.style.display = sel.value ? "none" : ""; sum(); };
      sel.onchange = sync; [q, pi, nu].forEach(x => x.oninput = sum); sync();
      $("#f", el).onsubmit = async e => {
        e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
        if (parseFloat(f.qty) > o.left) return toast(`You only ordered ${invQty(o.left)}. If ${invQty(f.qty)} is the number of pieces, enter 1 in “packages” and ${invQty(f.qty)} in “pieces in each package”.`, true);
        const body = { qty: parseFloat(f.qty), per_item: parseFloat(f.per_item) || 1, inv_id: f.inv_id || null, lot: f.lot, expiry_date: f.expiry_date, received_on: f.received_on || null };
        if (!f.inv_id) body.new_item = { name: f.nname, category: f.ncat, unit: f.nunit };
        await run($(".primary", el), async () => { const r = await api(`/orders/${o.id}/receive`, "POST", body); close(); toast(`Added ${invQty(r.added)} to stock${r.complete ? "" : " — the rest is still on order"}`); Router.render(); });
      };
    },
  });
}

function shoppingModal(D) {
  const list = D.items.filter(i => i.flags.some(f => ["low", "out", "expired"].includes(f)));
  const cur = i => i.price?.best ? `${money(i.price.best.price, i.price.best.currency)} at ${esc(i.price.best.site)}` : i.last_paid ? `last paid ${money(i.last_paid.price, i.last_paid.currency)}` : "";
  modal(`<div id="print-area"><h2>Shopping list</h2><p class="muted small" style="margin:0 0 8px">${new Date().toLocaleDateString([], { month: "long", day: "numeric", year: "numeric" })} · things that are low, out or expired and not already on order</p>
    ${list.length ? `<table><thead><tr><th></th><th>Item</th><th class="r">On hand</th><th class="r">Days left</th><th>Price</th></tr></thead><tbody>${list.map(i => `<tr><td>☐</td><td><b>${esc(i.name)}</b>${i.size ? ` <span class="muted">${esc(i.size)}</span>` : ""}</td><td class="r">${invQty(i.qty)} ${esc(i.unit || "")}</td><td class="r">${i.days_left != null ? "≈" + i.days_left : ""}</td><td class="small">${cur(i)}</td></tr>`).join("")}</tbody></table>` : '<div class="empty small">Nothing to buy right now.</div>'}</div>
    <div class="actions no-print"><button type="button" class="btn" data-close>Close</button>${list.length ? '<button type="button" class="btn primary" id="pr">🖨 Print</button>' : ""}</div>`, {
    onMount: el => { const b = $("#pr", el); if (b) b.onclick = () => window.print(); },
  });
}

function adjustModal(it) {
  const m = modal(`<div class="row" style="gap:12px;align-items:center;margin-bottom:6px"><h2 style="margin:0">${esc(it.name)}</h2></div><p class="muted small" style="margin:0 0 8px">On hand now: <b>${invQty(it.qty)} ${esc(it.unit || "")}</b></p>
    <form id="f" class="form-grid">
      <label class="f">What happened<select name="kind"><option value="add">Added / restocked</option><option value="use">Used</option><option value="discard">Discarded / expired</option><option value="set">Set exact amount</option></select></label>
      <label class="f">Amount (${esc(it.unit || "")})<input type="number" step="any" min="0" name="amt" required autofocus></label>
      <label class="f full">Note <span class="muted">(optional)</span><input name="note" placeholder="e.g. ordered from…"></label>
      <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div></form>`, {
    onMount: (el, close) => $("#f", el).onsubmit = async e => {
      e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)), n = parseFloat(f.amt);
      const body = f.kind === "set" ? { set: n, note: f.note } : { delta: f.kind === "add" ? n : -n, reason: f.kind === "add" ? "restocked" : f.kind === "use" ? "used" : "discarded", note: f.note };
      await run($(".primary", el), async () => { await api(`/inventory/${it.id}/adjust`, "POST", body); close(); Router.render(); });
    },
  });
}

async function historyModal(it) {
  const m = modal(`<div class="row" style="gap:12px;align-items:center;margin-bottom:6px"><h2 style="margin:0">${esc(it.name)} — history</h2></div><div id="h" class="muted">Loading…</div><div class="actions"><button class="btn" data-close>Close</button></div>`);
  const rows = await api(`/inventory/${it.id}/history`);
  $("#h", m.el).innerHTML = rows.length ? `<div class="scroll-x"><table><tbody>${rows.map(r => `<tr><td>${fmtDateTime(r.ts.slice(0, 16))}</td>
    <td><b class="${r.change >= 0 ? "down" : "up"}">${r.change >= 0 ? "+" : ""}${invQty(r.change)}</b></td><td>${esc(r.reason || "")}${r.note ? ` <span class="muted">· ${esc(r.note)}</span>` : ""}</td><td class="r muted">${invQty(r.qty_after)} left</td></tr>`).join("")}</tbody></table></div>` : '<div class="empty small">No changes recorded yet.</div>';
}

async function invModal(it, D) {
  const [meds, pitems] = await Promise.all([api("/meds").catch(() => []), api("/items").catch(() => [])]);
  const units = ["pcs", "vials", "cartridges", "pens", "mL", "mg", "boxes", "bottles", "tablets", "capsules"];
  const m = modal(`<h2>${it ? "Edit item" : "Add item"}</h2><form id="f" class="form-grid">
    <label class="f full">Name<input name="name" required value="${esc(it?.name || "")}" placeholder="e.g. BPC-157 5 mg vial, insulin syringes"></label>
    <label class="f">Category<select name="category">${D.categories.map(c => `<option ${c === (it?.category || "Supplies") ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label>
    <label class="f">${it ? "Quantity on hand" : "How many do you have?"}<input type="number" step="any" min="0" name="qty" value="${it ? it.qty : ""}" placeholder="0"></label>
    ${unitField("Unit", "unit", it?.unit || "pcs", units)}
    <label class="f">Size <span class="muted">(optional)</span><input name="size" value="${esc(it?.size || "")}" placeholder="e.g. 5 mg per vial, 30 mL"></label>
    <label class="f">Warn me when I'm down to<input type="number" step="any" min="0" name="low_at" value="${it?.low_at ?? ""}" placeholder="e.g. 10"></label>
    <label class="f">Expires<input type="date" name="expiry_date" value="${it?.expiry_date || ""}"></label>
    <label class="f">Lot # <span class="muted">(optional)</span><input name="lot" value="${esc(it?.lot || "")}"></label>
    <label class="f">Where it's stored <span class="muted">(optional)</span><input name="location" value="${esc(it?.location || "")}" placeholder="e.g. fridge, drawer"></label>
    <label class="f">Medication this vial is for <span class="muted">(optional)</span><select name="med_id" id="imed"><option value="">—</option>${meds.map(x => `<option value="${x.id}" ${it?.med_id === x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>
    <p class="small muted full" style="margin:-4px 0 0">Supplies like needles and swabs are linked to a medication from the Medication tab (Edit → Supplies used with each dose), so they come off your stock when you log a dose. The medication above is only for vials.</p>
    <label class="f full">Reorder link <span class="muted">(optional, from Price watch)</span><select name="price_item_id"><option value="">—</option>${pitems.map(x => `<option value="${x.id}" ${it?.price_item_id === x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>
    <label class="f full">Notes<input name="notes" value="${esc(it?.notes || "")}"></label>
    <div class="actions full">${it ? '<button type="button" class="btn danger" id="idel">Delete</button>' : ""}<button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div></form>`, {
    wide: true,
    onMount: (el, close) => {
      bindUnits(el);
      const md = $("#imed", el);
      $("#f", el).onsubmit = async e => {
        e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
        await run($(".primary", el), async () => { it ? await api("/inventory/" + it.id, "PUT", f) : await api("/inventory", "POST", f); close(); toast("Saved"); Router.render(); });
      };
      const del = $("#idel", el); if (del) del.onclick = async () => { if (await confirmBox(`Delete ${it.name} from your inventory?`)) { await api("/inventory/" + it.id, "DELETE"); close(); Router.render(); } };
    },
  });
}

function invCardDash(inv) {
  if (!inv || !inv.count) return "";
  const flagged = inv.low + inv.out + inv.expiring + inv.expired + (inv.late || 0);
  const line = i => {
    const t = i.flags.includes("expired") ? "expired" : i.flags.includes("out") ? "out of stock" : i.flags.includes("late") ? "order is late" : i.flags.includes("low") ? `low (${num(i.qty, 1)} ${esc(i.unit || "")}${i.days_left != null ? `, ≈${i.days_left}d` : ""})` : `expires in ${i.expiry_in} days`;
    return `<div class="li"><div class="grow small"><b>${esc(i.name)}</b> <span class="badge ${i.flags.includes("expired") || i.flags.includes("out") ? "bad" : "warn"}">${t}</span></div></div>`;
  };
  return `<div class="card"><h2>Inventory <a href="#/inventory" class="small">Open →</a></h2>${flagged ? inv.top.map(line).join("") + (flagged > inv.top.length ? `<div class="small muted" style="margin-top:6px">+${flagged - inv.top.length} more</div>` : "") : `<div class="empty small">✓ ${inv.count} item${inv.count === 1 ? "" : "s"} on hand — nothing low or expiring.</div>`}</div>`;
}

/* ---- reference panel at the top of the Inventory page */
function refPanel(lib) {
  if (!lib.length) return "";
  const groups = [...new Set(lib.flatMap(r => r.groups || []))].sort();
  return `<details class="card refbox" id="refbox" style="margin-bottom:16px" ${invLS("wp_inv_ref_open") === "1" ? "open" : ""}><summary><b>📖 Reference sheets</b> <span class="small muted">look up a compound's dosing and notes</span></summary><div class="row spread wrap" style="gap:10px;margin-top:10px">
      <div class="grow" style="max-width:420px;position:relative"><input id="rsearch" placeholder="Look up a compound…" autocomplete="off" style="width:100%"><div id="rhits" class="list" style="position:absolute;left:0;right:0;top:100%;z-index:5;background:var(--card);border:1px solid var(--line);border-radius:10px;display:none;max-height:260px;overflow:auto"></div></div></div>
    <div class="row wrap" style="gap:6px;margin-top:10px">${groups.map(g => `<button class="btn sm" data-rg="${esc(g)}">${INV_ICON[g] || ""} ${esc(g)}</button>`).join("")}</div></details>`;
}
function wireRefPanel(view, lib) {
  const box = $("#refbox", view); if (box) box.ontoggle = () => invLS("wp_inv_ref_open", box.open ? "1" : "0");
  const inp = $("#rsearch", view); if (!inp) return;
  const hits = $("#rhits", view);
  inp.oninput = () => {
    const q = inp.value.trim().toLowerCase();
    const found = q ? lib.filter(r => (r.name + " " + (r.names || "")).toLowerCase().includes(q)).slice(0, 8) : [];
    hits.style.display = found.length ? "" : "none";
    hits.innerHTML = found.map(r => `<div class="li" style="cursor:pointer;padding:8px 12px" data-rh="${r.id}"><div class="grow"><b>${esc(r.name)}</b> <span class="small muted">${esc((r.groups || []).join(" · "))}</span></div></div>`).join("");
    $$("[data-rh]", hits).forEach(el => el.onclick = () => { hits.style.display = "none"; inp.value = ""; refSheetModal(lib.find(r => r.id === +el.dataset.rh)); });
  };
  inp.onblur = () => setTimeout(() => (hits.style.display = "none"), 200);
  $$("[data-rg]", view).forEach(b => b.onclick = () => refBrowser(b.dataset.rg));
}

/* ---- "Add item": pick a category, pick what it is, say how many */
function addItemFlow(D, pre) {
  const lib = InvState.lib || [];
  const cats = D.pick_categories || D.categories, byName = n => D.items.find(i => i.name.toLowerCase() === n.toLowerCase());
  let step = pre && pre.item ? "form" : "cat", cat = pre && pre.cat || "", pick = pre && pre.item ? { name: pre.item.name, ref: pre.item } : null, q = "";
  if (pick && !cat) cat = (pre.item.groups || []).find(g => cats.includes(g)) || "Other";
  const rowsFor = c => c === "Supplies" ? D.presets.map(p => ({ name: p.name, sub: p.unit, unit: p.unit, low_at: p.low_at }))
    : c === "Other" ? [] : lib.filter(r => (r.groups || []).includes(c)).map(r => ({ name: r.name, sub: (r.dosage || "").split("\n")[0].slice(0, 60), ref: r }));
  modal(`<div id="aif"></div>`, {
    wide: true,
    onMount: (el, close) => {
      const box = $("#aif", el);
      const draw = () => {
        if (step === "cat") {
          box.innerHTML = `<h2>What are you adding?</h2><p class="muted small" style="margin:0 0 10px">Pick a category. Next you'll pick the item, then say how many you have.</p>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:8px">${cats.map(c => `<button type="button" class="btn" data-c="${esc(c)}" style="justify-content:flex-start;text-align:left;padding:12px">${INV_ICON[c] || "📦"} ${esc(c)}</button>`).join("")}</div>
            <div class="actions"><button type="button" class="btn" data-close>Cancel</button></div>`;
          $$("[data-c]", box).forEach(b => b.onclick = () => { cat = b.dataset.c; q = ""; step = "item"; draw(); });
        } else if (step === "item") {
          const rows = rowsFor(cat).filter(r => !q || r.name.toLowerCase().includes(q));
          box.innerHTML = `<h2>${INV_ICON[cat] || ""} ${esc(cat)}</h2>
            <div class="row" style="gap:8px;margin-bottom:8px"><button type="button" class="btn sm" id="back">← Categories</button><input id="aq" class="grow" placeholder="Search…" autocomplete="off"></div>
            <div class="list" style="max-height:46vh;overflow:auto">${rows.map((r, i) => `<div class="li" style="cursor:pointer" data-r="${i}"><div class="grow"><b>${esc(r.name)}</b>${r.sub ? `<div class="small muted">${esc(r.sub)}</div>` : ""}</div>${byName(r.name) ? '<span class="badge ok">have</span>' : ""}</div>`).join("")}
              <div class="li" style="cursor:pointer" data-r="new"><div class="grow"><b>＋ Something that's not on this list</b><div class="small muted">Type your own name</div></div></div></div>
            <div class="actions"><button type="button" class="btn" data-close>Cancel</button></div>`;
          $("#back", box).onclick = () => { step = "cat"; draw(); };
          const aq = $("#aq", box); aq.value = q; aq.oninput = () => { q = aq.value.trim().toLowerCase(); draw(); const n = $("#aq", box); n.focus(); n.setSelectionRange(99, 99); };
          $$("[data-r]", box).forEach(b => b.onclick = () => { pick = b.dataset.r === "new" ? { name: "" } : rows[+b.dataset.r]; step = "form"; draw(); });
        } else {
          const have = pick.name && byName(pick.name), vial = isVialCat(cat) || cat === "Diluents & Additives";
          const unit = pick.unit || (vial ? "vials" : "pcs"), st = pick.ref && pick.ref.storage ? pick.ref.storage.split("\n")[0] : "";
          box.innerHTML = `<h2>${INV_ICON[cat] || ""} ${esc(pick.name || "New item")}</h2>
            ${have ? `<div class="alert info" style="margin-bottom:10px">You already have <b>${invQty(have.qty)} ${esc(have.unit || "")}</b> of this. Saving adds to that count.</div>` : ""}
            <form id="f" class="form-grid">
              ${pick.name ? "" : '<label class="f full">Name<input name="name" required autofocus></label>'}
              <label class="f">How many do you have?<input type="number" step="any" min="0" name="qty" value="1" required ${pick.name ? "autofocus" : ""}></label>
              ${unitField("Counted in", "unit", unit, ["pcs", "vials", "cartridges", "pens", "mL", "mg", "boxes", "bottles", "tablets", "capsules"])}
              <label class="f">Expires <span class="muted">(optional)</span><input type="date" name="expiry_date"></label>
              <label class="f">Where it's stored <span class="muted">(optional)</span><input name="location" placeholder="e.g. fridge, drawer"></label>
              <label class="f">Warn me when I'm down to <span class="muted">(optional)</span><input type="number" step="any" min="0" name="low_at" value="${pick.low_at ?? ""}" placeholder="e.g. 2"></label>
              ${st ? `<div class="small muted" style="align-self:end">Reference sheet storage: ${esc(st)}</div>` : ""}
              <div class="actions full"><button type="button" class="btn" id="back">← Back</button><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Add to inventory</button></div></form>`;
          bindUnits(box);
          $("#back", box).onclick = () => { step = pre && pre.item ? "cat" : "item"; draw(); };
          $("#f", box).onsubmit = async e => {
            e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); const name = (pick.name || f.name || "").trim();
            if (!name) return toast("Give it a name", true);
            await run($(".primary", box), async () => {
              const ex = byName(name);
              if (ex) await api(`/inventory/${ex.id}/adjust`, "POST", { delta: parseFloat(f.qty) || 0, reason: "restocked" });
              else await api("/inventory", "POST", { name, category: cat, qty: parseFloat(f.qty) || 0, unit: f.unit, expiry_date: f.expiry_date, location: f.location, low_at: f.low_at });
              close(); toast(ex ? `Added ${f.qty} to ${name}` : `${name} added`); Router.render();
            });
          };
        }
        $$("[data-close]", box).forEach(b => b.onclick = close);      // buttons drawn after the window opened need wiring too
      };
      draw();
    },
  });
}
async function invAddFromRef(item) { const D = await api("/inventory"); InvState.vial = D.vial_categories || []; addItemFlow(D, { item }); }
