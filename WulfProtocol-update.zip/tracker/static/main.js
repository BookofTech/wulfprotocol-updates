var Pages = window.Pages || (window.Pages = {});

/* ================= Dashboard ================= */
/* ---- updates */
const fmtUpdated = d => { const m = String(d || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); if (!m) return String(d || ""); return new Date(+m[1], +m[2] - 1, +m[3]).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }); };
const relName = r => { if (!r || !r.version) return "the new version"; const t = x => String(x || "").charAt(0).toUpperCase() + String(x || "").slice(1).toLowerCase();
  return `Version ${r.version}${r.status ? " " + t(r.status) : ""}${r.codename ? " (" + t(r.codename) + ")" : ""}`; };
const UpdateUI = {
  info: null,
  async check(force) {
    try { this.info = await api("/update/check" + (force ? "?force=1" : "")); } catch (e) { this.info = null; }
    const a = document.querySelector('nav.side a[data-r="settings"]');
    if (a) { const old = a.querySelector(".updot"); if (old) old.remove(); if (this.info && this.info.newer) a.insertAdjacentHTML("beforeend", '<span class="badge acc updot" title="An update is available">update</span>'); }
    return this.info;
  },
  async install(btn) {
    await run(btn, async () => {
      const r = await fetch("/api/update/install", { method: "POST", headers: { "X-WulfProtocol": "1" } });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) return toast(d.error || "Update failed", true);
      try { await fetch("/api/shutdown", { method: "POST", headers: { "X-WulfProtocol": "1" } }); } catch (x) { /* stopping */ }
      document.body.innerHTML = `<div style="font-family:system-ui;text-align:center;margin:20vh auto;max-width:440px;color:#667085"><h2 style="color:#18212f">Updated to ${esc(relName(d.release))}</h2><p>Your information was kept${d.backup ? ` and a backup was saved as <b>${d.backup}</b>` : ""}.</p><p>Open WulfProtocol again from your icon to start the new version.</p></div>`;
    });
  },
};
const updateBanner = () => { const u = UpdateUI.info; return u && u.newer ? `<div class="alert info glow" style="margin-bottom:16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap"><span class="grow">⬆️ ${relName(u.release) === relName(u.current_release) ? "A newer build of" : "A new version of WulfProtocol is ready:"} ${esc(relName(u.release))}${relName(u.release) === relName(u.current_release) ? " is ready." : "."}${u.notes ? " " + esc(u.notes) : ""}</span><a class="btn sm primary" href="#/settings">Update</a></div>` : ""; };


const statusBadge = s => ({
  taken: '<span class="badge ok">✓ taken</span>', skipped: '<span class="badge warn">skipped</span>',
  missed: '<span class="badge bad">missed</span>', due: '<span class="badge warn">due now</span>', upcoming: "",
}[s] || "");
const doseLine = i => `${i.dose != null ? num(i.dose, 3) + " " + esc(i.unit) : ""}${i.route ? " · " + esc(i.route) : ""}`;

function supplySub(d) {
  if (d.refills.length) return esc(d.refills[0].name) + (d.refills[0].days_left != null ? " · " + d.refills[0].days_left + "d left" : "");
  if ((d.expiring || []).length) return esc(d.expiring[0].name) + (d.expiring[0].days_left < 0 ? " expired" : " expires in " + d.expiring[0].days_left + "d");
  return "supply looks fine";
}
function supplyRows(d) {
  const rows = d.refills.map(r => `<div class="li"><span class="dot" style="background:${r.color}"></span>
      <div class="grow"><div class="t">${esc(r.name)}</div><div class="m">${r.days_left === 0 ? "runs out today" : r.days_left + " days left"}${r.runs_out_on ? " · out " + fmtDate(r.runs_out_on) : ""}</div></div>
      <a class="btn sm" href="#/meds/${r.med_id}">Restock</a></div>`).join("")
    + (d.expiring || []).map(e => `<div class="li"><span class="dot" style="background:${e.color}"></span>
      <div class="grow"><div class="t">${esc(e.name)} <span class="badge ${e.days_left < 0 ? "bad" : "warn"}">${e.days_left < 0 ? "expired" : "expires in " + e.days_left + "d"}</span></div><div class="m">opened ${fmtDate(e.opened_on)} · use by ${fmtDate(e.expires_on)}</div></div>
      <a class="btn sm" href="#/meds/${e.med_id}">New vial</a></div>`).join("");
  return rows || '<div class="empty small">Nothing needs restocking or is about to expire.</div>';
}

Pages.dashboard = async function (view) {
  const d = await api("/dashboard");
  if (d.fitness) App.profile = d.fitness.profile;
  const F = feat(), lone = !F.meds;
  const urgent = d.due.length + d.missed.length;
  Router.setBadge(urgent);
  const lowRefills = d.refills.length + (d.expiring || []).length;
  const hello = (() => { const h = new Date().getHours(), g = h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening", n = ((App.settings && App.settings.user_name) || "").trim(); return n ? `${g}, ${esc(n)}` : g; })();

  const attnRow = (i, kind) => `<div class="li ${kind === "missed" ? "missed" : ""}">
      <span class="dot" style="background:${i.color}"></span>
      <div class="grow"><div class="t">${i.route_icon || ""} ${esc(i.name)} <span class="m">${doseLine(i)}</span></div>
        <div class="m">${kind === "missed" ? "Missed · " + dayLabel(i.slot) + " " + fmtTime(i.slot) : "Due " + fmtTime(i.slot) + " · " + rel(i.slot)}</div>
        ${i.next_site ? `<div class="m">★ Next ${i.route === "intranasal" ? "nostril" : "site"}: <b>${esc(i.next_site)}</b></div>` : ""}</div>
      ${kind === "missed"
      ? `<button class="btn sm primary" data-take-late="${i.med_id}|${i.slot}">Log taken</button>`
      : i.has_sites ? `<button class="btn sm primary" data-take-late="${i.med_id}|${i.slot}" data-now="1">✓ Taken</button>`
        : `<button class="btn sm primary" data-take="${i.med_id}|${i.slot}">✓ Taken</button>`}
      <button class="btn sm" data-skip="${i.med_id}|${i.slot}">Skip</button></div>`;

  const schedRow = i => `<div class="li sched">
          <span class="stime">${fmtTime(i.slot)}</span><span class="dot" style="background:${i.color}"></span><div class="grow"><div class="t">${i.route_icon || ""} ${esc(i.name)}</div><div class="m sub">${doseLine(i)}${i.next_site && i.status !== "taken" ? ` · ★ ${esc(i.next_site)}` : ""}</div></div>${statusBadge(i.status)}</div>`;
  const byDay = {};
  d.upcoming.filter(i => i.slot.slice(0, 10) !== d.now.slice(0, 10)).forEach(i => (byDay[i.slot.slice(0, 10)] = byDay[i.slot.slice(0, 10)] || []).push(i));

  view.innerHTML = `<div class="glassdash">
    <div class="hero"><span class="logo"></span>
      <div><h1>Wulf<em>Protocol</em></h1><div class="tag">Track. Optimize. Evolve.</div><div class="cat">BIOHACKING &amp; HEALTH MANAGEMENT</div></div>
      <div class="when"><b>${hello}</b><span class="muted">${new Date().toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}</span></div></div>
    ${F.meds ? `<div class="grid tiles">
      <div class="tile ${d.due.length ? "warn glow" : "ok"}"><div class="k">Due now</div><div class="v">${d.due.length}</div><div class="s">${d.due.length ? "waiting to be logged" : "nothing waiting"}</div></div>
      <div class="tile ${d.missed.length ? "bad glow" : "ok"}"><div class="k">Missed (7 days)</div><div class="v">${d.missed.length}</div><div class="s">${d.missed.length ? "tap Log taken if you did" : "none — nice"}</div></div>
      <div class="tile ${lowRefills ? "warn glow" : "ok"}"><div class="k">Refills &amp; expiry</div><div class="v">${lowRefills}</div><div class="s">${supplySub(d)}</div></div>
      <div class="tile"><div class="k">30-day adherence</div><div class="v">${d.adherence.pct == null ? "–" : d.adherence.pct + "%"}</div><div class="s">${d.adherence.taken} taken · ${d.adherence.missed} missed</div></div>
    </div>` : ""}
    ${updateBanner()}
    ${F.fitness && d.fitness && d.fitness.weigh_due ? `<div class="alert info glow" style="margin-bottom:16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap"><span class="grow">⚖️ Time for a weigh-in. Your last one was ${d.fitness.days_since_weight} day${d.fitness.days_since_weight === 1 ? "" : "s"} ago.</span><a class="btn sm primary" href="#/fitness">Log weight</a></div>` : ""}
    ${F.meds && d.med_count === 0 ? `<div class="card empty"><b>Let's get started</b>Add the peptides and meds you take and the dashboard will track doses, cycles and refills for you.<br><br><a class="btn primary" href="#/meds">Add your first medication</a></div>` : ""}
    <div class="grid ${lone ? "" : "cols-2"}">
      ${lone ? "" : `<div class="stack">
        ${d.med_count ? `<div class="card${urgent ? " glow" : ""}"><h2>Needs attention ${urgent ? `<span class="badge bad">${urgent}</span>` : ""}</h2>
          ${urgent ? `<div class="list">${d.due.map(i => attnRow(i, "due")).join("")}${d.missed.map(i => attnRow(i, "missed")).join("")}</div>`
        : '<div class="empty"><b>All caught up ✓</b>No due or missed doses.</div>'}</div>` : ""}
        ${d.today.length ? `<div class="card sched-card"><h2>Today <span class="small muted">${d.today.length} dose${d.today.length === 1 ? "" : "s"}</span></h2>${(() => { const sp = splitLater(d.today); return `<div class="list">${sp.shown.map(schedRow).join("")}</div>` + (sp.later.length ? laterBlock(sp.later.map(schedRow).join(""), sp.later.length) : ""); })()}</div>` : ""}
        ${Object.keys(byDay).length ? `<div class="card"><h2>Coming up <span class="small muted">next 4 days</span></h2>${Object.entries(byDay).slice(0, 4).map(([day, items]) => `<div class="day-head">${dayLabel(day)}</div>
          <div class="list">${items.map(i => `<div class="li"><span class="dot" style="background:${i.color}"></span><div class="grow"><span class="t">${esc(i.name)}</span> <span class="m">${doseLine(i)}</span></div><span class="m">${fmtTime(i.slot)}</span></div>`).join("")}</div>`).join("")}</div>` : ""}
      </div>`}
      <div class="${lone ? "grid cards-auto" : "stack"}">
        ${F.meds ? `<div class="card${lowRefills ? " glow" : ""}"><h2>Refills &amp; expiry</h2>${supplyRows(d)}</div>` : ""}
        ${F.meds ? invCardDash(d.inventory) : ""}
        ${d.cycles.length ? `<div class="card"><h2>Cycles</h2>${d.cycles.map(c => `<div class="li" style="flex-direction:column;align-items:stretch;gap:6px">
          <div class="row"><span class="dot" style="background:${c.color}"></span><b class="grow">${esc(c.name)}</b>${cycleBadge(c)}</div>
          ${c.enabled && c.phase ? cycleBar({ cycle: c, cycle_on: c.cycle_on, cycle_off: c.cycle_off }) + `<div class="small muted">${c.next_phase.toUpperCase()} phase starts ${fmtDate(c.next_change)} (${c.days_left_in_phase + 1} day${c.days_left_in_phase ? "s" : ""})</div>` : ""}</div>`).join("")}</div>` : ""}
        ${F.fitness && d.fitness ? `<div class="card"><h2>Weight <a href="#/fitness" class="small">Open →</a></h2>${weightCard(d.fitness)}</div>` : ""}
        ${F.fitness && d.labs && d.labs.count ? `<div class="card"><h2>Labs <a href="#/fitness/labs" class="small">Open →</a></h2>${labCard(d.labs)}</div>` : ""}
        ${F.prices && d.prices ? `<div class="card${d.prices.highlights && (d.prices.highlights.length || (d.prices.stock || []).length) ? " glow" : ""}"><h2>Price watch <a href="#/prices" class="small">Open →</a></h2>${priceCard(d.prices)}</div>` : ""}
      </div>
    </div></div>`;
  if (App.glowNow === false) $$(".glow", view).forEach(e => e.classList.remove("glow"));
  const endGlow = () => setTimeout(() => $$(".glow", view).forEach(e => e.classList.remove("glow")), 4300);      // the glow plays for about 4 seconds, then settles
  if (!document.getElementById("splash")) endGlow();
  else { const w = setInterval(() => { if (!document.getElementById("splash")) { clearInterval(w); endGlow(); } }, 150); }      // wait until the launch screen is gone

  bindLater(view);
  const split = v => { const [id, slot] = v.split("|"); return [+id, slot]; };
  $$("[data-take]", view).forEach(b => b.onclick = () => run(b, () => quickLog(...split(b.dataset.take), "taken")));
  $$("[data-skip]", view).forEach(b => b.onclick = () => run(b, () => quickLog(...split(b.dataset.skip), "skipped")));
  $$("[data-take-late]", view).forEach(b => b.onclick = () => run(b, () => openLogFor(...split(b.dataset.takeLate), b.dataset.now ? { now: true } : {})));
};

function weightCard(f) {
  if (!f.latest) return '<div class="empty small">No weight logged yet. <a href="#/fitness">Add your first entry</a></div>';
  const pts = f.weights.map(w => [0, toDisplay("weight", w.value)]);
  const c = f.change_30d;
  return `<div class="row spread"><div><div class="price">${num(toDisplay("weight", f.latest.value))} <span class="small muted">${metricUnit("weight")}</span></div>
    <div class="small">${c != null ? `<span class="${c <= 0 ? "down" : "up"}">${c > 0 ? "▲" : "▼"} ${num(Math.abs(toDisplay("weight", c)))} ${metricUnit("weight")}</span> <span class="muted">30 days</span>` : '<span class="muted">last 30 days n/a</span>'}</div></div>
    ${Charts.spark(pts, "var(--accent)", 120, 44)}</div>
    ${f.bmi ? `<div class="small muted" style="margin-top:6px">BMI ${f.bmi}${f.profile.goal_weight_kg ? " · goal " + fmtMetric("weight", f.profile.goal_weight_kg) : ""}</div>` : ""}`;
}
function labCard(l) {
  const flagged = l.spikes + l.out_of_range + l.retest;
  if (!flagged) return `<div class="empty small">✓ ${l.count} marker${l.count === 1 ? "" : "s"} tracked — nothing flagged.</div>`;
  return l.top.map(i => `<div class="li"><div class="grow small">${i.kind === "spike" ? `${i.pct > 0 ? "📈" : "📉"} <b>${esc(i.name)}</b> ${i.pct > 0 ? "up" : "down"} ${Math.abs(i.pct)}%`
    : i.kind === "range" ? `⚠ <b>${esc(i.name)}</b> is ${i.status}` : `⏰ <b>${esc(i.name)}</b> retest due`}</div></div>`).join("")
    + (flagged > l.top.length ? `<div class="small muted" style="margin-top:6px">+${flagged - l.top.length} more</div>` : "");
}
function priceCard(p) {
  if (!p.count) return '<div class="empty small">Not tracking any prices yet. <a href="#/prices">Add an item</a></div>';
  const rows = p.highlights.map(h => `<div class="li"><div class="grow"><div class="t" style="font-size:.9rem">${esc(h.name.slice(0, 48))}</div>
    <div class="m">${esc(h.site)}</div></div><div style="text-align:right"><b>${money(h.price, h.currency)}</b><div class="small ${h.at_target ? "down" : "down"}">${h.at_target ? "🎯 at target" : "▼ " + money(h.drop, h.currency)}</div></div></div>`).join("");
  const stock = (p.stock || []).map(e => `<div class="li"><div class="grow small">${e.kind === "back_in_stock" ? "🟢" : "🔴"} <b>${esc(e.name.slice(0, 40))}</b> ${e.kind === "back_in_stock" ? "is back in stock" : "went out of stock"} <span class="muted">at ${esc(e.site)}</span></div></div>`).join("");
  return stock + (rows || `<div class="empty small">${p.count} item${p.count > 1 ? "s" : ""} tracked — no drops this week.</div>`) +
    (p.errors ? `<div class="alert" style="margin-top:8px">⚠ ${p.errors} store${p.errors > 1 ? "s" : ""} need attention — <a href="#/prices">fix them</a></div>` : "");
}

/* ================= Settings ================= */
function phoneCard(ph) {
  if (!ph) return "";
  if (ph.from_phone) return `<div class="card"><h2>📱 Use on your phone</h2><p class="muted" style="margin:0">You're using WulfProtocol on your phone. Change the PIN or turn phone access off in Settings on your PC.</p></div>`;
  const on = ph.on && ph.has_pin;
  return `<div class="card" id="phonecard"><h2>📱 Use on your phone</h2>
    <p class="muted" style="margin-top:0">Open WulfProtocol on your phone when it's on the same Wi‑Fi as this PC. This PC has to be on with WulfProtocol running. Your phone asks for a PIN first.</p>
    ${on && ph.running ? `<div class="phaddr"><span class="small muted">On your phone, open ${ph.secure ? "Safari (iPhone) or Chrome (Android)" : "the browser"} and type:</span><b id="phaddr">${esc(ph.address || "(no Wi‑Fi address found)")}</b>${ph.secure && ph.ip_address ? `<span class="small muted">If that doesn't open, use <b>${esc(ph.ip_address)}</b> (this number can change when your router restarts).</span>` : ""}</div>` : ""}
    ${ph.error ? `<div class="alert" style="margin-bottom:10px">⚠ ${esc(ph.error)}</div>` : ""}
    <form id="phpin" class="form-grid"><label class="f">${ph.has_pin ? "Change PIN" : "Choose a PIN"} <span class="muted">(4 to 8 numbers)</span>
      <input id="phpinv" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="8" autocomplete="new-password"></label>
      <div class="actions" style="align-self:end"><button class="btn">${ph.has_pin ? "Change PIN" : "Save PIN"}</button></div></form>
    <label class="opt" style="margin-top:10px"><input type="checkbox" id="phon" ${on ? "checked" : ""} ${ph.has_pin ? "" : "disabled"}><span><b>Let my phone open WulfProtocol</b><small>${ph.has_pin ? "Only on your home Wi‑Fi, and only with the PIN" : "Choose a PIN first"}</small></span></label>
    ${on ? offlineBlock(ph) : ""}
    ${on ? `<p class="small muted" style="margin:10px 0 0">The first time, Windows may ask if Python can use the network. Choose <b>Allow</b> (Private networks).<br>Tip: on your phone, use “Add to Home Screen” to get an icon for it.</p>
      <div style="margin-top:10px"><button class="btn sm" id="phout">Sign out all phones</button></div>` : ""}</div>`;
}

function offlineBlock(ph) {
  const busy = ph.install === "running";
  const who = (() => { try { return localStorage.getItem("wp_phone_kind") || "iphone"; } catch (e) { return "iphone"; } })();
  const pcName = esc((ph.host || "").replace(".local", "") || "this PC");
  const alt = ph.ip_address ? ` If that doesn't open, use <b>${esc(ph.ip_address)}</b>.` : "";
  const iphone = `<ol class="steps small" data-kind="iphone" ${who === "iphone" ? "" : "hidden"}>
      <li>On your iPhone, open <b>Safari</b> (not Chrome) and type <b>${esc(ph.address)}</b>.${alt}</li>
      <li>Only this first time, Safari says the connection isn't private. Tap <b>Show Details</b>, then <b>visit this website</b>, then <b>Visit Website</b>.</li>
      <li>On the PIN page, tap <b>Install the certificate</b>, then <b>Allow</b>.</li>
      <li>Open the iPhone <b>Settings</b> app. Tap <b>Profile Downloaded</b> near the top, then <b>Install</b> (it asks for your phone passcode), then <b>Install</b> again.</li>
      <li>In Settings go to <b>General → About → Certificate Trust Settings</b> and turn on <b>WulfProtocol on ${pcName}</b>.</li>
      <li>Back in Safari, open the address again (no warning now) and enter your PIN. Then tap <b>Share → Add to Home Screen</b>. Always open WulfProtocol from that icon.</li></ol>`;
  const android = `<ol class="steps small" data-kind="android" ${who === "android" ? "" : "hidden"}>
      <li>On your Android phone, open <b>Chrome</b> and type <b>${esc(ph.address)}</b>.${alt} Some Android phones can't open the name address, so use the number one if needed.</li>
      <li>Only this first time, Chrome says <b>Your connection is not private</b>. Tap <b>Advanced</b>, then <b>Proceed</b>.</li>
      <li>On the PIN page, tap <b>Install the certificate</b>. It saves <b>WulfProtocol.crt</b> to your Downloads. If the phone says certificates must be installed in Settings, that's normal: tap <b>OK</b>.</li>
      <li>Open the phone's <b>Settings</b> app and search for <b>certificate</b>. Choose <b>Install a certificate</b> (or <b>Install from device storage</b>), then <b>CA certificate</b>, then <b>Install anyway</b>, and pick <b>WulfProtocol.crt</b> from Downloads. It may ask for your screen lock. The menu names differ a little between phone makers.</li>
      <li>Close Chrome completely, open the address again (no warning now) and enter your PIN. Then tap <b>⋮ → Add to Home screen</b> (or <b>Install app</b>). Always open WulfProtocol from that icon.</li></ol>`;
  const steps = ph.secure ? `<div class="row" style="margin-top:12px;gap:8px;align-items:center"><span class="small muted">Set-up steps for:</span>
      <span class="seg" id="phkind"><button type="button" data-k="iphone" class="${who === "iphone" ? "on" : ""}">iPhone</button><button type="button" data-k="android" class="${who === "android" ? "on" : ""}">Android</button></span></div>
      ${iphone}${android}
      <p class="small muted" style="margin:6px 0 0">This certificate only works for this PC on your home network. It can't be used for any other website.</p>` : "";
  return `<label class="opt" style="margin-top:10px"><input type="checkbox" id="phsec" ${ph.secure_wanted ? "checked" : ""} ${busy ? "disabled" : ""}><span><b>📴 Offline mode <span class="badge">beta</span></b><small>Your phone saves the app, so away from home you can see today's doses, your plan and the reference sheets, and log doses and weigh-ins. They sync by themselves when you're back on your Wi‑Fi. Needs a one-time setup on the phone.</small></span></label>
    ${busy ? `<p class="small" style="margin:8px 0 0">⏳ Setting up offline mode. Downloading the certificate tool takes about a minute…</p>` : ""}
    ${ph.install === "error" ? `<div class="alert" style="margin-top:8px">⚠ ${esc(ph.install_msg || "Setting up offline mode failed.")}</div>` : ""}
    ${steps}`;
}

function bindPhoneCard(view, ph) {
  const card = $("#phonecard", view); if (!card) return;
  const put = async (body, msg) => { try { await api("/phone", "PUT", body); toast(msg); Router.render(); } catch (e) { toast(e.message, true); } };
  $("#phpin", card).onsubmit = async e => {
    e.preventDefault(); const v = $("#phpinv", card).value.trim();
    if (!/^\d{4,8}$/.test(v)) return toast("The PIN must be 4 to 8 numbers", true);
    await put({ pin: v }, ph.has_pin ? "PIN changed. Phones need the new PIN." : "PIN saved");
  };
  $("#phon", card).onchange = e => put({ on: e.target.checked }, e.target.checked ? "Phone access is on" : "Phone access is off");
  const out = $("#phout", card); if (out) out.onclick = () => put({ sign_out_all: true }, "All phones signed out");
  $$("#phkind button", card).forEach(b => b.onclick = () => {
    try { localStorage.setItem("wp_phone_kind", b.dataset.k); } catch (e) { /* not remembered */ }
    $$("#phkind button", card).forEach(x => x.classList.toggle("on", x === b));
    $$(".steps[data-kind]", card).forEach(o => o.hidden = o.dataset.kind !== b.dataset.k);
  });
  const sec = $("#phsec", card); if (sec) sec.onchange = () => put({ secure: sec.checked }, sec.checked ? "Setting up offline mode" : "Offline mode is off");
  if (ph.install === "running") setTimeout(() => { if ($("#phonecard")) Router.render(); }, 3000);      // check again until it's ready
}

const GLOW_THEMES = [["emerald", "Emerald"], ["aqua", "Aqua"], ["violet", "Violet"], ["rose", "Rose"], ["gold", "Gold"], ["rainbow", "Rainbow"]];
Pages.settings = async function (view) {
  await refreshSettings();
  const s = App.settings, auto = await api("/autostart").catch(() => ({ supported: false }));
  const ph = await api("/phone").catch(() => null), bk = await api("/backups").catch(() => null);
  view.innerHTML = `<div class="page-head"><div><h1>Settings</h1></div><button class="btn" id="rerun">Run setup again</button></div>
    <div class="grid cols-2"><div class="stack">
      <div class="card"><h2>Your name</h2><form id="fn" class="form-grid"><label class="f full">Shown in the dashboard greeting<input name="uname" value="${esc(s.user_name || "")}" placeholder="e.g. Ken" maxlength="40"></label>
        <div class="actions full"><button class="btn primary">Save</button></div></form></div>
      <div class="card"><h2>Glow &amp; launch screen</h2><p class="muted small" style="margin-top:-4px">The colour used for the launch screen and for the short glow around important things on the dashboard.</p>
        <div class="glowpick" id="glowpick">${GLOW_THEMES.map(([k, n]) => `<label class="gp ${s.glow_theme === k ? "on" : ""}" data-g="${k}" title="${n}"><input type="radio" name="glow_theme" value="${k}" ${s.glow_theme === k ? "checked" : ""}><i class="gp-sw" data-glow="${k}"></i><span>${n}</span></label>`).join("")}</div>
        <label class="opt" style="margin-top:10px"><input type="checkbox" id="glowon" ${s.glow_on !== false ? "checked" : ""}><span><b>Glow around important items</b><small>Plays for about 4 seconds each time the dashboard opens</small></span></label>
        <div class="glassdash mini" style="margin-top:12px"><div class="tile" id="glowdemo"><div class="k">Preview</div><div class="s">This is how the glow looks</div></div></div>
        <div style="margin-top:10px"><button class="btn" type="button" id="glowplay">▶ Play preview</button></div></div>
      <div class="card"><h2>What you use</h2><p class="muted small" style="margin-top:-4px">Anything turned off is hidden and doesn't run in the background.</p>
        <form id="ff"><div class="opts" style="margin-top:0">
          <label class="opt"><input type="checkbox" name="use_meds" ${s.use_meds ? "checked" : ""}><span><b>💉 Peptides &amp; medications</b></span></label>
          <label class="opt"><input type="checkbox" name="use_fitness" ${s.use_fitness ? "checked" : ""}><span><b>⚖️ Fitness tracking</b></span></label>
          <label class="opt"><input type="checkbox" name="use_calc" ${s.use_calc ? "checked" : ""}><span><b>🧮 Calculator</b></span></label>
          <label class="opt"><input type="checkbox" name="use_prices" ${s.use_prices ? "checked" : ""}><span><b>🏷️ Live price tracking</b><small>Runs a web scraper in the background</small></span></label></div>
          <div style="margin-top:12px"><button class="btn primary">Save</button></div></form></div>
      ${s.use_fitness ? `<div class="card"><h2>Weigh-in reminder</h2><form id="fw" class="form-grid">
        <label class="f full">Remind me on the dashboard after this many days without a weigh-in<input type="number" min="0" max="365" name="weigh_reminder_days" value="${s.weigh_reminder_days ?? 7}"></label>
        <p class="small muted full" style="margin:0">Use 0 to turn the reminder off.</p>
        <div class="actions full"><button class="btn primary">Save</button></div></form></div>` : ""}
      ${s.use_meds ? `<div class="card"><h2>Doses</h2><form id="fd" class="form-grid">
        <label class="f">Count a dose as missed after (minutes)<input type="number" min="0" name="grace_minutes" value="${s.grace_minutes}"></label>
        <div class="full"><button class="btn primary">Save</button></div></form>
        <label class="opt" style="margin-top:14px"><input type="checkbox" id="popups" ${s.dose_popups ? "checked" : ""}><span><b>🔔 Pop-up reminder when a dose is due</b><small>A small Windows notification on this PC at each dose time, for example “Time for LL-37 · 200 mcg”. “Any time” doses don't pop up.</small></span></label>
        <div style="margin-top:8px"><button class="btn sm" type="button" id="poptest">Send a test pop-up</button></div></div>` : ""}
      ${s.use_prices ? `<div class="card"><h2>Price tracking</h2><form id="fp" class="form-grid">
        <label class="f">Re-check prices every (hours)<input type="number" min="0.5" step="0.5" name="check_hours" value="${s.check_hours}"></label>
        <label class="chk full"><input type="checkbox" name="auto_check" ${s.auto_check ? "checked" : ""}> Check prices automatically while the app is running</label>
        <div class="full"><button class="btn primary">Save</button></div></form>
        <h3 style="margin:18px 0 6px">Sign-in mode</h3>
        <p class="muted small" style="margin-top:0">For stores that need an account: press the 🌐 button on that store in <a href="#/prices">Price watch</a> and choose “Sign in for price checks”. A real browser window opens, you log in yourself, and close it. Session cookies are kept in a private profile inside the <code>data</code> folder. <b>Your password is never seen or stored by this app.</b></p>
        <label class="f" style="margin:6px 0 10px;max-width:420px">Browser for sign-in windows
          <select id="bpref"><option value="auto" ${s.browser_pref === "auto" ? "selected" : ""}>Automatic — my default browser</option>
            <option value="chrome" ${s.browser_pref === "chrome" ? "selected" : ""}>Google Chrome${s.browser.chrome ? "" : " (not found)"}</option>
            <option value="edge" ${s.browser_pref === "edge" ? "selected" : ""}>Microsoft Edge${s.browser.edge ? "" : " (not found)"}</option></select>
          <span class="small muted">Currently using: <b>${esc(s.browser.using_name)}</b>. Also used for the WulfProtocol app window. It uses its own private sign-in profile, so your normal browsing isn't touched.</span></label>
        <div id="bbox"></div></div>` : ""}
    </div><div class="stack"><div class="card"><h2>Your data</h2>
      <p class="muted" style="margin-top:0">Everything is stored on this computer in:<br><code>${esc(s.data_dir)}</code></p>
      <a class="btn" href="/api/export">⬇ Download full backup (JSON)</a>
      <p class="small muted">To back up or move everything, copy the <code>data</code> folder.</p>
      ${bk ? `<p class="small" style="margin-bottom:0">🛟 <b>Automatic backup:</b> ${bk.latest ? `last one ${esc(fmtDate(bk.latest))}` : "the first one is made shortly"}. A copy is saved every day and the last ${bk.keep} days are kept in <code>${esc(bk.folder)}</code>.</p>` : ""}</div>
      ${phoneCard(ph)}
      <div class="card"><h2>App version <span class="badge" id="ver"></span></h2>
        <p class="small" style="margin-top:0;font-weight:600" id="relline"></p>
        <p class="muted" style="margin-top:0" id="updmsg">Checking for updates…</p>
        <div class="row wrap" style="gap:8px"><button class="btn" id="updcheck">🔄 Check for updates</button><button class="btn primary" id="updgo" style="display:none">⬇ Install the update</button></div>
        <label class="chk" style="margin-top:12px"><input type="checkbox" id="updauto" ${s.auto_update_check !== false ? "checked" : ""}> Look for updates when the app opens <span class="muted">(it never installs anything unless you tap Install)</span></label>
        <p class="small muted" style="margin:12px 0 6px">Got an update file instead? Choose it here. Only the app itself is replaced. Your data stays exactly as it is, and a backup copy is made first.</p>
        <input type="file" id="updz" accept=".zip,.wulf" style="display:none"><button class="btn sm" id="upd">📦 Install an update from a file…</button></div>
      <div class="card"><h2>Send feedback</h2>
        <p class="muted" style="margin-top:0">Found a bug, or have an idea? Tell me and it goes straight to my inbox. Only what you type is sent, plus the app version. None of your medications, prices or logs.</p>
        <button class="btn" id="fbopen">💬 Send feedback</button></div>
      <div class="card"><h2>Running in the background</h2>
        <p class="muted" style="margin-top:0">Closing this window leaves WulfProtocol running quietly in the background, so price checks keep going. Click your desktop icon to open it again.</p>
        ${auto.supported ? `<label class="chk"><input type="checkbox" id="autostart" ${auto.enabled ? "checked" : ""}> Start WulfProtocol automatically when I sign in to Windows</label>` : ""}
        <div class="row wrap" style="margin-top:12px"><button class="btn danger" id="quit">⏻ Quit WulfProtocol completely</button><button class="btn" id="viewlog">View log</button></div>
        <p class="small muted" style="margin-bottom:0">You can also stop it from Task Manager: end the process named <b>Python</b>.</p></div></div></div>`;
  const save = async (body, msg) => { await api("/settings", "PUT", body); await refreshSettings(); toast(msg || "Saved"); };
  if (ph && ph.from_phone) {        // on the phone: PC-only buttons are hidden (the PC refuses them anyway)
    ["#quit", "#updgo", "#upd", "#autostart"].forEach(q => { const e = $(q, view); if (e) (e.closest("label.chk") || e).style.display = "none"; });
    const u = $("#upd", view); if (u) u.insertAdjacentHTML("afterend", '<p class="small muted" style="margin:0">Install updates and quit the app on your PC.</p>');
  }
  bindPhoneCard(view, ph);
  $("#rerun", view).onclick = () => Wizard.start();
  $("#fbopen", view).onclick = () => {
    const m = modal(`<h2>Send feedback</h2>
      <div class="row wrap" style="gap:8px;margin-bottom:10px" id="fbk">${["🐞 Something's broken", "💡 Idea", "💬 Other"].map((k, i) => `<button type="button" class="btn sm ${i ? "" : "sel"}" data-k="${esc(k.slice(3))}">${k}</button>`).join("")}</div>
      <label class="f">What happened, or what would you like?<textarea id="fbmsg" rows="6" maxlength="4000" placeholder="Tell me what you were doing and what you expected to happen."></textarea></label>
      <div class="form-grid"><label class="f">Your name <span class="muted">(optional)</span><input id="fbname" maxlength="80"></label>
      <label class="f">Email for a reply <span class="muted">(optional)</span><input id="fbmail" type="email" maxlength="120"></label></div>
      <p class="small muted">Sent with: app version${window.lastRoute ? " and the page you were on (" + esc(window.lastRoute) + ")" : ""}. Nothing else from your data.</p>
      <div id="fbfail"></div>
      <div class="actions"><button class="btn" data-close>Cancel</button><button class="btn primary" id="fbsend">Send</button></div>`);
    let kind = "Something's broken";
    $$("#fbk .btn", m.el).forEach(b => b.onclick = () => { kind = b.dataset.k; $$("#fbk .btn", m.el).forEach(x => x.classList.toggle("sel", x === b)); });
    $("#fbsend", m.el).onclick = e => run(e.target, async () => {
      try {
        await api("/feedback", "POST", { kind, message: $("#fbmsg", m.el).value, name: $("#fbname", m.el).value, email: $("#fbmail", m.el).value, page: window.lastRoute || "" });
        m.close(); toast("Sent. Thank you!");
      } catch (err) {
        if (!/automatically/.test(err.message)) throw err;
        const body = `${$("#fbmsg", m.el).value}\n\n---\nFrom: ${$("#fbname", m.el).value || "(no name)"} ${$("#fbmail", m.el).value}\nType: ${kind}\nPage: ${window.lastRoute || ""}\nVersion: ${($("#ver") || {}).textContent || ""}`;
        $("#fbfail", m.el).innerHTML = `<div class="alert" style="margin:0 0 10px">${esc(err.message)}<br>You can send it from your own email instead: <a class="btn sm" href="mailto:dollyj.916@gmail.com?subject=${encodeURIComponent("WulfProtocol feedback: " + kind)}&body=${encodeURIComponent(body)}">✉ Open my email app</a> <button type="button" class="btn sm" id="fbcopy">Copy the message</button></div>`;
        $("#fbcopy", m.el).onclick = async () => { try { await navigator.clipboard.writeText("To: dollyj.916@gmail.com\n\n" + body); toast("Copied. Paste it into an email to dollyj.916@gmail.com"); } catch (x) { toast("Couldn't copy", true); } };
      }
    });
  };

  const as = $("#autostart", view);
  if (as) as.onchange = async () => {
    try { await api("/autostart", "POST", { enabled: as.checked }); toast(as.checked ? "Will start automatically with Windows" : "Won't start automatically"); }
    catch (e) { as.checked = !as.checked; toast(e.message, true); }
  };
  api("/version").then(v => { const r = v.release || {}; $("#ver", view).textContent = relName(r).replace(/ \(.*\)$/, "");
    $("#relline", view).innerHTML = `${esc(r.codename || "")} · ${esc(r.status || "")} · Version ${esc(r.version || "")}${r.updated ? `<br><span class="muted">Last updated ${esc(fmtUpdated(r.updated))}</span>` : ""}`; }).catch(() => {});
  const showUpd = u => {
    const m = $("#updmsg", view), go = $("#updgo", view); if (!m) return;
    go.style.display = u && u.newer ? "" : "none";
    m.innerHTML = !u ? "Couldn't check right now."
      : !u.configured ? "This copy isn't connected to an update page, so use the file option below."
      : u.error ? esc(u.error)
      : u.newer ? `<b>${relName(u.release) === relName(u.current_release) ? "A newer build of " + esc(relName(u.release)) : esc(relName(u.release))} is available.</b>${u.notes ? "<br>" + esc(u.notes) : ""}`
      : `You're up to date: ${esc(relName(u.current_release))}.`;
  };
  UpdateUI.check(false).then(showUpd);
  $("#updcheck", view).onclick = async () => { $("#updmsg", view).textContent = "Checking…"; showUpd(await UpdateUI.check(true)); };
  $("#updgo", view).onclick = () => UpdateUI.install($("#updgo", view));
  $("#updauto", view).onchange = async e => { await api("/settings", "PUT", { auto_update_check: e.target.checked }); await refreshSettings(); toast("Saved"); };
  $("#upd", view).onclick = () => $("#updz", view).click();
  $("#updz", view).onchange = async e => {
    const file = e.target.files[0]; if (!file) return;
    const fd = new FormData(); fd.append("file", file);
    const r = await fetch("/api/update", { method: "POST", headers: { "X-WulfProtocol": "1" }, body: fd });
    const d = await r.json().catch(() => ({}));
    e.target.value = "";
    if (!r.ok) return toast(d.error || "Update failed", true);
    try { await fetch("/api/shutdown", { method: "POST", headers: { "X-WulfProtocol": "1" } }); } catch (x) { /* stopping */ }
    document.body.innerHTML = `<div style="font-family:system-ui;text-align:center;margin:20vh auto;max-width:440px;color:#667085"><h2 style="color:#18212f">Updated to ${esc(relName(d.release))}</h2><p>${d.files} files installed${d.backup ? ` and a backup of your data saved as <b>${d.backup}</b>` : ""}.</p><p>Open WulfProtocol again from your desktop icon to start the new version.</p></div>`;
  };
  $("#viewlog", view).onclick = async () => { const r = await api("/log"); modal(`<h2>Log</h2><pre style="max-height:55vh;overflow:auto;white-space:pre-wrap;font-size:.8rem">${esc(r.log)}</pre><div class="actions"><button class="btn" data-close>Close</button></div>`, { wide: true }); };
  $("#quit", view).onclick = async () => {
    if (!(await confirmBox("Quit WulfProtocol completely? Price checks will stop until you open it again from your desktop icon.", "Quit"))) return;
    try { await fetch("/api/shutdown", { method: "POST", headers: { "X-WulfProtocol": "1" } }); } catch (e) { /* already stopping */ }
    document.body.innerHTML = '<div style="font-family:system-ui;text-align:center;margin:20vh auto;max-width:420px;color:#667085"><h2 style="color:#18212f">WulfProtocol has stopped</h2><p>You can close this tab. To use it again, open it from your desktop icon.</p></div>';
  };
  $("#ff", view).onsubmit = async e => {
    e.preventDefault(); const f = new FormData(e.target);
    const body = { use_meds: !!f.get("use_meds"), use_fitness: !!f.get("use_fitness"), use_prices: !!f.get("use_prices"), use_calc: !!f.get("use_calc") };
    if (!body.use_meds && !body.use_fitness && !body.use_prices) return toast("Keep at least one turned on", true);
    await run($(".primary", e.target), async () => { await save(body); Router.render(); });
  };
  $("#fn", view).onsubmit = async e => { e.preventDefault(); await run(null, async () => { await save({ user_name: (new FormData(e.target).get("uname") || "").trim() }); Router.render(); }); };
  const fw = $("#fw", view); if (fw) fw.onsubmit = async e => { e.preventDefault(); const n = Math.max(0, Math.min(365, parseInt(new FormData(e.target).get("weigh_reminder_days"), 10) || 0)); await run(null, () => save({ weigh_reminder_days: n })); Router.render(); };
  const pu = $("#popups", view); if (pu) pu.onchange = () => run(null, () => save({ dose_popups: pu.checked }, pu.checked ? "Dose pop-ups are on" : "Dose pop-ups are off"));
  const pt = $("#poptest", view); if (pt) pt.onclick = () => run(pt, async () => { await api("/reminders/test", "POST"); toast("Test pop-up sent. Look at the bottom-right of your screen."); });
  const fd = $("#fd", view); if (fd) fd.onsubmit = async e => { e.preventDefault(); await run(null, () => save({ grace_minutes: +new FormData(e.target).get("grace_minutes") })); };
  const fp = $("#fp", view); if (fp) fp.onsubmit = async e => { e.preventDefault(); const f = new FormData(e.target); await run(null, () => save({ check_hours: +f.get("check_hours"), auto_check: !!f.get("auto_check") })); };
  const playGlow = () => { const t = $("#glowdemo", view); if (!t) return; t.classList.remove("glow"); void t.offsetWidth; t.classList.add("glow"); setTimeout(() => t.classList.remove("glow"), 4300); };
  $$("#glowpick input", view).forEach(r => r.onchange = async () => { await api("/settings", "PUT", { glow_theme: r.value }); await refreshSettings(); $$("#glowpick .gp", view).forEach(l => l.classList.toggle("on", l.dataset.g === r.value)); playGlow(); });
  const go = $("#glowon", view); if (go) go.onchange = async () => { await api("/settings", "PUT", { glow_on: go.checked }); await refreshSettings(); toast("Saved"); if (go.checked) playGlow(); };
  const gpl = $("#glowplay", view); if (gpl) gpl.onclick = playGlow;
  const bb = $("#bbox", view); if (bb) browserBox(bb);
  const bp = $("#bpref", view); if (bp) bp.onchange = async () => { await api("/settings", "PUT", { browser_pref: bp.value }); toast("Saved"); Router.render(); };
};

/* ================= Router ================= */
const Router = {
  async render() {
    const view = $("#view"), parts = (location.hash.slice(2) || "dashboard").split("/"), route = parts[0];
    $$("nav a").forEach(a => a.classList.toggle("on", a.dataset.r === route)); if (route !== "settings") window.lastRoute = route;
    App.glowNow = App.curRoute !== route; App.curRoute = route;
    view.classList.remove("page-enter"); if (App.glowNow) { void view.offsetWidth; view.classList.add("page-enter"); }          // pages ease in when you move between them, not on every refresh          // the glow plays when you arrive on a page, not on every refresh of it
    applyNav();
    const f = feat();
    if (["meds", "fitness", "prices", "calculator"].includes(route) && !f[route]) {
      view.innerHTML = `<div class="card empty"><b>This section is turned off</b>You can turn it on any time in Settings.<br><br><a class="btn primary" href="#/settings">Open Settings</a></div>`;
      return;
    }
    try {
      if (route === "meds" && parts[1]) await Pages.med(view, parts[1]);
      else if (Pages[route]) await Pages[route](view);
      else location.hash = "#/dashboard";
      if (window.Offline) Offline.decorate(view);
    } catch (e) {
      view.innerHTML = `<div class="card"><h2>Something went wrong</h2><p class="muted">${esc(e.message)}</p>${/not found/i.test(e.message) ? `<p class="muted">This usually means the app engine is still running an older version. Close this window, open the WulfProtocol icon on your desktop's system tray or task manager and end "python"/"pythonw" (or use Settings, Quit WulfProtocol completely), then open it again from the desktop icon.</p>` : ""}<button class="btn" onclick="Router.render()">Retry</button></div>`;
    }
    Router.badge();
  },
  setBadge(n) { const b = $("#nav-alert"); b.hidden = !n; b.textContent = n; document.title = (n ? `(${n}) ` : "") + "WulfProtocol"; },
  async badge() {
    if ((location.hash.slice(2) || "dashboard").startsWith("dashboard")) return;   // dashboard sets it itself
    try { const d = await api("/dashboard"); Router.setBadge(d.due.length + d.missed.length); } catch (e) { /* ignore */ }
  },
};
window.addEventListener("hashchange", () => Router.render());
(async function boot() {
  try { [App.profile, App.settings, App.routes] = await Promise.all([api("/profile"), api("/settings"), api("/route-types")]); applyGlow(); } catch (e) { /* ignore */ }
  setInterval(() => { if (!document.hidden && !$(".modal-bg") && !$("#wizard") && (location.hash === "" || location.hash.startsWith("#/dashboard"))) Router.render(); }, 60000);
  window.__appReady = true;
  try {
    if (App.settings && !App.settings.setup_done) { applyNav(); Wizard.start(); return; }
    await Router.render();                  // a failure here shows the app's own error card with a Retry button
  } finally { if (window.Splash) Splash.ready(); }
  if (App.settings && App.settings.auto_update_check !== false) UpdateUI.check(false).then(u => { if (u && u.newer && (location.hash === "" || location.hash.startsWith("#/dashboard"))) Router.render(); });
})();
