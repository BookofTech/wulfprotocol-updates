/* Injection-site / rotation helpers, body map, vial draw calculator */

// [view, x, y] in a 150-wide figure. Front view: patient's LEFT is on the viewer's right. Back view: patient's left is viewer's left.
const BODY = {
  "Abdomen L": ["front", 88, 118], "Abdomen R": ["front", 62, 118], "Thigh L": ["front", 88, 200], "Thigh R": ["front", 62, 200],
  "Quad L": ["front", 90, 184], "Quad R": ["front", 60, 184], "Deltoid L": ["front", 107, 66], "Deltoid R": ["front", 43, 66],
  "Upper arm L": ["front", 119, 96], "Upper arm R": ["front", 31, 96],
  "Glute L": ["back", 61, 150], "Glute R": ["back", 89, 150], "Flank L": ["back", 53, 112], "Flank R": ["back", 97, 112],
  "Arm (back) L": ["back", 31, 92], "Arm (back) R": ["back", 119, 92],
};
const FIGURE = `<circle cx="75" cy="26" r="16"/><rect x="69" y="40" width="12" height="12" rx="3"/>
  <path d="M42 56 Q75 46 108 56 L104 130 Q103 150 98 160 L52 160 Q47 150 46 130 Z"/>
  <path d="M40 58 Q28 62 26 90 L22 135 Q22 142 30 142 Q36 142 37 135 L46 92 Z"/><path d="M110 58 Q122 62 124 90 L128 135 Q128 142 120 142 Q114 142 113 135 L104 92 Z"/>
  <path d="M52 158 L74 158 L71 250 L66 316 L52 316 L50 250 Z"/><path d="M76 158 L98 158 L100 250 L98 316 L84 316 L79 250 Z"/>`;

const routeOf = m => (App.routes || {})[m.route_type] || (App.routes || {}).other || { label: "", short: "", icon: "💠", sites: [], expiry: true };
const daysSince = iso => iso ? Math.round((parseLocal(todayStr() + "T00:00") - parseLocal(iso.slice(0, 10) + "T00:00")) / 864e5) : null;
function agoText(iso) { const d = daysSince(iso); return d == null ? "never" : d <= 0 ? "today" : d === 1 ? "yesterday" : `${d} days ago`; }
const recency = iso => { const d = daysSince(iso); return d == null ? "rest" : d <= 3 ? "hot" : d <= 7 ? "warm" : "rest"; };

function bodyMap(info) {
  const dots = info.sites.filter(s => BODY[s.site]).map(s => {
    const [view, x, y] = BODY[s.site], dx = view === "back" ? 160 : 0, next = s.site === info.suggest;
    return `<g class="site ${next ? "next" : ""}"><title>${esc(s.site)} — last used ${agoText(s.last)}${next ? " (next suggested)" : ""}</title>
      ${next ? `<circle class="pulse" cx="${x + dx}" cy="${y}" r="9"/>` : ""}<circle class="sd ${recency(s.last)}" cx="${x + dx}" cy="${y}" r="8"/></g>`;
  }).join("");
  return `<svg class="bodymap" viewBox="0 0 310 336" role="img" aria-label="Injection site map">
    <g class="body-fig">${FIGURE}</g><g class="body-fig" transform="translate(160,0)">${FIGURE}</g>${dots}
    <text x="75" y="334" text-anchor="middle" class="tick">FRONT</text><text x="235" y="334" text-anchor="middle" class="tick">BACK</text></svg>
    <div class="legend"><span><i style="background:var(--bad)"></i>used in last 3 days</span><span><i style="background:var(--warn)"></i>4–7 days</span>
      <span><i style="background:var(--ok)"></i>rested / unused</span><span><i style="background:none;border:2px solid var(--accent);border-radius:50%"></i>next suggested</span></div>
    <p class="small muted" style="margin:6px 0 0">L / R = <b>your</b> left and right.</p>`;
}

/* radio chips for choosing a site in the log dialog */
function siteChips(info, selected) {
  return `<div class="chips">${info.sites.map(s => `<label class="chip"><input type="radio" name="site" value="${esc(s.site)}" ${s.site === selected ? "checked" : ""}>
    <span>${esc(s.site)}${s.site === info.suggest ? ' <b class="star">★ next</b>' : ""}<small>${s.last ? agoText(s.last) : "never used"}</small></span></label>`).join("")}</div>`;
}

/* checklist used when customizing which sites are in the rotation */
function siteChecklist(type, selected) {
  const defaults = (App.routes[type] || {}).sites || [];
  const extra = type === "nasal" ? [] : Object.keys(BODY).filter(s => !defaults.includes(s));
  const custom = (selected || []).filter(s => !defaults.includes(s) && !BODY[s]);
  return [...defaults, ...extra, ...custom].map(s => `<label><input type="checkbox" name="rsite" value="${esc(s)}" ${(selected || defaults).includes(s) ? "checked" : ""}>${esc(s)}</label>`).join("");
}
function wireChecklist(root, type) {
  const box = $(".daypick", root), add = $("[data-addsite]", root), input = $("[data-newsite]", root);
  if (add) add.onclick = () => {
    const v = input.value.trim(); if (!v) return;
    const l = document.createElement("label"); l.innerHTML = `<input type="checkbox" name="rsite" value="${esc(v)}" checked>${esc(v)}`; box.appendChild(l); input.value = "";
  };
}
function readChecklist(root, type) {            // null = "use the defaults"
  const picked = $$("input[name=rsite]:checked", root).map(i => i.value), def = (App.routes[type] || {}).sites || [];
  return picked.length === def.length && picked.every(s => def.includes(s)) ? null : picked;
}

/* vial maths: how much to draw for a dose (volume = dose / concentration; U-100 syringe = 100 units per mL) */
const MASS = { mcg: 1, ug: 1, "µg": 1, mg: 1000, g: 1e6 };
function vialInDoseUnit(m) {
  if (!(m.vial_amount > 0)) return null;
  if (String(m.dose_unit || "").toLowerCase() === "units") return m.diluent_ml > 0 ? m.diluent_ml * 100 : null;   // syringe marks: a whole vial is 100 per mL
  const vu = (m.vial_unit || m.dose_unit || "").toLowerCase(), du = (m.dose_unit || "").toLowerCase();
  if (vu === du) return m.vial_amount;
  return MASS[vu] && MASS[du] ? m.vial_amount * MASS[vu] / MASS[du] : null;
}
/* a dose written in syringe marks ("units" on a U-100 insulin syringe, 100 marks = 1 mL): how much medication that is, from the vial's strength */
const isMarks = m => String((m && m.dose_unit) || "").toLowerCase() === "units";
function marksInfo(m, dose) {
  const n = dose ?? m.dose;
  if (!isMarks(m) || !(n > 0) || !(m.vial_amount > 0 && m.diluent_ml > 0)) return null;
  const conc = m.vial_amount / m.diluent_ml, ml = n / 100;
  return { ml, conc, amount: conc * ml, unit: m.vial_unit || "mg" };
}
const marksText = (m, dose) => { const k = marksInfo(m, dose); return k ? `${num(k.amount, 3)} ${k.unit}` : ""; };
function drawInfo(m) {
  const click = m.container === "pen" && +m.click_amt > 0 ? +m.click_amt : 0;      // your pen's own click size (in the dose unit), if you set it
  if (click && m.dose > 0) {                       // your own click size wins; strength isn't needed (but gives the mL when it's known)
    const v = m.diluent_ml > 0 ? (isMarks(m) ? m.diluent_ml * 100 : vialInDoseUnit(m)) : null, conc = v ? v / m.diluent_ml : null;
    return { conc, ml: conc ? m.dose / conc : null, units: m.dose / click, doses: v ? v / m.dose : null, pen: true, perClick: click, custom: true, cartDoses: null };
  }
  if (!(m.vial_amount > 0 && m.diluent_ml > 0 && m.dose > 0)) return null;
  const k = marksInfo(m);                          // the dose is already the marks: 100 per mL
  if (k) return { conc: 100, ml: k.ml, units: m.dose, doses: m.diluent_ml / k.ml, pen: m.container === "pen", perClick: 1, cartDoses: Math.min(3, m.diluent_ml) / k.ml, marks: k };
  const v = vialInDoseUnit(m);
  if (v == null) return { error: "The vial unit and the dose unit don't match (for example mg vs IU), so the draw amount can't be calculated." };
  const conc = v / m.diluent_ml, ml = m.dose / conc, pen = m.container === "pen";
  return { conc, ml, units: ml * 100, doses: v / m.dose, pen, perClick: conc / 100, cartDoses: Math.min(3, m.diluent_ml) / ml };
}
/* a peptide pen dials in units: 1 unit = 1 click = 0.01 mL (the same U-100 scale as an insulin syringe) */
const drawText = d => d && !d.error ? (d.pen ? `Dial <b>${num(d.units, 1)} ${d.custom ? "clicks" : "units"}</b> (${d.custom ? "" : num(d.units, 1) + " clicks" + (d.ml != null ? ", " : "")}${d.ml != null ? num(d.ml, 3) + " mL" : ""}) on your pen` : `Draw <b>${num(d.units, 1)} units</b> (${num(d.ml, 3)} mL) on a U-100 insulin syringe`) : "";
