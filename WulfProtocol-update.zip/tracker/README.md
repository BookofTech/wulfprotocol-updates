# WulfProtocol
*Track. Optimize. Evolve.* — Biohacking & health management

A private, local app for tracking peptides/meds, fitness measurements, and prices.
Everything is stored on your computer in `data/tracker.db`. Nothing is sent anywhere except the price checks themselves.

## Run it
**Windows (recommended):** double-click **`create_shortcut.bat`** once. It sets everything up (about 1-2 minutes the first time),
puts a WulfProtocol icon on your Desktop, and opens the app. After that, just click the Desktop icon.

* The icon opens the app in **its own window** (Edge or Chrome app mode: no tabs or address bar). Behind the scenes a small
  engine runs invisibly in the background.
* **Closing the window does not stop it**, so price checks keep running. Click the icon again any time to reopen it.
* To stop it completely: **Settings -> Quit WulfProtocol completely**, or end the process named **Python** in Task Manager.
* **Settings -> Running in the background** can start it automatically when you sign in to Windows, and has a *View log* button for troubleshooting.
* `start.bat` runs the engine in a visible window instead (handy if something goes wrong and you want to see error messages).

**Mac:** double-click `WulfProtocol.command`.  **Linux:** `./start.sh`.  Python 3.9+ required.

## First-run setup
The first time it opens, a short setup asks what you want to use: **peptides & meds**, **fitness tracking**
and/or **live price tracking**, plus a few preferences (units, how strict missed-dose alerts are, how often to check prices).
Anything you leave off is hidden and doesn't run in the background — price tracking (the web scraper) is **off unless you turn it on**.
Change your mind any time in **Settings → What you use**, or press *Run setup again*.

## What's in it
**Dashboard** – due now, missed doses (last 7 days), refills due, 30-day adherence, today's schedule,
the next 4 days, cycle status (ON/OFF day counter + when the next phase starts), weight snapshot, price drops.
Missed doses stay on the dashboard until you log them ("Log taken", with the actual time) or skip them.

**Medication** – tell it *how you take it* and it adapts: subQ or IM injection, nasal spray, oral tablet/capsule, oral liquid,
sublingual, or topical/transdermal. Per medication: dose/unit, schedule (daily, every N days, specific weekdays, several times
a day, as-needed), start/end date, **cycles** (e.g. 28 on / 14 off – no doses are scheduled in OFF weeks), stock on hand with a
refill forecast, adherence and a doses-per-week chart. Stock counts down as you log doses; use *Restock* when you refill.
A dose counts as "missed" after a grace period (Settings, default 3 h).
* **Site rotation** (injections, nasal sprays, topicals): every dose logs where you took it. The app shows the **last site used**
  and **suggests the next one** – the site you've rested the longest – with a front/back body map colored by how recently each
  site was used. Pick a different site any time, untick sites you want to skip, or add your own.
* **Draw calculator** (injections): enter the vial size and water added, and it shows how many units to draw per dose on a U-100
* **Vials and pens**: in the medication form, "What you have" asks whether you have *a ready-to-use liquid vial* or *a ready-made 3 mL pen cartridge*, and (for a vial) whether you draw it with a syringe or load it into a pen. Enter what the label shows, either the total amount (e.g. 10 mg in 2 mL) or the amount per mL (e.g. 5 mg/mL). The app then shows how many syringe units to draw, or how many units to dial on a pen (1 unit = 1 click = 0.01 mL), and the Log dose window asks for the units you dialed. Medications saved earlier keep working: their "vial size" and "water added" are simply read as total amount and total liquid. In Inventory, a cartridge item shows *Open a cartridge*.
  syringe. Always double-check against your own protocol or prescriber.
* **Vial / bottle shelf life**: enter when it was opened or mixed and how many days it's good for; the dashboard warns you
  before it expires. *Restock → new vial* restarts the clock.
* Tip: enter stock in the same unit as the dose (e.g. a 5 mg vial of a 250 mcg-dose peptide = 5000 mcg).

**Inventory** – what you have on hand: peptide vials, medications and supplies (syringes, needles, swabs, bacteriostatic water…).
Quick-add common items, then use −1/+1 or *Adjust* (added, used, discarded, set exact) – every change is kept in a history.
* **Alerts**: set a "warn me at" level per item and an expiry date; low, out-of-stock and expiring items show on the Inventory page and the Dashboard.
* **Started earlier? Catch up**: if you began a medication before you added it, set the Start date to the real day. A "Started earlier? Catch up" box appears. It records the scheduled doses since then as taken (marked "added by catch-up" in the history), and if you enter how much you had on the start date it works out how much is left and how many doses that covers. Supplies like needles aren't changed.
* **Quick add**: the ⚡ Quick add button on the Medication page opens a searchable list of your saved reference sheets (68 loaded from your PDF, grouped). Pick one and the Add form opens pre-filled (dose, route, schedule, vial size and water where the sheet says so; check anything it flags), then you choose Vial or Pen and your supplies. The sheet is kept with the medication and shown in a **Reference** card on its page. Use ✎ in the list to edit or delete an item, or "+ New item" to add your own. The list lives in `library_seed.json` only for the first run; after that it is stored in your database.
* **Quicker daily use**: the Medication page opens with a **Today** list (missed and today's doses, each with a Take button). Every medication card has a **Take now** button that logs a dose right now, using the nearest scheduled dose and the suggested site, with an **Undo** for a few seconds. The Add form is short (name, how you take it, dose, schedule, start date); everything else is under **More options**.
* **Auto-use**: when you add or edit a medication, tick the supplies it uses (needles, swabs…) under "Supplies used with each dose" and say how many each dose uses. They count down by themselves each time you log a dose, and a deleted dose log puts them back. A supply can be shared by several medications. How much of the medication is left is tracked separately on the Medication tab. Vials are not supplies: link a vial item to its medication in Inventory and use Open a vial.
* **Vials**: link a vial item to its medication and press *Open a vial* to take one from inventory and add its contents to the medication's stock
  (restarting the shelf-life clock). Days of supply include unopened vials.
* **Reorder**: link an item to a Price watch item to see its best price, and send low items straight to the Order planner.

**Fitness** – weight, body fat, waist/chest/hips/arm/thigh/neck, resting HR, blood pressure, sleep, or any custom metric.
Profile (height, age, goal weight, units) gives BMI, 30-day change, distance to goal, and charts with 30d/90d/1y/All ranges.

**Labs & biomarkers** (Fitness → *Labs & biomarkers*) – pick markers from a list of ~40 common ones (testosterone, estradiol, A1c, lipids,
liver, blood counts, thyroid…) or add your own, then enter results from each blood draw. Each marker is charted against its normal range
(edit the range to match your lab report) with out-of-range flags and an optional **retest reminder**.
* **Events**: log dose changes, illness, travel, diet or training changes, etc. They show as markers on the lab charts and the Body charts, and
  medication start/stop dates are added automatically.
* **Spike detection**: when a result moves by 25% or more since the previous one (adjustable), it appears under *Worth a look* together with
  the events that happened since the last test, so you can see what changed around it.
* **Compare blood draws** side by side, export everything to CSV, and see flagged labs on the Dashboard.

**Prices** – paste a product link; name, image and price are detected automatically. Add the same item from several
stores to compare, set a target price, and see price history. Re-checks every few hours while the app runs.
* Price not found or wrong? Press 🎯 on that store, then click the price on the page yourself. Or press 🔍 to pick from a list of prices found on the page.
* **Stores that need an account:** (needs *sign-in mode*, turned on from Settings → Price tracking. It uses your own Chrome or Edge, so there's no big download unless neither is installed) tick "needs sign-in" (or press 🔑 on the store row). A normal browser window opens (in your default browser, or whichever you pick in Settings);
  you log in yourself (including any 2-factor prompt) and close it. The session is kept in a private profile inside `data/` (`browser_profile_chrome` / `browser_profile_edge`)
  and later checks reuse it. The app never sees or stores your password.
  When you close the sign-in window the app checks the price straight away and tells you whether the sign-in worked.
  Logins that normally end when a browser closes ("session cookies") are kept for up to 30 days in `data/sign_in_cookies.json` so checks stay signed in;
  they're refreshed on every check. Sessions can still expire on the store's side – just press 🔑 again.

## Notes
* Backups: Settings → *Download full backup*, or copy the `data` folder.
* This app records what you tell it; it doesn't give dosing advice. Check your regimen with your prescriber.
* Some stores block automated price checks (captchas, bot walls). Those show an error on the card; browser/sign-in
  mode helps in many cases but can't beat every site.
* Scraping can be against a site's terms of service; checks are infrequent and polite by default.


## Price watch upgrades
- **🎯 Point-and-click price:** on any store row, press 🎯. A browser window opens on that product page (using your saved sign-ins); choose the size/option if there is one, then click the price. The app saves that spot, re-reads the page fresh to prove it works (and tells you if it doesn't, changing nothing), and closes the window. Clicking something that isn't a price is rejected.
- **Stock tracking:** each store shows in stock / out of stock (read from the page data or the Add-to-cart button, and since when it changed). A change either way creates a 🔔 *Stock changes* alert on the Prices tab and the dashboard; dismiss them when you've seen them.
- **Needs attention:** stores that need a sign-in, can't find the price, error out, or haven't been checked lately are listed at the top of the Prices tab with a one-click fix (🔑 Sign in, 🎯 Pick the price, ↻ Re-check) and a "show only these items" filter. A coloured dot on every store row shows its status.
- **Trend badges:** "⭐ lowest in 30 days", "⬆ 30-day high", and "▼/▲ N% this week" (needs a few days of history to appear).
- **Bulk add / import:** *Bulk add / import* takes one link per line, `Name | link`, or a CSV (columns name, url, category, target_price, needs_login; a template can be downloaded). Same-name rows become extra stores of one item; already-tracked links are skipped; prices are fetched in the background with a progress bar.

## Custom cursors (WulfProtocol Crystalline Cursor Kit, Reference Faithful)
The kit's cursor files live, unmodified, in `static/cursors-crystalline-v2/` (10 states: default, hover, click, disabled, loading, help, text, resize-horizontal, resize-vertical, move; one sub-folder each with 32/48/64/128 px PNGs and 32/48/64 px `.cur` files, plus `manifest.json`; the kit's own CSS is kept as `kit-reference.css`, not loaded). It replaces every earlier cursor set (V5 and the first crystalline kit were deleted); the new folder name plus `?v=crystalline-5` means a browser can't reuse an older cursor from its cache. `wulf-cursors.css` (ours) maps the app's controls onto the states and uses only the 32 px assets (32 px PNG first, then the 32 px `.cur`, then the browser's own cursor) with no scaling or filters; paws and the help wolf use hotspot (0,0) (measured against the manifest's (2,2): covers about half as much of the area around the pointer, no missed clicks on this app's smallest controls), bones are centred (16,16). The textarea resize corner keeps the browser's own cursor. `wulf-cursors.js` shows the loading cursor while the app waits on the server. Mouse only: touch / no-hover devices keep the normal cursor, and each state falls back to the browser's native cursor. To switch it all off, remove the `wulf-cursors` class from `<html>` in `static/index.html`. After changing any cursor file, bump `crystalline-5` in `static/index.html` and `wulf-cursors.css`.

Cursor alignment (crystalline-5): the paw and help images were moved (no scaling) so their solid pixels (alpha 64 or more) start at (0,0); 748 faint pixels (alpha 60 or less) pushed off the edge were dropped and no solid pixel was clipped. The `.cur` hotspots match the CSS. Details are in `static/cursors-crystalline-v2/audit-solid-alignment/`.

## Orders (Order planner → Inventory)
In the Prices tab's Order planner, press **Mark as ordered** next to a store (or the best option) after you've bought something yourself. Nothing is ever bought from the app. It saves a note under **Inventory → On order** (store, quantity, price each, optional expected-by date). When the box arrives press **✓ Received…**: enter how many arrived (fewer is fine; the rest stays on order), how much each one adds to stock (e.g. 20 for a box of 20 syringes), and optionally the lot number and expiry date. It adds to the stock and writes a line in the item's History. Items on order don't show as low or out; they show **order is late** if the expected date has passed. Received orders are kept under "Recently received", and each item shows the last price you paid. **🖨 Shopping list** (Inventory) prints what's low, out or expired and not already on order. Orders are included in the data backup.

## Fitness tab
* **Log a measurement** is the first card: pick what (weight by default, or waist, body fat, etc., or "＋ Something else"), type the number and press Enter. The date is today unless you change it. The box shows your last value as a hint.
* **Goal** card: how far to go, a progress bar from your first weigh-in to your goal, your recent pace (a straight-line fit over the last four weeks) and the date you'd reach the goal at that pace.
* The chart adds a dashed **7-day average** line once there are four or more entries. Other measurements get their own tab as soon as they have an entry, with their own summary tiles.
* **About you** (height, birth date, goal, units) folds away once it's filled in.
* **Weigh-in reminder**: when your last weight is older than the number of days set in Settings → Weigh-in reminder (default 7, 0 = off), the dashboard shows a reminder.

## Inventory categories and reference sheets
* **Categories:** Anabolics, Analgesics, Cosmetic, Diluents & Additives, Fat Burning, Immune, Nootropics, Post-Cycle Therapy (PCT), Sexual Health, Tissue Growth & Repair and Canine, plus Supplies and Other. Older items in "Peptides & vials" or "Medications" keep working.
* **+ Add item** is now three quick steps: pick a category, pick the item from your reference list (or the common supplies list, or type your own), then say how many you have. If you already have that item, the new amount is added to it.
* **📖 Reference sheets** on the Inventory page: search for a compound or tap a category to browse. Each inventory item that matches a sheet has a **📖 Reference** button. From a sheet you can add it to your inventory or add it as a medication. The same 📖 Reference button is on the Medication page.
* **Updating the reference list:** the list is stored in your data (so you can edit it). A new version of `library_seed.json` is merged in once. Sheets you changed yourself are kept as they are and ones you deleted stay deleted. A medication's Reference card shows the current version of its sheet.

## Medication page extras (reference-sheet powered)
- **Heads-up lines:** anything a sheet wrote as `***LIKE THIS***` shows as a red line on the medication card, the medication page, the Reference card and the Log dose window.
- **Anything to note?:** the sheet's "Side effects" list becomes tap-to-select chips in Log dose. Taps are saved with the dose (`dose_logs.effects`) and counted in a "Things you noted" card on the medication page.
- **Dose steps by week:** `meds.phases` (JSON `[{from_week, dose}]`) and `meds.phase_start`. The sheet's "weeks 1-4 / 5-8 ..." lines are read and shown for you to confirm/edit. `sync_phases()` keeps `meds.dose` equal to today's step, so Take now, Log dose and the draw/dial amount follow automatically. Shows "Week N of your plan" on the card. Edit via the Dose steps card (PUT `/api/meds/<id>/phases`).

## Sending updates by email
Each release has a `VERSION` number. The zip made from the app folder (without `data`, `.venv`, `__pycache__`) works as both a fresh install and an update. Someone who already has the app opens Settings → "Install an update from a zip…", picks the zip, and reopens the app. Only program files are replaced; `data/` is never touched and a copy of the database is saved first (`backup-before-update-vN.db`). A zip that is not newer than the installed version is refused. Bump `VERSION` for every release.

### Frequency per dose step
A step can also carry its own `schedule` (`{type, days|every, times}`), e.g. Lipo-C once a week for weeks 1–4, twice a week from week 5. `schedule.slots_between` splits the timeline into segments per step, so past weeks keep the schedule they had (adherence stays correct) and `schedule.effective()` gives today's schedule for the card text. Steps with no `schedule` use the medication's own schedule.

## Building a shareable Windows package
Double-click **Build the package.bat** (needs internet). It downloads a bundled Python, installs the libraries into it, copies the app, starts it once as a test, then writes two files to `dist\`:
- `WulfProtocol-Windows.zip`: unzip, double-click "Install WulfProtocol" (installs to `%LOCALAPPDATA%\WulfProtocol`, offers a Desktop icon, adds a Start-menu entry, includes an uninstaller). Re-running it over an older install keeps the data.
- `WulfProtocol-update.zip`: app files only, for Settings → Install an update from a zip. The full zip also works for updating. If a release adds a new library to `requirements.txt`, send the full package instead of the update zip.
Installer sources live in `packaging\`. Bump `VERSION` before building.

## Publishing an update (for the "Check for updates" button)
Copies read `update.json` and `WulfProtocol-update.zip` from the `main` branch of https://github.com/BookofTech/wulfprotocol-updates (the address is stored in `update_source.txt`, served via raw.githubusercontent.com).
To publish: bump `VERSION` (and `RELEASE_NOTES.txt`), build the update zip (the app files under a top folder `tracker/`, no data, no packaging/dist/build files) plus `update.json` `{version, sha256, notes}`, commit both to that repository and push. Claude does this from its session; or run **Build the package.bat** and upload `dist\WulfProtocol-update.zip` + `dist\update.json` to the repository.

## Release label (Moonrise)
`release.json` holds the friendly label (name, codename, status, version, tagline). The launch screen in `static/index.html` is filled from it by the server (single source of truth), and Settings shows the exact build id (`<version>-<status>.<build>`, e.g. `1.0-beta.35`). `VERSION` is the build number used by the updater. Script/stylesheet URLs get `?v=<build>` automatically so a new build never serves stale files.
