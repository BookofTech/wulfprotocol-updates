"""Price fetching.

Strategy per source:
  1. Plain HTTP request + parse (JSON-LD, meta tags, itemprop, embedded JSON, optional CSS selector).
  2. If that is blocked / finds nothing / the source is marked "needs sign-in", fall back to a real
     Chromium (Playwright) using ONE persistent profile stored in data/browser_profile.
     You sign in once in a visible window; the site's session cookies are kept in that profile.
     Your passwords are never read or stored by this app.
"""
import json
import os
import random
import math
import re
import threading
import time
from datetime import datetime
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

import browsers
import db

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/126.0.0.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9",
           "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
PROFILE_DIR = db.DATA_DIR / "browser_profile"
_pw_lock = threading.Lock()
CURRENCY_SYMBOLS = {"$": "USD", "£": "GBP", "€": "EUR", "¥": "JPY", "₹": "INR"}


def site_of(url):
    return urlparse(url).netloc.lower().removeprefix("www.")


def parse_price(text):
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)
    m = re.search(r"\d[\d., \s]*\d|\d", str(text))
    if not m:
        return None
    n = re.sub(r"[\s ]", "", m.group(0))
    if "," in n and "." in n:
        dec = "," if n.rfind(",") > n.rfind(".") else "."
        n = n.replace("." if dec == "," else ",", "").replace(dec, ".")
    elif "," in n:
        n = n.replace(",", ".") if re.search(r",\d{1,2}$", n) else n.replace(",", "")
    try:
        v = float(n)
    except ValueError:
        return None
    return v if v > 0 else None


def _walk(o):
    if isinstance(o, dict):
        yield o
        for v in o.values():
            yield from _walk(v)
    elif isinstance(o, list):
        for v in o:
            yield from _walk(v)


def _first(v):
    return v[0] if isinstance(v, list) and v else v


def _el_text(el):
    """Visible text of an element; pieces are joined as-is so a price split over tags ("$", "55", ".00") stays one number."""
    return re.sub(r"\s+", " ", el.get_text("", strip=False)).strip()


def extract(html, selector=None):
    soup = BeautifulSoup(html, "lxml")
    out = _extract(soup, html, selector)
    if out["in_stock"] is None:
        out["in_stock"] = detect_stock(soup, html)
    return out


_AMAZON_PRICE = [
    "#corePrice_feature_div .a-price:not(.a-text-price) .a-offscreen", "#corePriceDisplay_desktop_feature_div .a-price:not(.a-text-price) .a-offscreen",
    "#apex_desktop .a-price:not(.a-text-price) .a-offscreen", "#buybox .a-price:not(.a-text-price) .a-offscreen",
    "#priceblock_ourprice", "#priceblock_dealprice", "#price_inside_buybox", "#newBuyBoxPrice", "#sns-base-price",
    "#tp_price_block_total_price_ww .a-offscreen", "#price", "span.a-price:not(.a-text-price) > span.a-offscreen",
]


def _amazon_price(soup):
    """Amazon keeps the price you pay in a hidden 'a-offscreen' span inside the buy box (the big visible number is split into pieces)."""
    for sel in _AMAZON_PRICE:
        try:
            el = soup.select_one(sel)
        except Exception:
            continue
        if el is not None:
            raw = _el_text(el)
            p = parse_price(raw)
            if p is not None:
                return p, raw
    return None, None


def _extract(soup, html, selector=None):
    out = {"name": None, "image": None, "price": None, "currency": None, "in_stock": None}

    # --- name / image from meta
    og = lambda p: (soup.find("meta", property=p) or soup.find("meta", attrs={"name": p}) or {}).get("content")
    out["name"] = og("og:title") or (soup.title.string.strip() if soup.title and soup.title.string else None)
    out["image"] = og("og:image")

    # --- user-supplied selector wins
    if selector:
        el = soup.select_one(selector)
        if el is not None:
            raw = el.get("content") or el.get("data-price") or _el_text(el)
            out["price"] = parse_price(raw)
            sym = next((s for s in CURRENCY_SYMBOLS if s in str(raw)), None)
            if sym:
                out["currency"] = CURRENCY_SYMBOLS[sym]
            if out["price"] is not None:
                return out

    # --- JSON-LD Product / Offer
    for tag in soup.find_all("script", type=re.compile("ld\\+json", re.I)):
        try:
            data = json.loads(tag.string or tag.get_text() or "")
        except Exception:
            continue
        for node in _walk(data):
            t = node.get("@type")
            types = t if isinstance(t, list) else [t]
            if "Product" in types:
                out["name"] = node.get("name") or out["name"]
                img = _first(node.get("image"))
                out["image"] = (img.get("url") if isinstance(img, dict) else img) or out["image"]
            if "Offer" in types or "AggregateOffer" in types:
                price = node.get("price") or node.get("lowPrice")
                if price is None and isinstance(node.get("priceSpecification"), dict):
                    price = node["priceSpecification"].get("price")
                p = parse_price(price)
                if p is not None and out["price"] is None:
                    out["price"] = p
                    out["currency"] = node.get("priceCurrency") or out["currency"]
                    av = str(node.get("availability", ""))
                    if av:
                        out["in_stock"] = 0 if re.search(r"OutOfStock|SoldOut|Discontinued", av) else 1
        if out["price"] is not None:
            return out

    # --- meta / microdata
    for key in ("product:price:amount", "og:price:amount", "twitter:data1"):
        p = parse_price(og(key))
        if p is not None:
            out["price"] = p
            out["currency"] = og("product:price:currency") or og("og:price:currency")
            return out
    el = soup.find(attrs={"itemprop": "price"})
    if el is not None:
        p = parse_price(el.get("content") or el.get_text())
        if p is not None:
            out["price"] = p
            cur = soup.find(attrs={"itemprop": "priceCurrency"})
            out["currency"] = cur.get("content") if cur is not None else None
            return out

    # --- Amazon's own price markup (its pages have no standard price data)
    ap, raw = _amazon_price(soup)
    if ap is not None:
        out["price"] = ap
        sym = next((s for s in CURRENCY_SYMBOLS if s in str(raw)), None)
        out["currency"] = CURRENCY_SYMBOLS[sym] if sym else out["currency"]
        if out["in_stock"] is None:
            out["in_stock"] = 1
        return out

    # --- embedded JSON blobs ("price": "12.34")
    hits = [parse_price(m.group(1)) for m in re.finditer(r'"(?:price|salePrice|currentPrice|final_price)"\s*:\s*"?(\d[\d.,]*)"?', html)]
    hits = [h for h in hits if h is not None]
    if hits:
        out["price"] = next((h for h in hits if h > 1.0), hits[0])        # skip $1.00 / $0.xx placeholders when a real-looking price exists
    return out


_OUT_WORDS = re.compile(r"sold[\s-]*out|out[\s-]*of[\s-]*stock|currently unavailable|notify me|email me when|back[\s-]*in[\s-]*stock|join (the )?waitlist|unavailable", re.I)
_BUY_WORDS = re.compile(r"add\s*to\s*(cart|bag|basket|order)|buy\s*(it\s*)?now|add\s*to\s*my\s*(cart|bag)|purchase", re.I)


def detect_stock(soup, html):
    """1 = in stock, 0 = out of stock, None = can't tell. Looks at schema.org availability, then the buy button, then store JSON."""
    for key in ("product:availability", "og:availability"):
        m = soup.find("meta", property=key) or soup.find("meta", attrs={"name": key})
        if m is not None and m.get("content"):
            return 0 if re.search(r"out\s*of\s*stock|sold|oos|discontinued", m["content"], re.I) else 1
    el = soup.find(attrs={"itemprop": "availability"})
    if el is not None:
        v = el.get("href") or el.get("content") or el.get_text(" ", strip=True)
        return 0 if re.search(r"OutOfStock|SoldOut|Discontinued|out of stock|sold out", v, re.I) else 1
    # the main buy button: a live "Add to cart" means in stock; "Sold out" / "Notify me" means out
    buy_live = buy_dead = out_label = False
    for b in soup.find_all(["button", "input", "a"]):
        if b.name == "input" and (b.get("type") or "").lower() not in ("submit", "button"):
            continue
        t = (b.get("value") if b.name == "input" else b.get_text(" ", strip=True)) or ""
        t = t.strip()
        if not t or len(t) > 40:
            continue
        dead = b.has_attr("disabled") or (b.get("aria-disabled") == "true") or "disabled" in (b.get("class") or []) or "sold-out" in " ".join(b.get("class") or [])
        if _OUT_WORDS.search(t):
            out_label = True
        elif _BUY_WORDS.search(t):
            if dead:
                buy_dead = True
            else:
                buy_live = True
    if buy_live:
        return 1
    if out_label or buy_dead:
        return 0
    av = re.findall(r'"available"\s*:\s*(true|false)', html)            # store product JSON (one entry per size/variant)
    if av:
        return 1 if "true" in av else 0
    q = re.findall(r'"inventory_quantity"\s*:\s*(-?\d+)', html)
    if q:
        return 1 if any(int(x) > 0 for x in q) else 0
    return None


_MONEY = re.compile(r"(?:[$€£¥₹]|USD|CAD|EUR|GBP)\s*\d[\d.,]*|\d[\d.,]*\s*(?:[$€£¥₹]|USD|CAD|EUR|GBP)|\d+[.,]\d{2}\b")


def _css_path(soup, el):
    """A CSS selector that matches exactly this element (id, else tag.class chains, else nth-of-type)."""
    def part(n):
        if n.get("id") and re.fullmatch(r"[A-Za-z][\w-]*", n["id"]):
            return "#" + n["id"]
        cls = [c for c in (n.get("class") or []) if re.fullmatch(r"[A-Za-z][\w-]*", c) and not re.search(r"\d{3,}", c)][:2]
        return n.name + "".join("." + c for c in cls)
    chain, node = [], el
    for _ in range(6):
        chain.insert(0, part(node))
        sel = " > ".join(chain)
        try:
            if len(soup.select(sel)) == 1:
                return sel
        except Exception:
            return None
        if chain[0].startswith("#") or node.parent is None or node.parent.name in ("[document]", "html"):
            break
        node = node.parent
    sel = " > ".join(chain)
    try:
        if len(soup.select(sel)) == 1:
            return sel
    except Exception:
        return None
    return _nth_path(soup, el)


def _nth_path(soup, el):
    """Fallback: a full path from the nearest id (or the top of the page) using nth-of-type, which is always exact."""
    parts, node = [], el
    while node is not None and getattr(node, "name", None) not in (None, "[document]", "html"):
        if node.get("id") and re.fullmatch(r"[A-Za-z][\w-]*", node["id"]):
            parts.insert(0, "#" + node["id"])
            break
        sibs = [x for x in (node.parent.find_all(node.name, recursive=False) if node.parent is not None else []) if x is not None]
        i = next((k for k, x in enumerate(sibs, 1) if x is node), 1)
        parts.insert(0, f"{node.name}:nth-of-type({i})")
        node = node.parent
    sel = " > ".join(parts)
    try:
        return sel if sel and len(soup.select(sel)) == 1 and soup.select_one(sel) is el else None
    except Exception:
        return None


def find_candidates(html, selector=None):
    """Every price-looking value on the page, with where it came from, so the person can pick the right one.
    Items from visible page elements carry a CSS selector that can be saved as the store's price selector."""
    soup = BeautifulSoup(html, "lxml")
    out, seen = [], set()

    def add(price, where, text="", sel=None, note=None):
        if price is None:
            return
        key = (round(price, 2), where, sel or text)
        if key in seen:
            return
        seen.add(key)
        out.append({"price": price, "where": where, "text": (text or "")[:80], "selector": sel, "note": note})

    for tag in soup.find_all("script", type=re.compile("ld\\+json", re.I)):
        try:
            data = json.loads(tag.string or tag.get_text() or "")
        except Exception:
            continue
        for node in _walk(data):
            t = node.get("@type")
            if "Offer" in (t if isinstance(t, list) else [t]) or "AggregateOffer" in (t if isinstance(t, list) else [t]):
                price = node.get("price") or node.get("lowPrice")
                if price is None and isinstance(node.get("priceSpecification"), dict):
                    price = node["priceSpecification"].get("price")
                add(parse_price(price), "Page data (structured offer)", str(price), note="Not selectable. If it's wrong, pick a visible price below")
    for key in ("product:price:amount", "og:price:amount"):
        m = soup.find("meta", property=key) or soup.find("meta", attrs={"name": key})
        if m is not None:
            add(parse_price(m.get("content")), "Page data (meta tag)", m.get("content"), note="Not selectable")
    for m in list(re.finditer(r'"(price|salePrice|currentPrice|final_price)"\s*:\s*"?(\d[\d.,]*)"?', html))[:8]:
        add(parse_price(m.group(2)), f"Page data (“{m.group(1)}” field)", m.group(2), note="Not selectable")
    # what you actually see on the page
    for el in soup.find_all(True):
        if el.name in ("script", "style", "noscript", "head", "title", "meta", "link", "option", "html", "body"):
            continue
        attrs = " ".join([el.get("id") or "", " ".join(el.get("class") or [])]).lower()
        par = el.parent.get("class") or [] if el.parent is not None and hasattr(el.parent, "get") else []
        if not re.search(r"price|amount|cost|money|sale", attrs) and not ("offscreen" in attrs and re.search(r"price", " ".join(par).lower())):
            continue
        text = el.get_text(" ", strip=True)
        if not text or len(text) > 40 or "display:none" in (el.get("style") or "").replace(" ", ""):
            continue
        if len(_MONEY.findall(text)) != 1:                         # skip containers that hold several prices: their children are listed instead
            continue
        p = parse_price(_MONEY.search(text).group(0))
        old = (el.find_parent(["del", "s", "strike"]) is not None or bool(re.search(r"old|was|regular|compare|strike|original|text-price", attrs))
               or el.find_parent(attrs={"data-a-strike": "true"}) is not None or el.get("data-a-strike") == "true")
        add(p, "Shown on the page", text, _css_path(soup, el), "looks like an old / crossed-out price" if old else None)
        if old and out and out[-1]["text"] == text[:80]:
            out[-1]["old"] = True
    cur = extract(html, selector)["price"]
    for c in out:
        c["current"] = cur is not None and abs(c["price"] - cur) < 0.005
    out.sort(key=lambda c: (c["selector"] is None, bool(c.get("old")), c["price"] <= 1.0))
    for c in out:
        if c["price"] <= 1.0 and not c.get("note"):
            c["note"] = "looks like a placeholder, not a real price"
    if out and out[0]["selector"] and not out[0].get("old") and out[0]["price"] > 1.0:
        out[0]["best"] = True
    return out[:30], cur


_NUM = r"\$\s?(\d{1,4}(?:\.\d\d)?)"
_FREE_OVER = [re.compile(p, re.I) for p in (
    r"free (?:standard |us |domestic |u\.s\. )?shipping[^.$\n]{0,45}?(?:over|above|of|on|when you spend|for)\s*(?:orders? )?(?:of |over |above )?" + _NUM,
    r"orders? (?:of |over |above )" + _NUM + r"[^.\n]{0,30}ships? free",
    _NUM + r"\+?\s*(?:for )?free shipping")]
_FLAT = [re.compile(p, re.I) for p in (
    r"(?:flat[- ]rate|standard|domestic|us|u\.s\.)\s+shipping(?: cost| fee| rate)?\s*(?:is|of|for|:|-|–)?\s*" + _NUM,
    r"\bshipping (?:cost|fee|rate)s?\s*(?:is|of|:|-|–)?\s*" + _NUM,
    r"ships? for\s*" + _NUM + r"(?!\s*\+)")]


def find_shipping(html):
    """Picks up shipping rules stores print on their pages ('Free shipping over $75', 'Flat rate shipping $8.95').
    Product pages rarely show the exact cost, so this only returns what is actually written there."""
    try:
        soup = BeautifulSoup(html, "lxml")
        for t in soup(["script", "style", "noscript", "template", "head"]):
            t.decompose()
        text = re.sub(r"\s+", " ", soup.get_text(" ", strip=True))[:300000]
        out = {}
        for rx in _FREE_OVER:
            m = rx.search(text)
            if m:
                out["free_over"] = float(m.group(1)); break
        for rx in _FLAT:
            m = rx.search(text)
            if m:
                out["fee"] = float(m.group(1)); break
        return out
    except Exception:
        return {}


def _save_shipping(site, ship):
    if not site or not ship:
        return
    row = db.q("SELECT * FROM store_shipping WHERE site=?", (site,), one=True)
    now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    if not row:
        db.x("INSERT INTO store_shipping(site,fee,free_over,manual,seen) VALUES (?,?,?,0,?)", (site, ship.get("fee"), ship.get("free_over"), now))
    elif not row["manual"]:
        db.x("UPDATE store_shipping SET fee=COALESCE(?,fee), free_over=COALESCE(?,free_over), seen=? WHERE site=?",
             (ship.get("fee"), ship.get("free_over"), now, site))


def is_placeholder(price, last=None):
    """Some pages carry $0.00 / $0.01 / $1.00 in their code and swap in the real price with a script after loading."""
    if price is None:
        return False
    return price <= 0.01 or (price <= 1.0 and (last is None or last > 2))


def best_real_price(html, last=None):
    """The most likely real price shown on the page: a visible, not-crossed-out value that isn't a placeholder,
    closest to the last good price when we have one."""
    cands, _ = find_candidates(html)
    good = [c for c in cands if c["selector"] and not c.get("old") and c["price"] > 1.0]
    if not good:
        return None
    if last:
        good.sort(key=lambda c: abs(math.log(c["price"] / last)))
    return good[0]["price"]


# ------------------------------------------------------------------ browser (Playwright)
_ready = None


def pw_available(refresh=False):
    """True if the playwright package is installed AND there is a browser to drive: the person's own
    Chrome/Edge (preferred, nothing extra to download) or Playwright's bundled Chromium (cached)."""
    global _ready
    if _ready is None or refresh:
        try:
            import importlib.util
            if importlib.util.find_spec("playwright") is None:
                _ready = False
            elif browsers.choose(db.get_settings()["browser_pref"]):
                _ready = True
            else:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as p:
                    _ready = os.path.exists(p.chromium.executable_path)
        except Exception:
            _ready = False
    return _ready


# Chrome forgets "session" cookies (logins without a "remember me" expiry) whenever it closes, which would sign you out
# between price checks. So after every sign-in / check we keep a copy of the cookies and put them back at the next launch.
_COOKIE_KEYS = ("name", "value", "domain", "path", "expires", "httpOnly", "secure", "sameSite")


def _cookie_file():
    return db.DATA_DIR / "sign_in_cookies.json"


def _snapshot(ctx):
    try:
        return [{k: c[k] for k in _COOKIE_KEYS if k in c} for c in ctx.cookies()]
    except Exception:
        return None


def _write_cookies(cookies):
    if not cookies:
        return
    try:
        tmp = _cookie_file().with_suffix(".tmp")
        tmp.write_text(json.dumps(cookies), encoding="utf-8")
        os.replace(tmp, _cookie_file())
    except Exception:
        pass


def _restore_cookies(ctx):
    try:
        cookies, now, out = json.loads(_cookie_file().read_text(encoding="utf-8")), time.time(), []
        for c in cookies:
            if c.get("expires", -1) in (-1, None):
                c["expires"] = now + 30 * 86400            # session cookie -> keep for 30 days
            elif c["expires"] < now:
                continue
            out.append(c)
        if out:
            ctx.add_cookies(out)
    except Exception:
        pass


def _launch(p, headless):
    """Drive the person's own Chrome/Edge when installed (their choice in Settings, default = system default
    browser); otherwise Playwright's bundled Chromium. Each browser gets its own sign-in profile folder, because
    a profile made by one browser build can't always be opened by another."""
    pick = browsers.choose(db.get_settings()["browser_pref"])
    profile = db.DATA_DIR / (f"browser_profile_{pick[0]}" if pick else "browser_profile")
    profile.mkdir(parents=True, exist_ok=True)
    kw = {"executable_path": pick[1]} if pick else {}
    ctx = p.chromium.launch_persistent_context(
        str(profile), headless=headless, user_agent=UA,
        viewport={"width": 1280, "height": 900},
        args=["--disable-blink-features=AutomationControlled"], **kw,
    )
    _restore_cookies(ctx)
    return ctx


def browser_fetch(url):
    from playwright.sync_api import sync_playwright
    if not _pw_lock.acquire(timeout=90):
        raise RuntimeError("Browser is busy (is a sign-in window still open?)")
    try:
        with sync_playwright() as p:
            ctx = _launch(p, True)
            try:
                page = ctx.pages[0] if ctx.pages else ctx.new_page()
                page.goto(url, wait_until="domcontentloaded", timeout=45000)
                try:
                    page.wait_for_load_state("networkidle", timeout=8000)
                except Exception:
                    pass
                page.wait_for_timeout(1500)
                html = page.content()
                _write_cookies(_snapshot(ctx))             # keep the session fresh
                return html
            finally:
                ctx.close()
    finally:
        _pw_lock.release()


login_state = {"state": "idle", "error": "", "result": None, "mode": "login"}      # idle | starting | open | error: lets the UI report what happened
_login_stop = threading.Event()                  # set to ask an open sign-in window to close


def login_window_busy():
    return login_state["state"] in ("starting", "open")


def close_login_window():
    _login_stop.set()


def open_login_window(url, max_minutes=20):
    """Opens a visible browser at `url` using the shared profile; returns when the user closes it
    (or close_login_window() is called)."""
    from playwright.sync_api import sync_playwright
    if not _pw_lock.acquire(timeout=5):
        raise RuntimeError("A sign-in window is already open")
    _login_stop.clear()
    login_state.update(state="starting", error="", result=None, mode="login")
    snap, last_snap = None, 0.0
    try:
        with sync_playwright() as p:
            ctx = _launch(p, False)
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            try:
                page.goto(url, timeout=45000)
            except Exception:
                pass
            login_state["state"] = "open"
            deadline = time.time() + max_minutes * 60
            while time.time() < deadline and not _login_stop.is_set():
                try:
                    pages = ctx.pages
                    if not pages:                      # the person closed the window
                        break
                    pages[0].wait_for_timeout(700)     # (not time.sleep: Playwright only notices closed windows while it is being called)
                    if time.time() - last_snap > 3:    # remember the latest cookies; the window may be closed at any moment
                        last_snap = time.time(); snap = _snapshot(ctx) or snap
                except Exception:
                    break
            snap = _snapshot(ctx) or snap
            try:
                ctx.close()
            except Exception:
                pass
            _write_cookies(snap)
    except Exception as e:
        login_state.update(state="error", error=str(e).splitlines()[0][:300])
        raise
    finally:
        if login_state["state"] != "error":
            login_state["state"] = "idle"
        _pw_lock.release()


# ------------------------------------------------------------------ point-and-click price picker
# Injected into every page of the pick window. The person moves the mouse (the price under it is outlined) and clicks the price;
# the page's own click is blocked, the clicked element is tagged data-wp-pick and its text is reported back.
PICK_JS = r"""
(() => {
  if (window.top !== window || window.__wpInstalled) return;
  window.__wpInstalled = true;
  let hot = null, done = false, bar = null;
  const css = 'outline:3px solid #0e8a8c !important;outline-offset:2px !important;background:rgba(14,138,140,.14) !important;cursor:crosshair !important;';
  const mkbar = () => {
    if (bar || !document.documentElement) return;
    bar = document.createElement('div'); bar.id = '__wp_bar';
    bar.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#0e8a8c;color:#fff;font:600 15px/1.3 system-ui,sans-serif;padding:10px 16px;display:flex;gap:12px;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.3)';
    bar.innerHTML = '<span id="__wp_msg" style="flex:1">WulfProtocol: click the PRICE you pay on this page. (Choose the size/option and sign in first if needed.)</span><button id="__wp_x" style="background:#fff;color:#0e8a8c;border:0;border-radius:8px;padding:6px 12px;font-weight:700;cursor:pointer">Cancel</button>';
    document.documentElement.appendChild(bar); document.documentElement.style.paddingTop = '46px';
    bar.querySelector('#__wp_x').addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); window.__wpCancel = true; }, true);
  };
  const inBar = e => bar && bar.contains(e.target);
  const clear = () => { if (hot) { hot.style.cssText = hot.__wpOld || ''; hot = null; } };
  document.addEventListener('mouseover', e => {
    if (done || inBar(e)) return;
    clear(); hot = e.target; hot.__wpOld = hot.style.cssText; hot.style.cssText += ';' + css;
  }, true);
  const stop = e => { if (!done && !inBar(e)) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); } };
  ['mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend', 'submit', 'auxclick'].forEach(t => document.addEventListener(t, stop, true));
  document.addEventListener('click', e => {
    if (done || inBar(e)) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    const el = e.target; clear();
    document.querySelectorAll('[data-wp-pick]').forEach(n => n.removeAttribute('data-wp-pick'));
    el.setAttribute('data-wp-pick', '1');
    const text = (el.innerText || el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 120);
    window.__wpPick = { text: text, url: location.href };
    done = true;
    const m = document.getElementById('__wp_msg'); if (m) m.textContent = 'Got it: "' + text.slice(0, 40) + '" - saving...';
    if (bar) bar.style.background = '#2e9e5b';
  }, true);
  const boot = () => mkbar();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  new MutationObserver(() => { if (bar && !bar.isConnected && document.documentElement) document.documentElement.appendChild(bar); else mkbar(); }).observe(document, { childList: true, subtree: true });
})();
"""

_NUM_RUN = re.compile(r"\d[\d.,]*")


def selector_from_pick(html):
    """From the page HTML with the clicked element tagged data-wp-pick: returns (selector, price, text) or (None, None, reason)."""
    soup = BeautifulSoup(html, "lxml")
    el = soup.find(attrs={"data-wp-pick": "1"})
    if el is None:
        return None, None, "Couldn't tell which element you clicked."
    for n in soup.find_all(attrs={"data-wp-pick": True}):
        del n["data-wp-pick"]
    # the click may have landed on a piece of the price ("$" or ".00"): climb while the parent is still just one price
    best = el
    for _ in range(3):
        par = best.parent
        if par is None or par.name in ("body", "html", "[document]"):
            break
        t = _el_text(par)
        if len(t) > 24 or len(_NUM_RUN.findall(t)) != 1 or parse_price(t) is None:
            break
        best = par
    text = _el_text(best)
    price = parse_price(text)
    if price is None:
        # clicked something near the price (a label or box): look just inside it
        for d in best.find_all(True):
            t = _el_text(d)
            if t and len(t) <= 24 and len(_NUM_RUN.findall(t)) == 1 and parse_price(t) is not None:
                best, text, price = d, t, parse_price(t); break
    if price is None:
        return None, None, "That doesn't look like a price (no number in it). Click directly on the price figure."
    attrs = " ".join(" ".join([n.get("id") or "", " ".join(n.get("class") or [])]) for n in [best, *list(best.parents)[:3]] if hasattr(n, "get")).lower()
    if not _MONEY.search(text) and not re.search(r"price|amount|cost|money|sale", attrs):     # e.g. a product name that happens to contain a number
        return None, None, f"“{text[:30]}” doesn't look like a price (no currency sign or decimals). Click the price figure itself."
    sel = _css_path(soup, best)
    if not sel:
        return None, None, "Couldn't build a stable address for that spot on the page."
    return sel, price, text


def open_pick_window(url, max_minutes=10):
    """Opens a visible browser at `url` (same sign-in profile) and waits for the person to click the price.
    Returns {"selector","price","text"} or {"error": "..."} / {"cancelled": True}."""
    from playwright.sync_api import sync_playwright
    if not _pw_lock.acquire(timeout=5):
        raise RuntimeError("A browser window is already open")
    _login_stop.clear()
    login_state.update(state="starting", error="", result=None, mode="pick")
    snap, last_snap, picked, html, cancelled = None, 0.0, None, None, False
    try:
        with sync_playwright() as p:
            ctx = _launch(p, False)
            ctx.add_init_script(PICK_JS)
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            try:
                page.goto(url, timeout=45000)
            except Exception:
                pass
            login_state["state"] = "open"
            deadline = time.time() + max_minutes * 60
            while time.time() < deadline and not _login_stop.is_set():
                try:
                    pages = ctx.pages
                    if not pages:
                        cancelled = True
                        break
                    pages[0].wait_for_timeout(500)
                    for pg in pages:
                        try:
                            if pg.evaluate("!!window.__wpCancel"):
                                cancelled = True
                            r = pg.evaluate("window.__wpPick || null")
                        except Exception:
                            continue
                        if r:
                            picked, html = r, pg.content()
                            pg.wait_for_timeout(1300)             # let the person see the green "Got it" bar
                            break
                    if picked or cancelled:
                        break
                    if time.time() - last_snap > 3:
                        last_snap = time.time(); snap = _snapshot(ctx) or snap
                except Exception:
                    cancelled = not picked
                    break
            snap = _snapshot(ctx) or snap
            try:
                ctx.close()
            except Exception:
                pass
            _write_cookies(snap)
    except Exception as e:
        login_state.update(state="error", error=str(e).splitlines()[0][:300])
        raise
    finally:
        if login_state["state"] != "error":
            login_state["state"] = "idle"
        _pw_lock.release()
    if not picked:
        return {"cancelled": True}
    sel, price, text = selector_from_pick(html)
    if not sel:
        return {"error": text}
    return {"selector": sel, "price": price, "text": text, "seen": picked.get("text"), "url": picked.get("url")}


# ------------------------------------------------------------------ checking
def fetch_html(url, needs_login=False, force_browser=False):
    """Returns (html, via)."""
    if not needs_login and not force_browser:
        try:
            r = requests.get(url, headers=HEADERS, timeout=20)
            if r.status_code < 400 and len(r.text) > 500:
                return r.text, "http"
            http_err = f"HTTP {r.status_code}"
        except requests.RequestException as e:
            http_err = type(e).__name__
        if not pw_available():
            raise RuntimeError(f"Request failed ({http_err}). Turn on sign-in/browser mode in Settings to try a real browser")
    elif not pw_available():
        raise RuntimeError("Sign-in mode isn't installed yet - open Settings and press Install sign-in mode")
    return browser_fetch(url), "browser"


def no_price_reason(html):
    low = html.lower()
    if re.search(r"enter the characters you see below|to discuss automated access|type the characters you see|/errors/validatecaptcha|robot check", low):
        return "The store showed a robot check instead of the product. Press 🔑 once, finish the check in the window that opens, then re-check"
    if re.search(r"currently unavailable|no featured offers available|see all buying options|temporarily out of stock", low):
        return "Couldn't find a price: the store lists this as unavailable or has no featured offer right now. If you can see a price on the page, press ⚠ Wrong price? and pick it"
    return "Couldn't find a price on that page. Press ⚠ Wrong price? to pick it"


def looks_like_login(html):
    return bool(re.search(r'type=["\']password["\']', html, re.I))


_OFFER = re.compile(
    r"\b\d{1,2}(?:\.\d)?\s?%\s?(?:off|discount)\b|\$\s?\d+(?:\.\d\d)?\s?(?:off|discount)\b|\bsave\s+(?:up to\s+)?(?:\$\s?\d+|\d{1,2}\s?%)"
    r"|\b(?:promo|coupon|discount|sale)?\s?code\b\s*[:\-]?\s*[\"'“]?[A-Z0-9]{4,}\b|\bfree shipping\b|\bbuy\s+\d+\s*,?\s*get\b|\bBOGO\b|\b(?:flash|clearance|limited[- ]time) sale\b", re.I)
_FINE_PRINT = re.compile(r"how (?:the|this) (?:sale|offer|deal) works|terms|cannot be combined|can't be combined|not valid|exclusions?|may not|while supplies|subject to", re.I)
_PROMO_BOX = re.compile(r"pop-?up|modal|dialog|promo|banner|announce|coupon|offer|discount|sale|overlay|toast|deal|notification", re.I)


def find_promo(html):
    """Looks for sale text that isn't part of the price itself: pop-ups, banners and coupon boxes ('15% off with code SAVE15').
    Returns a short string, or None."""
    try:
        soup = BeautifulSoup(html, "lxml")
        for t in soup(["script", "style", "noscript", "template", "head"]):
            t.decompose()
        found, seen = [], set()
        boxes = soup.find_all(lambda t: t.name in ("dialog", "aside", "section", "div", "span", "p", "a", "header")
                              and (t.get("role") in ("dialog", "alertdialog", "alert") or t.get("aria-modal") == "true" or t.name == "dialog"
                                   or _PROMO_BOX.search(" ".join(t.get("class") or []) + " " + (t.get("id") or ""))))
        for b in boxes:
            txt = re.sub(r"\s+", " ", b.get_text(" ", strip=True))
            if not txt or len(txt) > 2500:
                continue
            for sent in re.split(r"(?<=[.!?])\s+|\s{2,}| \| |\s[×•·✕]\s|[×•]", txt):
                sent = sent.strip(" -–•·×")
                m = _OFFER.search(sent)
                if not m or len(sent) < 8 or _FINE_PRINT.search(sent):
                    continue
                if len(sent) > 110:                                  # keep the part around the offer
                    a = max(0, m.start() - 35); sent = sent[a:a + 110].strip(" -–•·,")
                key = re.sub(r"\W+", "", sent.lower())[:60]
                if key in seen or any(key in k or k in key for k in seen):
                    continue
                seen.add(key)
                found.append(sent)
            if len(found) >= 3:
                break
        return " · ".join(found[:2])[:240] or None
    except Exception:
        return None


def check_source(source_id):
    s = db.q("SELECT * FROM sources WHERE id=?", (source_id,), one=True)
    if not s:
        return None
    now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    try:
        html, via = fetch_html(s["url"], bool(s["needs_login"]))
        res = extract(html, s["selector"])
        if res["price"] is None and via == "http" and pw_available():
            html, via = fetch_html(s["url"], force_browser=True)
            res = extract(html, s["selector"])
        if not s["selector"] and is_placeholder(res["price"], s["last_price"]):          # $1.00 stand-in in the page code: read what the page really shows
            seen = res["price"]
            if via == "http" and pw_available():
                html, via = fetch_html(s["url"], force_browser=True)
                res = extract(html, s["selector"])
            if is_placeholder(res["price"], s["last_price"]):
                real = best_real_price(html, s["last_price"])
                res["price"] = real
            if res["price"] is None or is_placeholder(res["price"], s["last_price"]):
                msg = (f"Couldn't find a real price: the page only holds a ${seen:.2f} placeholder. Press ⚠ Wrong price? to pick the right one")
                db.x("UPDATE sources SET last_checked=?, last_error=? WHERE id=?", (now, msg, source_id))
                return {"ok": False, "error": msg, "name": res["name"], "image": res["image"]}
        if res["price"] is None:
            msg = ("Sign-in required — use the Sign in button, then re-check"
                   if looks_like_login(html) else no_price_reason(html))
            db.x("UPDATE sources SET last_checked=?, last_error=? WHERE id=?", (now, msg, source_id))
            return {"ok": False, "error": msg, "name": res["name"], "image": res["image"]}
        promo = find_promo(html)
        _save_shipping(s["site"], find_shipping(html))
        prev, new = s["in_stock"], res["in_stock"]
        if prev is not None and new is not None and bool(prev) != bool(new):          # back in stock / went out of stock
            db.x("INSERT INTO stock_events(source_id,item_id,ts,kind,price) VALUES (?,?,?,?,?)",
                 (source_id, s["item_id"], now, "back_in_stock" if new else "out_of_stock", res["price"]))
        db.x("""UPDATE sources SET last_price=?, currency=COALESCE(?,currency), in_stock=COALESCE(?,in_stock), last_checked=?, last_error=NULL, promo=?
                WHERE id=?""", (res["price"], res["currency"], res["in_stock"], now, promo, source_id))
        db.x("INSERT INTO price_history(source_id, ts, price, in_stock, promo) VALUES (?,?,?,?,?)",
             (source_id, now, res["price"], res["in_stock"], promo))
        db.export_sites()
        return {"ok": True, **res, "via": via, "promo": promo}
    except Exception as e:  # noqa: BLE001
        msg = (str(e).strip().splitlines() or [type(e).__name__])[0][:200]
        db.x("UPDATE sources SET last_checked=?, last_error=? WHERE id=?", (now, msg, source_id))
        return {"ok": False, "error": msg}


def check_all(only_due=False):
    hours = db.get_settings()["check_hours"]
    for s in db.q("SELECT id,last_checked FROM sources"):
        if only_due and s["last_checked"]:
            age = (datetime.now() - datetime.fromisoformat(s["last_checked"])).total_seconds() / 3600
            if age < hours:
                continue
        check_source(s["id"])
        time.sleep(random.uniform(1.5, 4))  # be polite


def scheduler_loop():
    while True:
        try:
            cfg = db.get_settings()
            if cfg["use_prices"] and cfg["auto_check"]:
                check_all(only_due=True)
        except Exception as e:  # noqa: BLE001
            print("scheduler error:", e)
        time.sleep(300)


def start_scheduler():
    threading.Thread(target=scheduler_loop, daemon=True).start()
