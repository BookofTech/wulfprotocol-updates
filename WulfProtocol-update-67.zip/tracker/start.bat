@echo off
rem Windows launcher: creates a private Python environment on first run, then starts the app.
cd /d "%~dp0"
if not exist .venv (
  echo First run: setting things up ^(1-2 minutes^)...
  python -m venv .venv || (echo Python 3.9+ is required & pause & exit /b 1)
  .venv\Scripts\pip install -q -r requirements.txt
)
.venv\Scripts\python app.py
if errorlevel 1 pause
