/* Tiny dependency-free SVG charts (works offline). */
const Charts = (() => {
  const NS = "http://www.w3.org/2000/svg";
  const registry = new Set();

  function niceTicks(min, max, n = 5) {
    if (min === max) { min -= 1; max += 1; }
    const span = max - min, raw = span / n;
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => s >= raw) || raw;
    const lo = Math.floor(min / step) * step, hi = Math.ceil(max / step) * step;
    const ticks = [];
    for (let v = lo; v <= hi + step / 2; v += step) ticks.push(+v.toFixed(10));
    return { ticks, lo, hi };
  }
  const el = (name, attrs = {}, parent) => {
    const e = document.createElementNS(NS, name);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  };

  /* series: [{name,color,points:[[ms,y],...], dashed?}]  opts: {height,yFmt,xFmt,hLine:{y,label}} */
  function line(host, series, opts = {}) {
    const draw = () => {
      host.innerHTML = "";
      const all = series.flatMap(s => s.points);
      if (!all.length) { host.innerHTML = '<div class="chart-empty">No data yet</div>'; return; }
      const W = host.clientWidth || 600, H = opts.height || 240;
      const m = { l: 46, r: 14, t: 12, b: 26 };
      const xs = all.map(p => p[0]), ys = all.map(p => p[1]);
      if (opts.hLine) ys.push(opts.hLine.y);
      if (opts.band) {                                  // reference band: only stretch the axis for edges that are near the data
        const dmin = Math.min(...ys), dmax = Math.max(...ys), span = (dmax - dmin) || Math.abs(dmax) * 0.2 || 1;
        if (opts.band.lo != null && opts.band.lo >= dmin - span) ys.push(opts.band.lo);
        if (opts.band.hi != null && opts.band.hi <= dmax + span) ys.push(opts.band.hi);
      }
      let x0 = Math.min(...xs), x1 = Math.max(...xs);
      if (opts.xDomain) { x0 = Math.min(x0, opts.xDomain[0]); x1 = Math.max(x1, opts.xDomain[1]); }
      if (x0 === x1) { x0 -= 864e5; x1 += 864e5; }
      const pad = (Math.max(...ys) - Math.min(...ys)) * 0.08 || 1;
      const T = niceTicks(Math.min(...ys) - pad, Math.max(...ys) + pad, 4);
      const X = v => m.l + (v - x0) / (x1 - x0) * (W - m.l - m.r);
      const Y = v => H - m.b - (v - T.lo) / (T.hi - T.lo) * (H - m.t - m.b);
      const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: "chart" }, host);
      if (opts.band) {                                  // shaded "normal range"
        const top = Y(Math.min(opts.band.hi ?? T.hi, T.hi)), bot = Y(Math.max(opts.band.lo ?? T.lo, T.lo));
        if (bot > top) el("rect", { x: m.l, y: top, width: W - m.l - m.r, height: bot - top, class: "band" }, svg);
      }
      T.ticks.forEach(t => {
        el("line", { x1: m.l, x2: W - m.r, y1: Y(t), y2: Y(t), class: "grid" }, svg);
        el("text", { x: m.l - 8, y: Y(t) + 4, class: "tick", "text-anchor": "end" }, svg).textContent = (opts.yFmt || (v => v))(t);
      });
      const evs = (opts.events || []).filter(e => (e.x2 ?? e.x) >= x0 && e.x <= x1);
      evs.forEach(e => {                                // event markers: dashed line (or shaded span) behind the data
        const a = X(Math.max(e.x, x0)), b = e.x2 ? X(Math.min(e.x2, x1)) : a;
        if (e.x2 && b - a > 3) el("rect", { x: a, y: m.t, width: b - a, height: H - m.t - m.b, fill: e.color, opacity: 0.12 }, svg);
        el("line", { x1: a, x2: a, y1: m.t, y2: H - m.b, stroke: e.color, "stroke-width": 1.6, "stroke-dasharray": "4 3", opacity: 0.85 }, svg);
        el("path", { d: `M${a - 4} ${m.t} L${a + 4} ${m.t} L${a} ${m.t + 7} Z`, fill: e.color }, svg);
      });
      const nx = Math.max(2, Math.min(6, Math.floor((W - m.l) / 90)));
      let lastLabel = null;
      for (let i = 0; i < nx; i++) {
        const v = x0 + (x1 - x0) * i / (nx - 1);
        const label = (opts.xFmt || (d => new Date(d).toLocaleDateString(undefined, { month: "short", day: "numeric" })))(v);
        if (label === lastLabel) continue;                 // a short range would repeat the same date
        lastLabel = label;
        el("text", { x: X(v), y: H - 6, class: "tick", "text-anchor": i === 0 ? "start" : i === nx - 1 ? "end" : "middle" }, svg).textContent = label;
      }
      if (opts.hLine) {
        el("line", { x1: m.l, x2: W - m.r, y1: Y(opts.hLine.y), y2: Y(opts.hLine.y), class: "hline" }, svg);
        el("text", { x: W - m.r, y: Y(opts.hLine.y) - 4, class: "tick", "text-anchor": "end" }, svg).textContent = opts.hLine.label || "";
      }
      series.forEach(s => {
        if (!s.points.length) return;
        const pts = s.points.slice().sort((a, b) => a[0] - b[0]);
        const d = pts.map((p, i) => (i ? "L" : "M") + X(p[0]).toFixed(1) + " " + Y(p[1]).toFixed(1)).join("");
        el("path", { d, fill: "none", stroke: s.color, "stroke-width": 2.2, "stroke-linejoin": "round",
          "stroke-dasharray": s.dashed ? "5 4" : "none" }, svg);
        if (!s.noDots && pts.length <= 60) pts.forEach(p => el("circle", { cx: X(p[0]), cy: Y(p[1]), r: 2.8, fill: s.color }, svg));
      });
      // hover
      const tip = document.createElement("div"); tip.className = "chart-tip"; host.appendChild(tip);
      const dot = el("circle", { r: 5, class: "hover-dot", style: "display:none" }, svg);
      const overlay = el("rect", { x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: "transparent" }, svg);
      overlay.addEventListener("mousemove", e => {
        const r = svg.getBoundingClientRect(), mx = (e.clientX - r.left) * (W / r.width);
        let best = null;
        series.forEach(s => s.points.forEach(p => { const d = Math.abs(X(p[0]) - mx); if (!best || d < best.d) best = { d, p, s }; }));
        if (!best) return;
        dot.setAttribute("cx", X(best.p[0])); dot.setAttribute("cy", Y(best.p[1])); dot.setAttribute("stroke", best.s.color);
        dot.style.display = "";
        const date = new Date(best.p[0]).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
        tip.innerHTML = `<b>${(opts.yFmt || (v => v))(best.p[1])}</b>${series.length > 1 ? " · " + best.s.name : ""}<br><span>${date}</span>`;
        tip.style.display = "block";
        tip.style.left = Math.min(Math.max(X(best.p[0]) - 40, 0), W - 110) + "px";
        tip.style.top = Math.max(Y(best.p[1]) - 52, 0) + "px";
      });
      overlay.addEventListener("mouseleave", () => { tip.style.display = "none"; dot.style.display = "none"; });
      evs.forEach(e => {                                // hover targets for the event markers
        const r = el("rect", { x: X(Math.max(e.x, x0)) - 6, y: m.t, width: 12, height: 22, fill: "transparent", style: "cursor:help" }, svg);
        el("title", {}, r).textContent = e.label;
      });
    };
    draw();
    const entry = { host, draw };
    registry.add(entry);
    return entry;
  }

  /* data: [{label,value}] */
  function bars(host, data, opts = {}) {
    const draw = () => {
      host.innerHTML = "";
      const W = host.clientWidth || 600, H = opts.height || 180, m = { l: 30, r: 8, t: 14, b: 24 };
      const max = Math.max(1, ...data.map(d => d.value));
      const T = niceTicks(0, max, 3);
      const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: "chart" }, host);
      const Y = v => H - m.b - v / T.hi * (H - m.t - m.b);
      T.ticks.forEach(t => {
        el("line", { x1: m.l, x2: W - m.r, y1: Y(t), y2: Y(t), class: "grid" }, svg);
        el("text", { x: m.l - 6, y: Y(t) + 4, class: "tick", "text-anchor": "end" }, svg).textContent = t;
      });
      const bw = (W - m.l - m.r) / data.length;
      data.forEach((d, i) => {
        const x = m.l + i * bw + bw * 0.18, w = bw * 0.64;
        const r = el("rect", { x, y: Y(d.value), width: w, height: Math.max(0, H - m.b - Y(d.value)), rx: 3, fill: opts.color || "var(--accent)" }, svg);
        el("title", {}, r).textContent = `${d.label}: ${d.value}`;
        if (i % Math.max(1, Math.ceil(data.length * 46 / (W - m.l - m.r))) === 0)
          el("text", { x: x + w / 2, y: H - 7, class: "tick", "text-anchor": "middle" }, svg).textContent = d.label;
      });
    };
    draw();
    registry.add({ host, draw });
  }

  function spark(points, color = "var(--accent)", w = 110, h = 30) {
    if (points.length < 2) return "";
    const ys = points.map(p => p[1]), lo = Math.min(...ys), hi = Math.max(...ys), n = points.length;
    const d = points.map((p, i) => `${i ? "L" : "M"}${(i / (n - 1) * (w - 4) + 2).toFixed(1)} ${(h - 3 - (hi === lo ? 0.5 : (p[1] - lo) / (hi - lo)) * (h - 6)).toFixed(1)}`).join("");
    return `<svg class="spark" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}"><path d="${d}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }

  window.addEventListener("resize", () => {
    for (const c of [...registry]) { if (!document.body.contains(c.host)) registry.delete(c); else c.draw(); }
  });
  return { line, bars, spark };
})();
