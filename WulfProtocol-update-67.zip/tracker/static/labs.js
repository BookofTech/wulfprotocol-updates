/* Labs & biomarkers: results with reference ranges, spike detection, and events (what changed around then). */
var Pages = window.Pages || (window.Pages = {});
const LabState = { cat: "All", showAuto: true, open: null, cmpA: null, cmpB: null };

const EV_STYLE = {
  med_start: { icon: "🟢", color: "#3aa675" }, dose_change: { icon: "🟠", color: "#e07a3f" }, med_stop: { icon: "⚫", color: "#7a8794" },
  illness: { icon: "🤒", color: "#d9534f" }, injury: { icon: "🩹", color: "#b05fd0" }, travel: { icon: "✈️", color: "#2f7dd1" },
  diet: { icon: "🍽️", color: "#d9a521" }, training: { icon: "🏋️", color: "#0e8a8c" }, stress: { icon: "😴", color: "#8a6fd0" }, other: { icon: "📌", color: "#7a8794" },
};
const evStyle = t => EV_STYLE[t] || EV_STYLE.other;
const dayMs = d => new Date(d + "T12:00").getTime();
const labNum = v => v == null ? "–" : (+v).toLocaleString(undefined, { maximumFractionDigits: Math.abs(v) < 1 ? 3 : Math.abs(v) < 10 ? 2 : 1 });
const rangeText = b => b.ref_low != null && b.ref_high != null ? `${labNum(b.ref_low)}–${labNum(b.ref_high)}` : b.ref_high != null ? `under ${labNum(b.ref_high)}` : b.ref_low != null ? `over ${labNum(b.ref_low)}` : "";

/* ---- shared by the Body tab too */
function fitTabs(active) {
  return `<div class="seg" id="ftabs"><button data-ftab="body" class="${active === "body" ? "on" : ""}">Body</button><button data-ftab="labs" class="${active === "labs" ? "on" : ""}">Labs &amp; biomarkers</button></div>`;
}
function wireFitTabs(view) {
  $$("[data-ftab]", view).forEach(b => b.onclick = () => { location.hash = b.dataset.ftab === "labs" ? "#/fitness/labs" : "#/fitness"; });
}
function chartEvents(events, showAuto = true) {
  return events.filter(e => showAuto || !e.auto).map(e => ({
    x: dayMs(e.date), x2: e.end_date ? dayMs(e.end_date) : null, color: evStyle(e.type).color,
    label: `${evStyle(e.type).icon} ${e.title} — ${fmtDate(e.date, true)}${e.end_date ? " to " + fmtDate(e.end_date, true) : ""}`, ev: e,
  }));
}
function eventLegend(chartEvs, x0, x1) {
  const inWin = chartEvs.filter(e => (e.x2 ?? e.x) >= x0 && e.x <= x1).sort((a, b) => a.x - b.x);
  if (!inWin.length) return "";
  return `<div class="ev-legend">${inWin.slice(0, 10).map(e => `<span><i style="background:${e.color}"></i>${esc(e.ev.title)} · ${fmtDate(e.ev.date)}</span>`).join("")}${inWin.length > 10 ? `<span>+${inWin.length - 10} more</span>` : ""}</div>`;
}
const statusBadge2 = s => s === "low" ? '<span class="badge warn">▼ low</span>' : s === "high" ? '<span class="badge bad">▲ high</span>' : s === "normal" ? '<span class="badge ok">in range</span>' : "";
const ctxLine = ctx => ctx && ctx.length ? ctx.map(c => `${evStyle(c.type).icon} ${esc(c.title)} <span class="muted">(${fmtDate(c.date)})</span>`).join(" · ") : "";

/* ================= page ================= */
Pages.labs = async function (view) {
  const D = await api("/labs"), bms = D.biomarkers, events = D.events;
  const withData = bms.filter(b => b.latest);
  const cats = ["All", ...D.categories.filter(c => bms.some(b => b.category === c))];
  if (!cats.includes(LabState.cat)) LabState.cat = "All";
  const shown = bms.filter(b => LabState.cat === "All" || b.category === LabState.cat);
  const manual = events.filter(e => !e.auto), listed = events.filter(e => LabState.showAuto || !e.auto);

  view.innerHTML = `
    <div class="page-head"><div><h1>Fitness</h1><p>Lab results and biomarkers, with events so you can see what changed around a spike.</p></div>
      <div class="row wrap">${fitTabs("labs")}</div></div>
    <div class="row wrap" style="margin-bottom:16px;gap:8px">
      <button class="btn primary" id="addres">+ Add lab results</button><button class="btn" id="addbm">+ Add markers</button><button class="btn" id="addev">+ Log an event</button>
      ${withData.length ? '<a class="btn" href="/api/labs/export.csv">⭳ Export CSV</a>' : ""}</div>
    ${bms.length ? "" : `<div class="card empty"><b>Track your labs</b>Pick the markers you get tested for (testosterone, estradiol, A1c, lipids, liver, blood counts…) or add your own. Then enter results from each blood draw and the app will chart them against the normal range and flag big changes.<br><br><button class="btn primary" id="addbm2">Choose markers to track</button></div>`}
    ${bms.length ? insightsCard(D) : ""}
    ${bms.length ? `<div class="row spread wrap" style="margin-bottom:12px"><div class="seg" id="cats">${cats.map(c => `<button data-c="${esc(c)}" class="${c === LabState.cat ? "on" : ""}">${esc(c)}</button>`).join("")}</div></div>
      <div class="grid bm-grid">${shown.map(bmCard).join("")}</div>` : ""}
    <div class="grid cols-2" style="margin-top:16px;align-items:start">
      <div class="card"><div class="row spread wrap" style="margin-bottom:6px"><h2 style="margin:0">Events</h2>
          <label class="chk small"><input type="checkbox" id="showauto" ${LabState.showAuto ? "checked" : ""}> show med start/stop dates</label></div>
        <p class="muted small" style="margin:0 0 8px">Things that could move your numbers. They appear as markers on the charts, and are listed with any spike.</p>
        ${listed.length ? `<div class="list">${listed.slice(0, 40).map(evRow).join("")}</div>` : '<div class="empty small">No events yet. Log a dose change, illness, travel, diet change…</div>'}
        ${manual.length ? "" : ""}</div>
      ${cmpCard(bms)}
    </div>
    <p class="muted small" style="margin-top:14px">Reference ranges are typical adult values and vary by lab, age and sex. Edit each marker to match the range printed on your report. This app records and charts your results; it can't interpret them. Talk to your clinician about anything that looks off.</p>`;

  wireFitTabs(view);
  const addRes = () => resultsModal(D), addBm = () => markersModal();
  $("#addres", view).onclick = addRes; $("#addbm", view).onclick = addBm; $("#addev", view).onclick = () => eventModal(null, () => Router.render());
  const b2 = $("#addbm2", view); if (b2) b2.onclick = addBm;
  $$("#cats button", view).forEach(b => b.onclick = () => { LabState.cat = b.dataset.c; Router.render(); });
  $$("[data-bm]", view).forEach(c => c.onclick = () => detailModal(D, +c.dataset.bm));
  $$("[data-ins]", view).forEach(c => c.onclick = e => { if (e.target.closest("a")) return; detailModal(D, +c.dataset.ins); });
  $$("[data-addev]", view).forEach(a => a.onclick = e => { e.stopPropagation(); eventModal(null, () => Router.render()); });
  const sa = $("#showauto", view); if (sa) sa.onchange = () => { LabState.showAuto = sa.checked; Router.render(); };
  const sp = $("#spike", view); if (sp) sp.onchange = async () => { await api("/settings", "PUT", { lab_spike_pct: +sp.value }); Router.render(); };
  $$("[data-evedit]", view).forEach(b => b.onclick = () => eventModal(events.find(e => String(e.id) === b.dataset.evedit), () => Router.render()));
  $$("[data-evdel]", view).forEach(b => b.onclick = async () => { if (await confirmBox("Delete this event?")) { await api("/events/" + b.dataset.evdel, "DELETE"); Router.render(); } });
  wireCompare(view, bms);
  if (LabState.open) { const id = LabState.open; LabState.open = null; if (bms.some(b => b.id === id)) detailModal(D, id); }
};

function bmCard(b) {
  const L = b.latest, pts = b.results.map((r, i) => [i, r.value]);
  const delta = L && L.change_pct != null ? `<span class="${L.spike ? (L.change_pct > 0 ? "up" : "down") : "muted"}">${L.change_pct > 0 ? "▲" : "▼"} ${Math.abs(L.change_pct)}%</span> <span class="muted">vs last</span> · ` : "";
  return `<div class="card bm ${L && L.status !== "normal" && L.status !== "none" ? "flag" : ""}" data-bm="${b.id}" tabindex="0">
    <div class="row spread"><b>${esc(b.name)}</b>${L ? statusBadge2(L.status) : ""}</div>
    ${L ? `<div class="row spread"><div><span class="price">${labNum(L.value)}</span> <span class="small muted">${esc(b.unit)}</span>
        <div class="small">${delta}<span class="muted">${b.days_since === 0 ? "today" : b.days_since + "d ago"}</span></div></div>${Charts.spark(pts, "var(--accent)", 90, 34)}</div>`
      : '<div class="muted small" style="padding:10px 0">No results yet — tap to add one</div>'}
    <div class="row spread small muted"><span>${rangeText(b) ? "Range " + rangeText(b) : "no range set"}</span>
      ${b.retest_due ? '<span class="badge warn">⏰ retest due</span>' : b.retest_in != null && b.retest_in <= 14 ? `<span class="badge">retest in ${Math.max(b.retest_in, 0)}d</span>` : ""}</div></div>`;
}

function insightsCard(D) {
  const ins = D.insights;
  const rows = ins.map(i => {
    if (i.kind === "spike") {
      const ctx = ctxLine(i.context);
      return `<div class="li ins" data-ins="${i.biomarker_id}" style="flex-direction:column;align-items:stretch;gap:3px;cursor:pointer">
        <div><b>${i.pct > 0 ? "📈" : "📉"} ${esc(i.name)}</b> ${i.pct > 0 ? "rose" : "fell"} <b>${Math.abs(i.pct)}%</b> to ${labNum(i.value)} ${esc(i.unit)} <span class="muted">(${fmtDate(i.date, true)})</span> ${statusBadge2(i.status)}</div>
        <div class="small">${ctx ? `<span class="muted">Since the last test:</span> ${ctx}` : `<span class="muted">No events logged since the last test.</span> <a href="javascript:void 0" data-addev>Log one</a>`}</div></div>`;
    }
    if (i.kind === "range") return `<div class="li ins" data-ins="${i.biomarker_id}" style="cursor:pointer"><div class="grow"><b>${i.status === "high" ? "⚠" : "⚠"} ${esc(i.name)}</b> is <b>${i.status}</b>: ${labNum(i.value)} ${esc(i.unit)} <span class="muted">(range ${rangeText(i) || ""}, ${fmtDate(i.date, true)})</span></div></div>`;
    return `<div class="li ins" data-ins="${i.biomarker_id}" style="cursor:pointer"><div class="grow">⏰ <b>${esc(i.name)}</b> retest due <span class="muted">— last tested ${i.days_since} days ago${i.overdue > 0 ? `, ${i.overdue} days past your reminder` : ""}</span></div></div>`;
  }).join("");
  const anyData = D.biomarkers.some(b => b.latest);
  return `<div class="card" style="margin-bottom:16px"><div class="row spread wrap"><h2 style="margin:0">Worth a look ${ins.length ? `<span class="badge ${ins.some(i => i.kind !== "retest") ? "warn" : ""}">${ins.length}</span>` : ""}</h2>
      <label class="small muted">Flag changes of <select id="spike" style="width:auto;padding:3px 6px">${[10, 15, 25, 40, 50].map(v => `<option ${v === D.spike_pct ? "selected" : ""} value="${v}">${v}%</option>`).join("")}</select> or more</label></div>
    ${ins.length ? `<div class="list" style="margin-top:8px">${rows}</div>` : `<div class="empty small">${anyData ? "✓ Nothing flagged — latest results are in range with no big jumps." : "Add your first results and anything unusual will show up here."}</div>`}</div>`;
}

function evRow(e) {
  const s = evStyle(e.type);
  return `<div class="li"><span style="font-size:1.1rem">${s.icon}</span><div class="grow"><div class="t">${esc(e.title)} ${e.auto ? '<span class="badge">auto</span>' : ""}</div>
    <div class="m">${fmtDate(e.date, true)}${e.end_date ? " → " + fmtDate(e.end_date, true) : ""}${e.notes ? " · " + esc(e.notes) : ""}</div></div>
    ${e.auto ? "" : `<span class="row" style="gap:0"><button class="btn ghost sm" data-evedit="${e.id}">✎</button><button class="btn ghost sm" data-evdel="${e.id}">✕</button></span>`}</div>`;
}

/* ---- compare two draws */
function cmpCard(bms) {
  const dates = [...new Set(bms.flatMap(b => b.results.map(r => r.date)))].sort().reverse();
  if (dates.length < 2) return `<div class="card"><h2>Compare blood draws</h2><div class="empty small">Once you have results from two different dates you can compare them side by side here.</div></div>`;
  const A = LabState.cmpA && dates.includes(LabState.cmpA) ? LabState.cmpA : dates[1], B = LabState.cmpB && dates.includes(LabState.cmpB) ? LabState.cmpB : dates[0];
  const opts = sel => dates.map(d => `<option value="${d}" ${d === sel ? "selected" : ""}>${fmtDate(d, true)}</option>`).join("");
  const at = (b, d) => { const r = b.results.filter(x => x.date === d); return r.length ? r[r.length - 1].value : null; };
  const rows = bms.map(b => ({ b, a: at(b, A), c: at(b, B) })).filter(r => r.a != null || r.c != null).map(({ b, a, c }) => {
    const d = a != null && c != null ? c - a : null, p = d != null && a ? d / Math.abs(a) * 100 : null;
    return `<tr><td>${esc(b.name)}</td><td class="r">${a != null ? labNum(a) : "–"}</td><td class="r">${c != null ? labNum(c) : "–"}</td>
      <td class="r ${p != null && Math.abs(p) >= 25 ? (p > 0 ? "up" : "down") : "muted"}">${d != null ? (d > 0 ? "+" : "") + labNum(d) + " (" + (p > 0 ? "+" : "") + p.toFixed(0) + "%)" : ""}</td><td class="muted small">${esc(b.unit)}</td></tr>`;
  }).join("");
  return `<div class="card"><h2>Compare blood draws</h2><div class="row wrap" style="gap:8px;margin-bottom:8px"><select id="cmpa" style="width:auto">${opts(A)}</select><span class="muted">→</span><select id="cmpb" style="width:auto">${opts(B)}</select></div>
    <div class="scroll-x"><table><thead><tr><th>Marker</th><th class="r" style="white-space:nowrap">${fmtDate(A)}</th><th class="r" style="white-space:nowrap">${fmtDate(B)}</th><th class="r">Change</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}
function wireCompare(view) {
  const a = $("#cmpa", view), b = $("#cmpb", view);
  if (a) a.onchange = () => { LabState.cmpA = a.value; Router.render(); };
  if (b) b.onchange = () => { LabState.cmpB = b.value; Router.render(); };
}

/* ================= modals ================= */
function detailModal(D, id) {
  const b = D.biomarkers.find(x => x.id === id); if (!b) return;
  const evs = chartEvents(D.events, LabState.showAuto), rs = b.results;
  const spikes = rs.filter(r => r.spike).reverse();
  const m = modal(`<div class="row spread wrap"><h2 style="margin:0">${esc(b.name)} <span class="muted small">${esc(b.unit)}</span></h2>${b.latest ? statusBadge2(b.latest.status) : ""}</div>
    <div class="small muted" style="margin:2px 0 10px">${rangeText(b) ? "Normal range " + rangeText(b) + " " + esc(b.unit) + " · " : ""}${esc(b.category)}${b.retest_days ? " · retest every " + b.retest_days + " days" : ""}</div>
    <div class="chart-host" id="lc"></div><div id="lleg"></div>
    <form id="qa" class="row wrap" style="gap:8px;margin:14px 0 4px"><input type="date" name="date" value="${todayStr()}" required style="width:auto">
      <input type="number" step="any" name="value" placeholder="New result (${esc(b.unit)})" required style="width:220px"><input name="lab" placeholder="Lab (optional)" style="width:150px"><button class="btn primary">Add result</button></form>
    ${spikes.length ? `<h3 style="margin:16px 0 6px">Spikes &amp; what was happening</h3>${spikes.map(r => `<div class="small" style="margin-bottom:6px"><b>${fmtDate(r.date, true)}</b> — <span class="${r.change_pct > 0 ? "up" : "down"}">${r.change_pct > 0 ? "▲ +" : "▼ "}${r.change_pct}%</span> to ${labNum(r.value)}<br>
      ${r.context.length ? ctxLine(r.context) : '<span class="muted">No events logged between the previous test and this one.</span>'}</div>`).join("")}` : ""}
    <h3 style="margin:16px 0 6px">Results</h3>
    ${rs.length ? `<div class="scroll-x"><table><tbody>${rs.slice().reverse().map(r => `<tr><td>${fmtDate(r.date, true)}</td><td><b>${labNum(r.value)}</b> <span class="muted small">${esc(b.unit)}</span></td><td>${statusBadge2(r.status)}</td>
      <td class="small ${r.spike ? (r.change_pct > 0 ? "up" : "down") : "muted"}">${r.change_pct != null ? (r.change_pct > 0 ? "▲ " : "▼ ") + Math.abs(r.change_pct) + "%" : ""}</td><td class="muted small">${esc([r.lab, r.notes].filter(Boolean).join(" · "))}</td>
      <td class="r"><button class="btn ghost sm" data-redit="${r.id}" title="Edit">✎</button><button class="btn ghost sm" data-rdel="${r.id}" title="Delete">✕</button></td></tr>`).join("")}</tbody></table></div>` : '<div class="empty small">No results yet.</div>'}
    <details style="margin-top:16px"><summary class="small muted" style="cursor:pointer">Edit marker settings</summary>
      <form id="ef" class="form-grid" style="margin-top:10px">
        <label class="f">Name<input name="name" value="${esc(b.name)}" required></label><label class="f">Unit<input name="unit" value="${esc(b.unit)}"></label>
        <label class="f">Range low<input type="number" step="any" name="ref_low" value="${b.ref_low ?? ""}"></label><label class="f">Range high<input type="number" step="any" name="ref_high" value="${b.ref_high ?? ""}"></label>
        <label class="f">Category<select name="category">${D.categories.map(c => `<option ${c === b.category ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label>
        <label class="f">Remind me to retest every (days)<input type="number" min="1" name="retest_days" value="${b.retest_days ?? ""}" placeholder="e.g. 90"></label>
        <label class="f full">Notes<input name="notes" value="${esc(b.notes || "")}"></label>
        <div class="actions full"><button type="button" class="btn danger" id="delbm">Delete marker</button><button class="btn primary">Save</button></div></form></details>
    <div class="actions"><button class="btn" data-close>Close</button></div>`, {
    wide: true,
    onMount: (el, close) => {
      const done = () => { LabState.open = id; close(); Router.render(); };
      if (rs.length) {
        const last = rs[rs.length - 1], x0 = dayMs(rs[0].date), x1 = Math.max(dayMs(todayStr()), dayMs(last.date));
        const opts = { yFmt: v => labNum(v), height: 260, events: evs, xDomain: [x0, x1] };
        if (b.ref_low != null || b.ref_high != null) opts.band = { lo: b.ref_low, hi: b.ref_high };
        Charts.line($("#lc", el), [{ name: b.name, color: "var(--accent)", points: rs.map(r => [dayMs(r.date), r.value]) }], opts);
        $("#lleg", el).innerHTML = eventLegend(evs, x0, x1);
      } else $("#lc", el).innerHTML = '<div class="chart-empty">Add a result to see the chart</div>';
      $("#qa", el).onsubmit = async e => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
        await run($(".primary", e.target), async () => { await api("/lab-results", "POST", { date: f.date, lab: f.lab, results: [{ biomarker_id: id, value: f.value }] }); done(); }); };
      $$("[data-rdel]", el).forEach(x => x.onclick = async () => { await api("/lab-results/" + x.dataset.rdel, "DELETE"); done(); });
      $$("[data-redit]", el).forEach(x => x.onclick = () => { const r = rs.find(z => z.id === +x.dataset.redit); resultEditModal(r, b, done); });
      $("#ef", el).onsubmit = async e => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
        await run($("#ef .primary", el), async () => { await api("/biomarkers/" + id, "PUT", f); done(); }); };
      $("#delbm", el).onclick = async () => { if (await confirmBox(`Delete ${b.name} and all ${rs.length} of its results?`)) { await api("/biomarkers/" + id, "DELETE"); close(); Router.render(); } };
    },
  });
}

function resultEditModal(r, b, done) {
  modal(`<h2>Edit result</h2><form id="f" class="form-grid">
    <label class="f">Date<input type="date" name="date" value="${r.date}" required></label><label class="f">Value (${esc(b.unit)})<input type="number" step="any" name="value" value="${r.value}" required></label>
    <label class="f">Lab<input name="lab" value="${esc(r.lab || "")}"></label><label class="f">Notes<input name="notes" value="${esc(r.notes || "")}"></label>
    <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div></form>`, {
    onMount: (el, close) => $("#f", el).onsubmit = async e => { e.preventDefault(); await run(null, async () => { await api("/lab-results/" + r.id, "PUT", Object.fromEntries(new FormData(e.target))); close(); done(); }); },
  });
}

function resultsModal(D) {
  if (!D.biomarkers.length) { toast("Add the markers you track first", true); return markersModal(); }
  const groups = D.categories.map(c => [c, D.biomarkers.filter(b => b.category === c)]).filter(g => g[1].length);
  modal(`<h2>Add lab results</h2><form id="f"><div class="form-grid"><label class="f">Date of blood draw<input type="date" name="date" value="${todayStr()}" required></label>
      <label class="f">Lab / clinic <span class="muted">(optional)</span><input name="lab" placeholder="e.g. Quest"></label></div>
    <p class="muted small" style="margin:10px 0 4px">Fill in only the markers on this report; leave the rest blank.</p>
    <div style="max-height:46vh;overflow:auto;padding-right:4px">${groups.map(([c, list]) => `<div class="day-head">${esc(c)}</div>${list.map(b => `<div class="row" style="gap:8px;padding:4px 0">
      <span class="grow">${esc(b.name)}${b.latest ? ` <span class="small muted">last ${labNum(b.latest.value)}</span>` : ""}</span>
      <input type="number" step="any" data-b="${b.id}" style="width:120px"><span class="small muted" style="width:70px">${esc(b.unit)}</span></div>`).join("")}`).join("")}</div>
    <div class="actions"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save results</button></div></form>`, {
    wide: true,
    onMount: (el, close) => $("#f", el).onsubmit = async e => {
      e.preventDefault();
      const f = Object.fromEntries(new FormData(e.target)), results = $$("[data-b]", el).filter(i => i.value !== "").map(i => ({ biomarker_id: +i.dataset.b, value: i.value }));
      if (!results.length) return toast("Enter at least one value", true);
      await run($(".primary", el), async () => { const r = await api("/lab-results", "POST", { date: f.date, lab: f.lab, results }); close(); toast(`Saved ${r.added} result${r.added === 1 ? "" : "s"}`); Router.render(); });
    },
  });
}

async function markersModal() {
  const P = await api("/labs/presets");
  const groups = P.categories.map(c => [c, P.presets.filter(p => p.category === c)]).filter(g => g[1].length);
  modal(`<h2>Add markers to track</h2><form id="f">
    <p class="muted small" style="margin:0 0 6px">Tick what you get tested for. Ranges are typical adult values, so edit them later to match your lab report.</p>
    <div style="max-height:44vh;overflow:auto;padding-right:4px">${groups.map(([c, list]) => `<div class="day-head">${esc(c)}</div><div class="pl-items">${list.map((p, i) => `<label class="pl-item ${p.added ? "" : ""}" style="${p.added ? "opacity:.5" : ""}">
      <input type="checkbox" data-p='${esc(JSON.stringify(p))}' ${p.added ? "checked disabled" : ""}><span class="grow">${esc(p.name)} <span class="small muted">${esc(p.unit)}${p.added ? " · added" : ""}</span></span></label>`).join("")}</div>`).join("")}</div>
    <details style="margin-top:12px"><summary class="small" style="cursor:pointer">+ Add your own marker</summary><div class="form-grid" style="margin-top:8px">
      <label class="f">Name<input name="cname" placeholder="e.g. Growth hormone"></label><label class="f">Unit<input name="cunit" placeholder="e.g. ng/mL"></label>
      <label class="f">Range low<input type="number" step="any" name="clo"></label><label class="f">Range high<input type="number" step="any" name="chi"></label>
      <label class="f full">Category<select name="ccat">${P.categories.map(c => `<option ${c === "Other" ? "selected" : ""}>${esc(c)}</option>`).join("")}</select></label></div></details>
    <div class="actions"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Add selected</button></div></form>`, {
    wide: true,
    onMount: (el, close) => $("#f", el).onsubmit = async e => {
      e.preventDefault();
      const f = Object.fromEntries(new FormData(e.target)), list = $$("[data-p]:checked:not(:disabled)", el).map(i => JSON.parse(i.dataset.p));
      if (f.cname && f.cname.trim()) list.push({ name: f.cname, unit: f.cunit, ref_low: f.clo, ref_high: f.chi, category: f.ccat });
      if (!list.length) return toast("Pick at least one marker", true);
      await run($(".primary", el), async () => { await api("/biomarkers", "POST", list); close(); toast(`Added ${list.length} marker${list.length === 1 ? "" : "s"}`); Router.render(); });
    },
  });
}

async function eventModal(ev, done) {
  const [meds, T] = await Promise.all([api("/meds").catch(() => []), api("/events")]);
  const types = T.types, medTypes = ["med_start", "dose_change", "med_stop"];
  const m = modal(`<h2>${ev ? "Edit event" : "Log an event"}</h2><p class="muted small" style="margin:0 0 8px">Anything that could move your numbers — it shows as a marker on the charts.</p>
    <form id="f" class="form-grid">
    <label class="f">Type<select name="type" id="etype">${Object.entries(types).map(([k, v]) => `<option value="${k}" ${ev && ev.type === k ? "selected" : ""}>${evStyle(k).icon} ${esc(v)}</option>`).join("")}</select></label>
    <label class="f">Medication <span class="muted">(optional)</span><select name="med_id" id="emed"><option value="">—</option>${meds.map(x => `<option value="${x.id}" ${ev && ev.med_id === x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></label>
    <label class="f full">What happened<input name="title" id="etitle" value="${esc(ev ? ev.title : "")}" placeholder="e.g. Raised dose to 250 mcg"></label>
    <label class="f">Date<input type="date" name="date" value="${ev ? ev.date : todayStr()}" required></label>
    <label class="f">Ended <span class="muted">(optional, for a span like an illness)</span><input type="date" name="end_date" value="${ev && ev.end_date ? ev.end_date : ""}"></label>
    <label class="f full">Notes<input name="notes" value="${esc(ev ? ev.notes || "" : "")}"></label>
    <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div></form>`, {
    onMount: (el, close) => {
      const t = $("#etype", el), md = $("#emed", el), ti = $("#etitle", el);
      const hint = () => { const mn = (meds.find(x => x.id === +md.value) || {}).name; ti.placeholder = medTypes.includes(t.value) && mn ? `${types[t.value]}: ${mn}` : types[t.value]; };
      t.onchange = md.onchange = hint; hint();
      $("#f", el).onsubmit = async e => {
        e.preventDefault();
        const f = Object.fromEntries(new FormData(e.target)); f.title = (f.title || "").trim() || ti.placeholder;
        await run($(".primary", el), async () => { ev ? await api("/events/" + ev.id, "PUT", f) : await api("/events", "POST", f); close(); toast("Saved"); done && done(); });
      };
    },
  });
}
