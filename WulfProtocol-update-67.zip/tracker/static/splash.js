/* Moonrise launch screen: shown on every full page load for splash_seconds (release.json), or until you click / press a key. */
window.Splash = (function () {
  try { const g = localStorage.getItem("wp_glow"); if (g) document.documentElement.dataset.glow = g; } catch (e) { }      // the colour you picked in Settings
  const el = document.getElementById("splash");
  if (!el) return { ready() {}, hide() {} };
  const reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const secs = parseFloat(el.dataset.seconds), t0 = Date.now(), MIN = (secs >= 0 && secs <= 60 ? secs : 6) * 1000, MAX = MIN + 6000;
  let done = false;
  function hide() {
    if (done) return; done = true;
    el.setAttribute("aria-hidden", "true"); el.classList.add("out");
    setTimeout(() => el.remove(), reduce ? 0 : 400);
  }
  function ready() { setTimeout(hide, Math.max(0, MIN - (Date.now() - t0))); }
  ["click", "touchstart"].forEach(e => el.addEventListener(e, hide, { once: true }));
  document.addEventListener("keydown", hide, { once: true });
  setTimeout(hide, MAX);                 // fail-safe: never hide the app behind the splash
  if (window.__appReady) ready();
  return { ready, hide };
})();
