/* Concentration calculator: pure math on the numbers you enter. Nothing is saved or sent anywhere. */
var Pages = window.Pages || (window.Pages = {});
const CalcState = { v: {} };

const WFREQ = [["Single dose (no frequency)", 0], ["Once per day", 1], ["Twice per day", 2], ["Three times per day", 3], ["Four times per day", 4],
  ["Every 4 hours", 6], ["Every 3 hours", 8], ["Every 2 hours", 12], ["Every hour", 24]];
const LB_PER_KG = 2.20462262;

const calcFmt = (n, sig = 4) => {
  if (!isFinite(n)) return "—";
  if (n === 0) return "0";
  const a = Math.abs(n), d = Math.max(0, sig - 1 - Math.floor(Math.log10(a)));
  return (+n.toFixed(Math.min(d, 8))).toLocaleString(undefined, { maximumFractionDigits: 8 });
};

Pages.calculator = async function (view) {
  const S = CalcState;
  const mass = (id, label, hint) => `<div class="f calc-f"><label for="${id}">${label}</label>
      <div class="calc-in"><input id="${id}" type="number" min="0" step="any" inputmode="decimal" value="${S.v[id] ?? ""}">
      <span class="seg" data-unit="${id}">${["mg", "mcg"].map(u => `<button type="button" data-u="${u}" class="${(S.v[id + "_u"] || "mg") === u ? "on" : ""}">${u}</button>`).join("")}</span></div>
      <span class="small muted">${hint}</span></div>`;
  const vol = (id, label, hint) => `<div class="f calc-f"><label for="${id}">${label}</label>
      <div class="calc-in"><input id="${id}" type="number" min="0" step="any" inputmode="decimal" value="${S.v[id] ?? ""}"><span class="calc-u">mL</span></div>
      <span class="small muted">${hint}</span></div>`;
  const forms = {
    volume: `${mass("vial", "Amount in the vial", "Total amount printed on the vial label")}
             ${vol("total", "Total solution volume", "Final liquid volume in the vial")}
             ${mass("want", "Amount you want to measure", "You choose this value; the tool only converts it")}`,
  };
  view.innerHTML = `
    <div class="page-head"><div><h1>Concentration calculator</h1><p>Converts the numbers you enter. It doesn't choose or recommend amounts — check your own protocol or prescriber.</p></div>
      <button class="btn" id="cclear">Clear values</button></div>
    <div class="card" style="max-width:760px">
      <div class="form-grid calc-form">${forms.volume}</div>
      <div id="cout" class="calc-out"></div>
    </div>
    <div class="card" style="max-width:760px;margin-top:16px"><h2>Weight-based dose</h2>
      <p class="muted small" style="margin:-4px 0 12px">Multiplies body weight by a dose-per-weight value you enter. It doesn't choose a dose — use the figure from your label or prescriber.</p>
      <div class="form-grid calc-form">
        <div class="f calc-f"><label for="wt">Your weight</label>
          <div class="calc-in"><input id="wt" type="number" min="0" step="any" inputmode="decimal" value="${S.v.wt ?? ""}">
          <span class="seg" data-wunit="wt">${["kg", "lb"].map(u => `<button type="button" data-u="${u}" class="${(S.v.wt_u || "kg") === u ? "on" : ""}">${u}</button>`).join("")}</span></div></div>
        <div class="f calc-f"><label for="wd">Dosage per body weight</label>
          <div class="calc-in"><input id="wd" type="number" min="0" step="any" inputmode="decimal" value="${S.v.wd ?? ""}">
          <span class="seg" data-wunit="wdm">${["mg", "mcg"].map(u => `<button type="button" data-u="${u}" class="${(S.v.wdm_u || "mg") === u ? "on" : ""}">${u}</button>`).join("")}</span>
          <span class="seg" data-wunit="wdw">${["kg", "lb"].map(u => `<button type="button" data-u="${u}" class="${(S.v.wdw_u || "kg") === u ? "on" : ""}">per ${u}</button>`).join("")}</span></div>
          <span class="small muted">Taken from the medication label or prescription. Weight and dosage can use different units (kg vs lb); it converts.</span></div>
        <div class="f calc-f"><label for="wf">Frequency</label>
          <select id="wf">${WFREQ.map(([t, n], i) => `<option value="${i}" ${+(S.v.wf ?? 0) === i ? "selected" : ""}>${t}</option>`).join("")}</select></div>
        <div class="f calc-f"><label for="wc">Medicine concentration <span class="muted">(optional, for liquids)</span></label>
          <div class="calc-in"><input id="wc" type="number" min="0" step="any" inputmode="decimal" value="${S.v.wc ?? ""}"><span class="calc-u">mg/mL</span></div></div>
      </div>
      <div id="wout" class="calc-out"></div></div>
    <div class="card muted small" style="max-width:760px;margin-top:16px"><b>How it works</b><br>
      Concentration = vial amount ÷ solution volume.<br>
      Volume = amount wanted ÷ concentration.<br>
      Weight-based: dose = weight × dosage per weight; liquid volume = dose ÷ concentration. 1 kg = 2.20462 lb.<br>
      1 mg = 1,000 mcg. Flipping mg/mcg converts the number in the box so the physical amount stays the same.</div>`;

  const val = id => { const x = parseFloat($("#" + id, view)?.value); return x > 0 ? x : null; };
  const mcg = id => { const x = val(id); return x == null ? null : ($("[data-unit=" + id + "] .on", view).dataset.u === "mg" ? x * 1000 : x); };

  function update() {
    const out = $("#cout", view); let main = "", rows = [], copy = "", bar = "";
    const row = (k, v) => `<div class="spread row"><span class="muted">${k}</span><b>${v}</b></div>`;
    const concStr = c => `${calcFmt(c / 1000)} mg/mL <span class="muted small">(${calcFmt(c)} mcg/mL)</span>`;
    const vialM = mcg("vial");
    {
      const t = val("total"), w = mcg("want");
      if (vialM && t && w) {
        const c = vialM / t, ml = w / c;
        main = `${calcFmt(ml)} mL`;
        rows = [row("Concentration", concStr(c)), row("Entered amount", `${calcFmt(w / 1000)} mg (${calcFmt(w)} mcg)`), row("On a U-100 syringe", `${calcFmt(ml * 100, 3)} units`)];
        if (ml > t) rows.push(`<div class="err">⚠ That's more than the total volume in the vial (${calcFmt(t)} mL).</div>`);
        const pct = Math.min(100, ml / t * 100);
        bar = `<div class="calc-bar"><i style="width:${pct}%"></i></div><div class="small muted">Volume in context: ${calcFmt(ml)} of ${calcFmt(t)} mL (a proportion, not a measuring scale)</div>`;
        copy = `${calcFmt(ml)} mL (${calcFmt(w / 1000)} mg at ${calcFmt(c / 1000)} mg/mL)`;
      }
    }
    out.innerHTML = main ? `<div class="calc-main">${main}</div>${rows.join("")}${bar}<button class="btn sm" id="ccopy" style="margin-top:10px">Copy result</button>`
      : `<div class="muted">Enter all the values above to see the result.</div>`;
    const cb = $("#ccopy", out);
    if (cb) cb.onclick = async () => { try { await navigator.clipboard.writeText(copy); toast("Copied"); } catch (e) { toast("Couldn't copy — select the text instead", true); } };
  }

  const save = () => $$("input", view).forEach(i => { if (i.id) S.v[i.id] = i.value; });
  $$("input[type=number]", view).forEach(i => i.oninput = () => { save(); update(); });
  $$("[data-unit]", view).forEach(sg => $$("button", sg).forEach(b => b.onclick = () => {
    const id = sg.dataset.unit, cur = $(".on", sg).dataset.u, to = b.dataset.u;
    if (cur === to) return;
    const inp = $("#" + id, view), x = parseFloat(inp.value);
    if (x >= 0) inp.value = +(to === "mcg" ? x * 1000 : x / 1000).toPrecision(10);
    $$("button", sg).forEach(o => o.classList.toggle("on", o === b));
    S.v[id + "_u"] = to; save(); update();
  }));
  $("#cclear", view).onclick = () => { S.v = {}; Pages.calculator(view); };

  /* ---- weight-based dose ---- */
  const wsel = id => $("[data-wunit=" + id + "] .on", view).dataset.u;
  function updateW() {
    const out = $("#wout", view), x = id => { const n = parseFloat($("#" + id, view).value); return n > 0 ? n : null; };
    const wt = x("wt"), wd = x("wd"), conc = x("wc"), per = WFREQ[+$("#wf", view).value][1];
    if (!(wt && wd)) { out.innerHTML = '<div class="muted">Enter your weight and the dosage per weight to see the dose.</div>'; return; }
    const kg = wsel("wt") === "kg" ? wt : wt / LB_PER_KG;
    const perKg = wsel("wdw") === "kg" ? wd : wd * LB_PER_KG;          // dosage per kg (in the chosen mass unit)
    const mg = (wsel("wdm") === "mg" ? perKg : perKg / 1000) * kg;      // total dose in mg
    const row = (k, v) => `<div class="spread row"><span class="muted">${k}</span><b>${v}</b></div>`;
    const both = m => `${calcFmt(m)} mg <span class="muted small">(${calcFmt(m * 1000)} mcg)</span>`;
    let rows = [], copy = `${calcFmt(mg)} mg`;
    if (conc) { const ml = mg / conc; rows.push(row("Liquid dose", `${calcFmt(ml)} mL`)); if (ml <= 1) rows.push(row("On a U-100 syringe", `${calcFmt(ml * 100, 3)} units`)); copy += ` = ${calcFmt(ml)} mL at ${calcFmt(conc)} mg/mL`; }
    if (per) { rows.push(row(`Doses per day`, per)); rows.push(row("Total per day", both(mg * per))); copy += `; ${per}x/day = ${calcFmt(mg * per)} mg/day`; }
    out.innerHTML = `<div class="calc-main">${both(mg)}</div>${rows.join("")}<button class="btn sm" id="wcopy" style="margin-top:10px">Copy result</button>`;
    $("#wcopy", out).onclick = async () => { try { await navigator.clipboard.writeText(copy); toast("Copied"); } catch (e) { toast("Couldn't copy — select the text instead", true); } };
  }
  const wsave = () => ["wt", "wd", "wc", "wf"].forEach(id => S.v[id] = $("#" + id, view).value);
  ["wt", "wd", "wc"].forEach(id => $("#" + id, view).oninput = () => { wsave(); updateW(); });
  $("#wf", view).onchange = () => { wsave(); updateW(); };
  $$("[data-wunit]", view).forEach(sg => $$("button", sg).forEach(b => b.onclick = () => {
    $$("button", sg).forEach(o => o.classList.toggle("on", o === b)); S.v[sg.dataset.wunit + "_u"] = b.dataset.u;
    if (sg.dataset.wunit === "wt") { S.v.wt_u = b.dataset.u; }
    updateW();
  }));
  updateW();
  update();
};
