var Pages = window.Pages || (window.Pages = {});
const FitState = { metric: "weight", range: 90 };

/* ---- trend helpers (rows are {date, value} in stored units, oldest first) */
const dayNum = d => Math.round(new Date(d + "T12:00").getTime() / 864e5);
function movingAvg(rows, days = 7) {                // average of every entry in the last `days` days, for each entry
  return rows.map((r, i) => {
    const t = dayNum(r.date); let s = 0, n = 0;
    for (let j = i; j >= 0 && t - dayNum(rows[j].date) < days; j--) { s += rows[j].value; n++; }
    return { date: r.date, value: s / n };
  });
}
function pacePerWeek(rows, lookbackDays = 28) {     // straight-line slope over the recent entries, or null if there isn't enough
  if (!rows.length) return null;
  const last = dayNum(rows[rows.length - 1].date), pts = rows.filter(r => last - dayNum(r.date) <= lookbackDays).map(r => [dayNum(r.date), r.value]);
  if (pts.length < 2 || pts[pts.length - 1][0] - pts[0][0] < 5) return null;
  const n = pts.length, mx = pts.reduce((a, p) => a + p[0], 0) / n, my = pts.reduce((a, p) => a + p[1], 0) / n;
  const den = pts.reduce((a, p) => a + (p[0] - mx) ** 2, 0); if (!den) return null;
  return pts.reduce((a, p) => a + (p[0] - mx) * (p[1] - my), 0) / den * 7;
}
const monthChange = rows => {                       // latest vs. the entry from ~30 days ago (or the first one)
  if (rows.length < 2) return null;
  const cur = rows[rows.length - 1], cut = new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10);
  const old = rows.filter(r => r.date <= cut), ref = old.length ? old[old.length - 1] : rows[0];
  return ref === cur ? null : cur.value - ref.value;
};

Pages.fitness = async function (view) {
  if (location.hash.startsWith("#/fitness/labs")) return Pages.labs(view);
  const [profile, rows, evd] = await Promise.all([api("/profile"), api("/metrics"), api("/events").catch(() => ({ events: [] }))]);
  App.profile = profile;
  const byMetric = {};
  rows.forEach(r => (byMetric[r.metric] = byMetric[r.metric] || []).push(r));
  const metrics = ["weight", ...Object.keys(byMetric).filter(k => k !== "weight")];
  if (!metrics.includes(FitState.metric)) FitState.metric = "weight";
  const k = FitState.metric, isW = k === "weight", u = metricUnit(k);
  const imp = imperial();
  const hcm = profile.height_cm, totalIn = hcm ? hcm / 2.54 : null;
  const ft = totalIn ? Math.floor(totalIn / 12) : "", inch = totalIn ? +(totalIn % 12).toFixed(1) : "";
  const mine = byMetric[k] || [], w = byMetric.weight || [], cur = mine.length ? mine[mine.length - 1] : null;
  const wcur = w.length ? w[w.length - 1] : null;
  const bmi = wcur && hcm ? wcur.value / (hcm / 100) ** 2 : null;
  const chg = monthChange(mine);
  const goal = profile.goal_weight_kg, toGoal = wcur && goal ? wcur.value - goal : null;
  const dSign = v => (v > 0 ? "+" : v < 0 ? "−" : "") + num(Math.abs(toDisplay(k, v)), 1);
  const pace = pacePerWeek(mine);
  const paceTxt = pace == null ? null : `${pace > 0 ? "+" : pace < 0 ? "−" : ""}${num(Math.abs(toDisplay(k, pace)), 2)} ${u} / week`;
  const profileDone = !!(hcm && profile.birth_date && goal);
  const profLine = [totalIn ? (imp ? `${ft}′${inch}″` : `${hcm} cm`) : null, profile.sex, profile.age != null ? `age ${profile.age}` : null, goal ? `goal ${fmtMetric("weight", goal)}` : null].filter(Boolean).join(" · ");

  /* tiles: weight tab shows the weight summary; any other metric shows its own */
  const tile = (kk, v, s, cls = "") => `<div class="tile ${cls}"><div class="k">${kk}</div><div class="v">${v}</div><div class="s">${s}</div></div>`;
  const vs = mine.map(r => toDisplay(k, r.value));
  const tiles = isW ? [
    tile("Current weight", cur ? `${num(toDisplay("weight", cur.value))}<span class="small muted"> ${u}</span>` : "–", cur ? "as of " + fmtDate(cur.date) : "log your first weight above"),
    tile("Change (30 days)", chg != null ? dSign(chg) : "–", chg != null ? u : "needs two weigh-ins"),
    tile("BMI", bmi ? num(bmi) : "–", hcm ? "" : "add your height"),
    tile("To goal", toGoal == null ? "–" : Math.abs(toGoal) < 0.05 ? "🎉" : num(Math.abs(toDisplay("weight", toGoal)), 1), toGoal == null ? "set a goal weight" : Math.abs(toGoal) < 0.05 ? "goal reached" : `${u} to ${toGoal > 0 ? "lose" : "gain"} · goal ${fmtMetric("weight", goal)}`),
    tile("Age", profile.age ?? "–", ""),
  ] : [
    tile("Latest", cur ? `${num(toDisplay(k, cur.value), 1)}<span class="small muted"> ${u}</span>` : "–", cur ? "as of " + fmtDate(cur.date) : ""),
    tile("Change (30 days)", chg != null ? dSign(chg) : "–", chg != null ? u : "needs two entries"),
    tile("Lowest", vs.length ? num(Math.min(...vs), 1) : "–", u),
    tile("Highest", vs.length ? num(Math.max(...vs), 1) : "–", u),
    tile("Entries", mine.length, ""),
  ];

  /* goal card (weight only) */
  let goalCard = "";
  if (isW) {
    if (!goal) goalCard = `<div class="card"><h2>Goal</h2><p class="muted" style="margin:0">Set a goal weight under <b>About you</b> to see your progress here.</p></div>`;
    else if (wcur) {
      const start = w[0].value, total = start - goal, done = start - wcur.value;
      const pct = Math.abs(total) < 0.05 ? 100 : Math.max(0, Math.min(100, done / total * 100));
      const reached = Math.abs(toGoal) < 0.05 || (total > 0 ? wcur.value <= goal : wcur.value >= goal);
      let eta = "";
      if (!reached && pace) {
        const need = goal - wcur.value, days = need / (pace / 7);           // days until the line hits the goal
        eta = days > 0 && days < 365 * 3
          ? `At this pace you'd reach it around <b>${new Date(Date.now() + days * 864e5).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" })}</b>.`
          : `Your recent trend is moving away from your goal.`;
      }
      goalCard = `<div class="card"><h2>Goal</h2>
        <div class="big" style="font-size:1.5rem;font-weight:800">${reached ? "Goal reached 🎉" : `${num(Math.abs(toDisplay("weight", toGoal)), 1)} ${u} to go`}</div>
        <div class="bar ${reached ? "ok" : ""}" style="margin:10px 0 4px"><i style="width:${Math.max(3, pct)}%"></i></div>
        <div class="row spread small muted"><span>Start ${fmtMetric("weight", start)}</span><span>${Math.round(pct)}%</span><span>Goal ${fmtMetric("weight", goal)}</span></div>
        <div class="small" style="margin-top:10px">${paceTxt ? `Recent pace: <b>${paceTxt}</b>` : '<span class="muted">Log a few more weigh-ins over a week or so to see your pace.</span>'}</div>
        ${eta ? `<div class="small" style="margin-top:4px">${eta}</div>` : ""}</div>`;
    }
  }

  view.innerHTML = `
    <div class="page-head"><div><h1>Fitness</h1><p>Body measurements and trends over time.</p></div>
      <div class="row wrap">${fitTabs("body")}<button class="btn" id="logev">+ Log an event</button></div></div>
    <div class="grid tiles">${tiles.join("")}</div>
    <div class="grid cols-2">
      <div class="stack">
        <div class="card"><h2>Log a measurement</h2>
          <form id="add">
            <div class="row" style="gap:10px;align-items:flex-end;flex-wrap:wrap">
              <label class="f" style="flex:0 0 170px"><span>What</span><select name="metric" id="msel">${Object.keys(METRICS).map(m => `<option value="${m}" ${m === k ? "selected" : ""}>${METRICS[m].label}</option>`).join("")}${metrics.filter(m => !METRICS[m]).map(m => `<option value="${m}" ${m === k ? "selected" : ""}>${esc(metricLabel(m))}</option>`).join("")}<option value="__custom">＋ Something else…</option></select></label>
              <label class="f grow" style="min-width:150px"><span id="qlabel"></span><input type="number" step="any" inputmode="decimal" name="value" id="qv" required style="font-size:1.3rem;font-weight:700"></label>
              <button class="btn primary" style="height:46px">Log it</button></div>
            <label class="f full" id="cname" style="display:none;margin-top:10px">Name for the new measurement<input name="custom" placeholder="e.g. Grip strength"></label>
            <div class="row small" style="gap:12px;margin-top:10px;flex-wrap:wrap"><label class="row" style="gap:6px">Date <input type="date" name="date" value="${todayStr()}" required style="width:auto"></label>
              <label class="row grow" style="gap:6px">Note <input name="notes" placeholder="optional" class="grow"></label></div></form></div>
        <div class="card"><div class="row spread wrap" style="margin-bottom:10px"><div class="seg" id="tabs">${metrics.map(m => `<button data-m="${m}" class="${m === k ? "on" : ""}">${esc(metricLabel(m))}</button>`).join("")}<button data-m="__new" title="Track something else">＋</button></div>
          <div class="seg" id="range">${[[30, "30d"], [90, "90d"], [365, "1y"], [0, "All"]].map(([d, l]) => `<button data-d="${d}" class="${d === FitState.range ? "on" : ""}">${l}</button>`).join("")}</div></div>
          <div class="chart-host" id="chart"></div><div id="evleg"></div><div class="small muted" id="stat" style="margin-top:8px"></div></div>
        <div class="card"><h2>Entries — ${esc(metricLabel(k))}</h2><div id="entries"></div></div>
      </div>
      <div class="stack">
        ${goalCard}
        <details class="card prof" ${profileDone ? "" : "open"}><summary><b>About you</b> <span class="muted small">${esc(profLine) || "add your height, birth date and goal"}</span></summary>
          <form id="prof" class="form-grid" style="margin-top:12px">
            <label class="f">Units<select name="units"><option value="imperial" ${imp ? "selected" : ""}>Imperial (lb, in)</option><option value="metric" ${!imp ? "selected" : ""}>Metric (kg, cm)</option></select></label>
            <label class="f">Sex<select name="sex"><option value=""></option>${["male", "female", "other"].map(s => `<option ${profile.sex === s ? "selected" : ""}>${s}</option>`).join("")}</select></label>
            ${imp ? `<label class="f">Height (ft)<input type="number" name="ft" value="${ft}"></label><label class="f">Height (in)<input type="number" step="0.1" name="in" value="${inch}"></label>`
      : `<label class="f full">Height (cm)<input type="number" step="0.1" name="cm" value="${hcm ?? ""}"></label>`}
            <label class="f">Date of birth<input type="date" name="birth_date" value="${profile.birth_date || ""}"></label>
            <label class="f">Goal weight (${metricUnit("weight")})<input type="number" step="0.1" name="goal" value="${goal ? +toDisplay("weight", goal).toFixed(1) : ""}"></label>
            <div class="full"><button class="btn">Save profile</button></div></form></details>
      </div>
    </div>`;

  // chart: the entries, plus a smoothed 7-day average line once there are enough of them
  const inRange = r => !FitState.range || (Date.now() - new Date(r.date + "T12:00")) / 864e5 <= FitState.range;
  const data = mine.filter(inRange), avg = movingAvg(mine).filter(inRange);
  const pt = r => [new Date(r.date + "T12:00").getTime(), toDisplay(k, r.value)];
  const opts = { yFmt: v => num(v, 1), height: 270 };
  if (isW && goal) opts.hLine = { y: toDisplay("weight", goal), label: "goal" };
  const cev = chartEvents(evd.events || [], true);
  if (cev.length) opts.events = cev;
  const series = [{ name: metricLabel(k), color: "var(--accent)", points: data.map(pt) }];
  if (data.length >= 4) series.push({ name: "7-day average", color: "var(--muted)", dashed: true, noDots: true, points: avg.map(pt) });
  Charts.line($("#chart", view), series, opts);
  if (data.length) $("#evleg", view).innerHTML = eventLegend(cev, new Date(data[0].date + "T12:00").getTime(), new Date(data[data.length - 1].date + "T12:00").getTime());
  $("#stat", view).textContent = data.length > 1
    ? `Low ${num(Math.min(...data.map(r => toDisplay(k, r.value))))} ${u} · High ${num(Math.max(...data.map(r => toDisplay(k, r.value))))} ${u} · Average ${num(data.reduce((a, r) => a + toDisplay(k, r.value), 0) / data.length)} ${u} · ${data.length} entries${paceTxt ? " · Pace " + paceTxt : ""}${series.length > 1 ? " · dashed line = 7-day average" : ""}`
    : data.length === 1 ? "That's your first entry. Log another one to start seeing a trend." : "";
  const all = mine.slice().reverse().slice(0, 15);
  $("#entries", view).innerHTML = all.length ? `<table><tbody>${all.map(r => `<tr><td>${fmtDate(r.date, true)}</td><td><b>${fmtMetric(k, r.value)}</b></td><td class="muted">${esc(r.notes || "")}</td><td class="r"><button class="btn ghost sm" data-del="${r.id}">✕</button></td></tr>`).join("")}</tbody></table>` : '<div class="empty">No entries yet.</div>';

  wireFitTabs(view);
  $("#logev", view).onclick = () => eventModal(null, () => Router.render());
  const msel = $("#msel", view), qv = $("#qv", view);
  const syncQuick = () => {                                         // label the number box with the unit, hint the last value
    const m = msel.value, last = (byMetric[m] || []).slice(-1)[0];
    $("#qlabel", view).textContent = m === "__custom" ? "Value" : `${metricLabel(m)}${metricUnit(m) ? " (" + metricUnit(m) + ")" : ""}`;
    qv.placeholder = last ? `last: ${num(toDisplay(m, last.value), 1)}` : "";
    $("#cname", view).style.display = m === "__custom" ? "" : "none";
  };
  msel.onchange = syncQuick; syncQuick();
  $$("#tabs button", view).forEach(b => b.onclick = () => {
    if (b.dataset.m === "__new") { msel.value = "__custom"; syncQuick(); $("#cname input", view).focus(); return; }
    FitState.metric = b.dataset.m; Router.render();
  });
  $$("#range button", view).forEach(b => b.onclick = () => { FitState.range = +b.dataset.d; Router.render(); });
  $$("[data-del]", view).forEach(b => b.onclick = async () => { await api("/metrics/" + b.dataset.del, "DELETE"); Router.render(); });
  $("#add", view).onsubmit = async e => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    let metric = f.metric;
    if (metric === "__custom") { metric = (f.custom || "").trim().toLowerCase().replace(/\s+/g, "_"); if (!metric) return toast("Name your measurement", true); }
    await run($(".primary", e.target), async () => {
      await api("/metrics", "POST", { date: f.date, metric, value: fromDisplay(metric, +f.value), notes: f.notes });
      FitState.metric = metric; toast("Logged ✓"); Router.render();
    });
  };
  $("#prof", view).onsubmit = async e => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    const units = f.units, wasImp = imp;
    const body = { units, sex: f.sex || null, birth_date: f.birth_date || null };
    if (f.ft !== undefined) body.height_cm = (f.ft || f.in) ? ((+f.ft || 0) * 12 + (+f.in || 0)) * 2.54 : null;
    else body.height_cm = f.cm ? +f.cm : null;
    // goal is typed in the unit shown on screen (the form's previous units)
    body.goal_weight_kg = f.goal ? (wasImp ? +f.goal / KG_LB : +f.goal) : null;
    await run($(".btn", e.target), async () => { await api("/profile", "PUT", body); toast("Profile saved"); Router.render(); });
  };
};
