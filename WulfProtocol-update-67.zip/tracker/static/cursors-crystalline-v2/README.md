# WulfProtocol Crystalline Cursor Kit

All 10 designs are isolated from the exact approved reference image, retaining the original cyan facets, purple wolf head, and bone shapes. This is **reference-preserving raster extraction and alpha reconstruction**, not ten newly painted layered masters. No simplified substitute designs were used.

Includes 512px transparent PNG masters, 32/48/64/128px PNGs, 32/48/64px Windows CURs, manifest, CSS, preview, and HTML test page.

Important: Browser cursor behavior differs by browser and OS. Test 100%, 125%, 150% display scaling and small clickable icons. Hotspots at (2,2) for paw/wolf states prioritize clear targets, not paw-toe precision. Native textarea resize handles can override CSS. Click/loading are static states, not animated. At 32px fine crystalline details are necessarily limited by source resolution.

The 512px files are resampled from the original ~200px artwork and do not contain genuine 512px optical detail. For true independently rendered, editable masters, professional manual redrawing from the original concept remains necessary.
