# WulfProtocol Solid-Pixel Alignment Verification

Source: `WulfProtocol_Cursor_Pixel_Cleanup.zip`

Solid means alpha >= 64. Shifted only the 18 paw/Help PNGs, without scaling, rotation, resampling, sharpening, or recoloring. Pixels outside the new canvas were discarded only when alpha <64. The other 12 PNGs and CURs are byte-identical to the source.

## Results
- Images shifted: 18
- Dropped pixels: 748
- Maximum alpha among dropped pixels: PASS
- Retained pixels with modified RGBA values after accounting for translation: 0
- CUR binary headers verified: 30 / 30
- Failures: none

The first solid row and first solid column are 0 for every shifted image. These are independent extrema, not necessarily one solid pixel at the exact (0,0) coordinate.

## Per-image results

| PNG | dx | dy | First solid x | First solid y | Dropped | Max dropped alpha | Retained pixel mismatches |
|---|---:|---:|---:|---:|---:|---:|---:|
| `default/default_32.png` | -2 | -3 | 0 | 0 | 21 | 4 | 0 |
| `default/default_48.png` | -3 | -2 | 0 | 0 | 34 | 8 | 0 |
| `default/default_64.png` | -2 | -2 | 0 | 0 | 26 | 3 | 0 |
| `hover/hover_32.png` | -2 | -3 | 0 | 0 | 34 | 3 | 0 |
| `hover/hover_48.png` | -3 | -2 | 0 | 0 | 50 | 40 | 0 |
| `hover/hover_64.png` | -2 | -2 | 0 | 0 | 45 | 4 | 0 |
| `click/click_32.png` | -3 | -2 | 0 | 0 | 45 | 6 | 0 |
| `click/click_48.png` | -2 | -3 | 0 | 0 | 60 | 8 | 0 |
| `click/click_64.png` | -2 | -2 | 0 | 0 | 58 | 3 | 0 |
| `disabled/disabled_32.png` | -3 | -2 | 0 | 0 | 20 | 8 | 0 |
| `disabled/disabled_48.png` | -3 | -2 | 0 | 0 | 25 | 4 | 0 |
| `disabled/disabled_64.png` | -3 | -2 | 0 | 0 | 18 | 2 | 0 |
| `loading/loading_32.png` | -2 | -2 | 0 | 0 | 26 | 4 | 0 |
| `loading/loading_48.png` | -3 | -3 | 0 | 0 | 47 | 11 | 0 |
| `loading/loading_64.png` | -2 | -3 | 0 | 0 | 46 | 60 | 0 |
| `help/help_32.png` | -3 | -3 | 0 | 0 | 60 | 8 | 0 |
| `help/help_48.png` | -3 | -3 | 0 | 0 | 67 | 17 | 0 |
| `help/help_64.png` | -3 | -2 | 0 | 0 | 66 | 24 | 0 |

## Audit
`DROPPED_PIXELS.csv` lists every discarded pixel with original coordinates and RGBA. `SOLID_ALIGNMENT_REPORT.csv` gives per-image shifts, solid boundaries and mismatch counts. `HOTSPOT_VERIFICATION.csv` records the binary-read dimensions and hotspots of all 30 `.cur` files.

Earlier pixel-change CSV reports were removed from this package because they describe the previous version, not this alignment.