"""Administration types, site-rotation suggestions and vial/bottle expiry."""
import json
import re
from datetime import date, timedelta

SUBQ_SITES = ["Abdomen L", "Abdomen R", "Thigh L", "Thigh R", "Flank L", "Flank R", "Arm (back) L", "Arm (back) R"]
IM_SITES = ["Glute L", "Glute R", "Quad L", "Quad R", "Deltoid L", "Deltoid R"]
TOPICAL_SITES = ["Upper arm L", "Upper arm R", "Abdomen L", "Abdomen R", "Thigh L", "Thigh R"]

ROUTES = {
    "subq": {"label": "Injection – subcutaneous (subQ)", "short": "subQ", "icon": "💉", "unit": "mcg", "sites": SUBQ_SITES, "expiry": True, "vial": True},
    "im": {"label": "Injection – intramuscular (IM)", "short": "IM", "icon": "💉", "unit": "mg", "sites": IM_SITES, "expiry": True, "vial": True},
    "nasal": {"label": "Nasal spray", "short": "intranasal", "icon": "👃", "unit": "sprays", "sites": ["Left nostril", "Right nostril"], "expiry": True, "vial": False},
    "oral_tablet": {"label": "Oral – tablet / capsule", "short": "oral", "icon": "💊", "unit": "tablet", "sites": [], "expiry": False, "vial": False},
    "oral_liquid": {"label": "Oral – liquid", "short": "oral liquid", "icon": "🧪", "unit": "mL", "sites": [], "expiry": True, "vial": False},
    "sublingual": {"label": "Sublingual (under the tongue)", "short": "sublingual", "icon": "👅", "unit": "mg", "sites": [], "expiry": True, "vial": False},
    "topical": {"label": "Topical / transdermal", "short": "topical", "icon": "🩹", "unit": "mg", "sites": TOPICAL_SITES, "expiry": True, "vial": False},
    "other": {"label": "Other", "short": "", "icon": "💠", "unit": "mg", "sites": [], "expiry": True, "vial": False},
}


def infer_route(text):
    """Guess the type from older free-text routes like 'subQ' or 'oral'."""
    t = (text or "").lower()
    if re.search(r"sub-?q|subcut|\bsc\b", t): return "subq"
    if re.search(r"\bim\b|intramus", t): return "im"
    if "nasal" in t: return "nasal"
    if re.search(r"sublingual|under the tongue|\bsl\b", t): return "sublingual"
    if re.search(r"topical|transdermal|cream|gel|patch", t): return "topical"
    if "liquid" in t: return "oral_liquid"
    if re.search(r"oral|tablet|capsule|pill|\bpo\b", t): return "oral_tablet"
    return "other"


def enabled_sites(med):
    rt = med.get("route_type") or infer_route(med.get("route"))
    defaults = ROUTES.get(rt, ROUTES["other"])["sites"]
    if not defaults:
        return []
    raw = med.get("sites")
    if raw:
        try:
            s = json.loads(raw) if isinstance(raw, str) else raw
            if isinstance(s, list) and s:
                return [str(x) for x in s]
        except Exception:
            pass
    return list(defaults)


def site_info(med, logs):
    """logs: taken doses that have a site, newest first. Suggests the least-recently-used enabled site."""
    enabled = enabled_sites(med)
    if not enabled:
        return None
    last, count = {}, {}
    for l in logs:
        last.setdefault(l["site"], l["taken_at"])
        count[l["site"]] = count.get(l["site"], 0) + 1
    rows = [{"site": s, "last": last.get(s), "count": count.get(s, 0)} for s in enabled]
    order = sorted(range(len(rows)), key=lambda i: (rows[i]["last"] is not None, rows[i]["last"] or "", i))
    return {"sites": rows, "suggest": rows[order[0]]["site"],
            "last_site": logs[0]["site"] if logs else None, "last_at": logs[0]["taken_at"] if logs else None}


def expiry_info(med, today=None):
    today = today or date.today()
    if not med.get("opened_on") or not med.get("use_within_days"):
        return None
    opened = date.fromisoformat(med["opened_on"])
    exp = opened + timedelta(days=int(med["use_within_days"]))
    left = (exp - today).days
    return {"opened_on": med["opened_on"], "expires_on": exp.isoformat(), "days_left": left, "low": left <= 3}
