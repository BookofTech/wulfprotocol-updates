"""SQLite storage. Everything lives in ./data/tracker.db (override with TRACKER_DATA)."""
import json
import os
import sqlite3
from pathlib import Path

DATA_DIR = Path(os.environ.get("TRACKER_DATA", Path(__file__).parent / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "tracker.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS meds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  kind TEXT DEFAULT 'peptide',          -- peptide | medication | supplement | other
  dose REAL,                            -- amount per dose
  dose_unit TEXT DEFAULT 'mg',
  route TEXT,                           -- e.g. subQ, oral, IM
  schedule TEXT NOT NULL DEFAULT '{"type":"daily","times":["08:00"]}',
  start_date TEXT NOT NULL,
  end_date TEXT,
  cycle_on INTEGER DEFAULT 0,           -- days on  (0 = no cycling)
  cycle_off INTEGER DEFAULT 0,          -- days off
  stock_qty REAL,                       -- remaining, in dose_unit (NULL = not tracked)
  refill_lead_days INTEGER DEFAULT 7,
  color TEXT,
  notes TEXT,
  active INTEGER DEFAULT 1,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS dose_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  med_id INTEGER NOT NULL REFERENCES meds(id) ON DELETE CASCADE,
  slot TEXT,                            -- scheduled datetime this log answers (NULL = extra/as-needed)
  status TEXT NOT NULL DEFAULT 'taken', -- taken | skipped
  taken_at TEXT NOT NULL,
  amount REAL,
  site TEXT,                            -- injection site etc.
  notes TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_log_slot ON dose_logs(med_id, slot) WHERE slot IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_log_taken ON dose_logs(taken_at);

CREATE TABLE IF NOT EXISTS profile (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  height_cm REAL, birth_date TEXT, sex TEXT, goal_weight_kg REAL, units TEXT DEFAULT 'imperial'
);
INSERT OR IGNORE INTO profile(id) VALUES (1);
CREATE TABLE IF NOT EXISTS metrics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL, metric TEXT NOT NULL, value REAL NOT NULL, notes TEXT
);
CREATE INDEX IF NOT EXISTS ix_metrics ON metrics(metric, date);

CREATE TABLE IF NOT EXISTS items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, image TEXT, category TEXT, target_price REAL, notes TEXT,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  url TEXT NOT NULL, site TEXT, selector TEXT,
  needs_login INTEGER DEFAULT 0,
  currency TEXT, last_price REAL, in_stock INTEGER,
  last_checked TEXT, last_error TEXT,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS price_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
  ts TEXT NOT NULL, price REAL NOT NULL, in_stock INTEGER
);
CREATE INDEX IF NOT EXISTS ix_ph ON price_history(source_id, ts);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS stock_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
  item_id INTEGER NOT NULL, ts TEXT NOT NULL,
  kind TEXT NOT NULL,                         -- back_in_stock | out_of_stock
  price REAL, seen INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_stock ON stock_events(seen, ts);

CREATE TABLE IF NOT EXISTS inventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, category TEXT DEFAULT 'Supplies',
  qty REAL DEFAULT 0, unit TEXT DEFAULT 'pcs',
  size TEXT,                            -- e.g. "5 mg" per vial, "30 mL" per bottle
  low_at REAL,                          -- warn when quantity drops to this or below
  expiry_date TEXT, lot TEXT, location TEXT, notes TEXT,
  med_id INTEGER REFERENCES meds(id) ON DELETE SET NULL,          -- linked medication
  per_dose REAL,                        -- supplies used automatically each time a dose of the linked med is logged
  price_item_id INTEGER REFERENCES items(id) ON DELETE SET NULL,  -- linked Price watch item (for reorders)
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS inventory_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  inv_id INTEGER NOT NULL REFERENCES inventory(id) ON DELETE CASCADE,
  ts TEXT NOT NULL, change REAL NOT NULL, qty_after REAL NOT NULL, reason TEXT, note TEXT
);
CREATE INDEX IF NOT EXISTS ix_invlog ON inventory_log(inv_id, ts);
CREATE TABLE IF NOT EXISTS orders (          -- things you ordered from a store (nothing is bought from this app; this is your own record)
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, site TEXT, url TEXT,
  price_item_id INTEGER REFERENCES items(id) ON DELETE SET NULL,
  inv_id INTEGER REFERENCES inventory(id) ON DELETE SET NULL,   -- stock item it will be added to (chosen automatically via the reorder link, or when received)
  qty REAL NOT NULL, qty_received REAL DEFAULT 0,
  unit_price REAL, currency TEXT,
  ordered_on TEXT NOT NULL, expected_by TEXT, received_on TEXT,
  status TEXT NOT NULL DEFAULT 'open',                          -- open | received | cancelled
  notes TEXT
);
CREATE INDEX IF NOT EXISTS ix_orders ON orders(status, ordered_on);

CREATE TABLE IF NOT EXISTS med_supplies (       -- supplies used up each time a dose of a medication is logged (needles, swabs...)
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  med_id INTEGER NOT NULL REFERENCES meds(id) ON DELETE CASCADE,
  inv_id INTEGER NOT NULL REFERENCES inventory(id) ON DELETE CASCADE,
  per_dose REAL NOT NULL DEFAULT 1,
  UNIQUE(med_id, inv_id)
);
CREATE TABLE IF NOT EXISTS library (            -- saved reference items for "Quick add" on the Medication page
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  data TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS store_shipping (      -- shipping rules per store: flat fee and the order size that makes it free
  site TEXT PRIMARY KEY, fee REAL, free_over REAL, manual INTEGER DEFAULT 0, seen TEXT
);
CREATE TABLE IF NOT EXISTS biomarkers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, unit TEXT, category TEXT DEFAULT 'Other',
  ref_low REAL, ref_high REAL,          -- reference range (editable; use the range printed on your lab report)
  retest_days INTEGER,                  -- remind me to retest every N days (NULL = no reminder)
  notes TEXT,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS lab_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  biomarker_id INTEGER NOT NULL REFERENCES biomarkers(id) ON DELETE CASCADE,
  date TEXT NOT NULL, value REAL NOT NULL, lab TEXT, notes TEXT
);
CREATE INDEX IF NOT EXISTS ix_lab ON lab_results(biomarker_id, date);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL, end_date TEXT,
  type TEXT DEFAULT 'other', title TEXT NOT NULL, notes TEXT, med_id INTEGER
);
CREATE INDEX IF NOT EXISTS ix_events ON events(date);
"""

DEFAULT_SETTINGS = {
    "grace_minutes": "180",      # how late a dose can be before it counts as missed
    "check_hours": "6",          # how often to re-check prices
    "auto_check": "1",
    "setup_done": "0",
    "use_meds": "1",
    "use_fitness": "1",
    "use_prices": "0",           # live price tracking is opt-in
    "weigh_reminder_days": "7",  # remind me to weigh in after this many days (0 = off)
    "use_calc": "1",             # show the Calculator tab
    "user_name": "",             # how the greeting addresses you
    "browser_pref": "auto",      # which browser sign-in windows use: auto (system default) | chrome | edge
    "auto_update_check": "1",    # look for a newer version when the app opens (never installs by itself)
    "lab_spike_pct": "25",       # flag a lab result that moved by at least this % since the previous one
}


def conn():
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


MIGRATIONS = [("meds", "route_type", "TEXT"), ("meds", "sites", "TEXT"), ("meds", "opened_on", "TEXT"),
              ("meds", "use_within_days", "INTEGER"), ("meds", "vial_amount", "REAL"),
              ("meds", "vial_unit", "TEXT"), ("meds", "diluent_ml", "REAL"), ("meds", "container", "TEXT"), ("meds", "reference", "TEXT"),
              ("meds", "phases", "TEXT"), ("meds", "phase_start", "TEXT"), ("dose_logs", "effects", "TEXT"),
              ("sources", "promo", "TEXT"), ("sources", "promo_note", "TEXT"), ("sources", "pre_clicks", "TEXT"), ("sources", "hist_from", "TEXT"), ("price_history", "promo", "TEXT"), ("items", "ref_name", "TEXT"), ("items", "size", "TEXT"), ("meds", "click_amt", "REAL")]


LIBRARY_VERSION = 3            # bump when library_seed.json changes; existing installs get the changes merged in once
_LIB_FIELDS = ["groups", "names", "indications", "reconstitute", "storage", "dosage", "onset", "half_life", "side_effects", "notes"]


def _lib_hash(d):
    import hashlib
    return hashlib.sha1(json.dumps([d.get("name", "")] + [d.get(k, "") for k in _LIB_FIELDS], ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def _lib_load(name):
    try:
        return json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), name), encoding="utf-8"))
    except Exception:
        return None


def _library_sync(c):
    """Load the starter reference list on first run, and merge newer versions of it later.
    Items you edited yourself are never overwritten, and ones you deleted stay deleted."""
    seed = _lib_load("library_seed.json")
    if seed is None:
        return
    row = c.execute("SELECT value FROM settings WHERE key='library_seeded'").fetchone()
    ver = c.execute("SELECT value FROM settings WHERE key='library_version'").fetchone()
    cur_ver = int(ver[0]) if ver else (1 if row else 0)
    if cur_ver >= LIBRARY_VERSION:
        return
    if cur_ver == 0:                                            # brand-new database
        for it in seed:
            c.execute("INSERT INTO library(name,data) VALUES (?,?)", (it["name"], json.dumps(it, ensure_ascii=False)))
    else:                                                       # upgrade from an older list
        v1 = _lib_load("library_v1_hashes.json") or {}
        v2 = _lib_load("library_v2_hashes.json") or {}
        old = {}                                                # name -> every untouched version of that entry we ever shipped
        for hs in (v1, v2):
            for n, h in hs.items():
                old.setdefault(n, set()).add(h)
        was = v1 if cur_ver <= 1 else v2                        # what this copy was sent with: names missing from its list were deleted on purpose
        rows = {r[1].lower(): (r[0], r[2]) for r in c.execute("SELECT id,name,data FROM library")}
        new_names = {it["name"].lower() for it in seed}
        for it in seed:
            hit = rows.get(it["name"].lower())
            if hit:
                try:
                    have = json.loads(hit[1])
                except Exception:
                    have = {}
                have["name"] = it["name"]
                if _lib_hash(have) in old.get(it["name"], ()):  # you never edited it: take the new wording
                    c.execute("UPDATE library SET data=? WHERE id=?", (json.dumps(it, ensure_ascii=False), hit[0]))
            elif it["name"] not in was:                         # new in this version (and not something you deleted)
                c.execute("INSERT INTO library(name,data) VALUES (?,?)", (it["name"], json.dumps(it, ensure_ascii=False)))
        for name, hs in old.items():                            # dropped from the list: remove only if you never edited it
            if name.lower() not in new_names and name.lower() in rows and name in was:
                rid, data = rows[name.lower()]
                try:
                    have = json.loads(data)
                except Exception:
                    continue
                have["name"] = name
                if _lib_hash(have) in hs:
                    c.execute("DELETE FROM library WHERE id=?", (rid,))
    c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES ('library_seeded','1')")
    c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES ('library_version',?)", (str(LIBRARY_VERSION),))


def init():
    with conn() as c:
        c.executescript(SCHEMA)
        for table, col, typ in MIGRATIONS:          # add new columns to databases created by older versions
            if col not in {r[1] for r in c.execute(f"PRAGMA table_info({table})")}:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
        # older versions stored "used per dose" on the inventory item itself: move those links to the new table (once)
        c.execute("""INSERT OR IGNORE INTO med_supplies(med_id,inv_id,per_dose)
                     SELECT med_id,id,per_dose FROM inventory WHERE med_id IS NOT NULL AND per_dose>0""")
        c.execute("UPDATE inventory SET per_dose=NULL WHERE per_dose>0 AND med_id IS NOT NULL")
        for k, v in DEFAULT_SETTINGS.items():
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)", (k, v))
        _library_sync(c)


def q(sql, args=(), one=False):
    with conn() as c:
        rows = [dict(r) for r in c.execute(sql, args).fetchall()]
    return (rows[0] if rows else None) if one else rows


def x(sql, args=()):
    """Execute a write; returns lastrowid."""
    with conn() as c:
        cur = c.execute(sql, args)
        return cur.lastrowid


def get_settings():
    s = {r["key"]: r["value"] for r in q("SELECT key,value FROM settings")}
    return {
        "grace_minutes": int(s.get("grace_minutes", 180)),
        "check_hours": float(s.get("check_hours", 6)),
        "auto_check": s.get("auto_check", "1") == "1",
        "setup_done": s.get("setup_done", "0") == "1",
        "use_meds": s.get("use_meds", "1") == "1",
        "use_fitness": s.get("use_fitness", "1") == "1",
        "use_prices": s.get("use_prices", "0") == "1",
        "use_calc": s.get("use_calc", "1") == "1",
        "auto_update_check": s.get("auto_update_check", "1") == "1",
        "weigh_reminder_days": int(float(s.get("weigh_reminder_days", 7))),
        "user_name": s.get("user_name", ""),
        "lab_spike_pct": float(s.get("lab_spike_pct", 25)),
        "browser_pref": s.get("browser_pref", "auto"),
    }


def set_settings(d):
    with conn() as c:
        for k, v in d.items():
            if k in DEFAULT_SETTINGS:
                if isinstance(v, bool):
                    v = "1" if v else "0"
                c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)", (k, str(v)))


SITES_FILE = "my-price-sites.csv"


def export_sites():
    """Keeps a plain spreadsheet-friendly list of every tracked item and store in the data folder (opens in Excel).
    Rewritten after every add / edit / delete. The first columns match the Bulk add / import template, so the file can be loaded back in."""
    import csv
    try:
        rows = q("""SELECT i.name, i.ref_name, i.size, s.url, i.category, i.target_price, s.needs_login, s.site, s.last_price, s.currency, s.in_stock,
                           COALESCE(NULLIF(s.promo_note,''), s.promo) AS sale, s.last_checked, i.notes
                    FROM items i LEFT JOIN sources s ON s.item_id=i.id ORDER BY i.name COLLATE NOCASE, s.id""")
        tmp = DATA_DIR / (SITES_FILE + ".tmp")
        with open(tmp, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["name", "url", "category", "target_price", "needs_login", "store", "last_price", "currency",
                        "in_stock", "sale_note", "last_checked", "item_notes", "reference_name", "size"])
            for r in rows:
                w.writerow([r["name"], r["url"] or "", r["category"] or "", "" if r["target_price"] is None else r["target_price"],
                            "yes" if r["needs_login"] else "", r["site"] or "", "" if r["last_price"] is None else r["last_price"],
                            r["currency"] or "", {1: "yes", 0: "no"}.get(r["in_stock"], ""), r["sale"] or "",
                            (r["last_checked"] or "").replace("T", " "), r["notes"] or "", r["ref_name"] or "", r["size"] or ""])
        os.replace(tmp, DATA_DIR / SITES_FILE)        # fails harmlessly while the file is open in Excel; the next change retries
    except Exception:
        pass
