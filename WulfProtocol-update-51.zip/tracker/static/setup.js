/* First-run setup wizard + shared helpers for feature switches / optional sign-in mode */
const feat = () => ({ meds: App.settings ? App.settings.use_meds : true, fitness: App.settings ? App.settings.use_fitness : true, prices: App.settings ? App.settings.use_prices : false, calculator: App.settings ? App.settings.use_calc : true });

/* "Install sign-in mode" widget (used in the wizard and in Settings) */
async function browserBox(host) {
  const draw = async () => {
    if (!document.body.contains(host)) return;
    let s; try { s = await api("/install-browser"); } catch (e) { return; }
    if (s.ready) { host.innerHTML = `<span class="badge ok">✓ Sign-in mode is ready</span> <span class="small muted">— sign-in windows open in ${esc(s.browser.using_name)}</span>
      <div style="margin-top:10px"><button class="btn sm" id="bw">🔐 Add Bitwarden to the sign-in window</button>
      <div class="small muted" style="margin-top:4px">Opens the sign-in window on Bitwarden's page in the ${esc(s.browser.using_name)} store. Press <b>Add</b>, sign in to Bitwarden once, and from then on it can fill in each store's login. Your passwords stay in Bitwarden. This app never sees them.</div></div>`;
      const bw = $("#bw", host); if (bw) bw.onclick = () => run(bw, async () => { await api("/bitwarden/install", "POST"); toast("A window opened on Bitwarden's page. Add it, sign in to Bitwarden, then close the window."); }); if (App.settings) App.settings.playwright = true; return; }
    if (s.state === "running") {
      host.innerHTML = '<span class="badge warn">Installing… this can take a few minutes. Keep this window open.</span>';
      return setTimeout(draw, 2500);
    }
    const own = s.browser && s.browser.using !== "bundled";
    host.innerHTML = `<button class="btn" id="inst">${own ? "⬇ Turn on sign-in mode" : "⬇ Install sign-in mode"} <span class="muted small">${own ? `(uses your ${esc(s.browser.using_name)}, only a small add-on is needed)` : "(~150 MB, one time)"}</span></button>
      ${s.state === "error" ? `<div class="alert bad" style="margin-top:8px">${esc(s.log)}</div>` : ""}`;
    $("#inst", host).onclick = async () => { await run(null, () => api("/install-browser", "POST")); draw(); };
  };
  draw();
}

async function refreshSettings() { App.settings = await api("/settings"); applyNav(); }
function applyNav() {
  const f = feat();
  $$("nav a[data-r]").forEach(a => { const k = a.dataset.r; if (k in f) a.style.display = f[k] ? "" : "none"; });
}

const Wizard = {
  W: null, i: 0,
  start() {
    const s = App.settings || {};
    this.W = {
      use_meds: s.setup_done ? s.use_meds : true, use_fitness: s.setup_done ? s.use_fitness : true, use_prices: s.setup_done ? s.use_prices : false, use_calc: s.setup_done ? s.use_calc : true, name: s.user_name || "",
      units: (App.profile && App.profile.units) || "imperial", grace: s.grace_minutes || 180, check_hours: s.check_hours || 6, login: "no",
    };
    this.i = 0;
    let root = $("#wizard");
    if (!root) { root = document.createElement("div"); root.id = "wizard"; root.className = "wizard"; document.body.appendChild(root); }
    this.draw();
  },
  steps() { const W = this.W, s = ["name", "features"]; if (W.use_meds) s.push("meds"); s.push("about"); if (W.use_prices) s.push("prices"); s.push("done"); return s; },
  collect() {                    // read the current step's inputs into W
    const root = $("#wizard"), step = this.steps()[this.i], W = this.W;
    if (step === "name") W.name = $("[name=uname]", root).value.trim();
    if (step === "features") { W.use_calc = $("[name=use_calc]", root).checked; W.use_meds = $("[name=use_meds]", root).checked; W.use_fitness = $("[name=use_fitness]", root).checked; W.use_prices = $("[name=use_prices]", root).checked; }
    if (step === "meds") W.grace = +$("[name=grace]:checked", root).value;
    if (step === "about") W.units = $("[name=units]:checked", root).value;
    if (step === "prices") { W.check_hours = +$("[name=hours]", root).value; W.login = $("[name=login]:checked", root).value; }
  },
  next() {
    this.collect();
    if (this.steps()[this.i] === "features" && !(this.W.use_meds || this.W.use_fitness || this.W.use_prices)) return toast("Pick at least one thing to use", true);
    this.i++; this.draw();
  },
  back() { this.collect(); this.i = Math.max(0, this.i - 1); this.draw(); },
  radio(name, val, cur, title, sub) {
    return `<label class="opt"><input type="radio" name="${name}" value="${val}" ${String(val) === String(cur) ? "checked" : ""}><span><b>${title}</b>${sub ? `<small>${sub}</small>` : ""}</span></label>`;
  },
  draw() {
    const root = $("#wizard"), steps = this.steps(), step = steps[this.i], W = this.W;
    let body = "";
    if (step === "name") body = `
      <h2>What should we call you?</h2><p class="muted">Your name shows in the greeting on the dashboard. You can change it any time in Settings, or leave it blank.</p>
      <div class="form-grid" style="margin:14px 0"><label class="f full">Your name or nickname<input name="uname" value="${esc(W.name || "")}" placeholder="e.g. Ken" autocomplete="off" maxlength="40"></label></div>`;
    if (step === "features") body = `
      <h2>What would you like to use WulfProtocol for?</h2><p class="muted">Pick what's useful — anything you leave off stays hidden and won't run. You can change this any time in Settings.</p>
      <div class="opts">
        <label class="opt big"><input type="checkbox" name="use_meds" ${W.use_meds ? "checked" : ""}><span><b>💉 Peptides &amp; medications</b><small>Dose schedules, cycles, missed-dose alerts and refill reminders</small></span></label>
        <label class="opt big"><input type="checkbox" name="use_fitness" ${W.use_fitness ? "checked" : ""}><span><b>⚖️ Fitness tracking</b><small>Weight, body measurements, BMI and progress charts</small></span></label>
        <label class="opt big"><input type="checkbox" name="use_calc" ${W.use_calc ? "checked" : ""}><span><b>🧮 Calculator</b><small>Dose and draw-amount calculator</small></span></label>
        <label class="opt big"><input type="checkbox" name="use_prices" ${W.use_prices ? "checked" : ""}><span><b>🏷️ Live price tracking</b><small>Watch prices across websites. Uses a web scraper, so only turn it on if you want it.</small></span></label>
      </div>`;
    if (step === "meds") body = `
      <h2>How strict should missed-dose alerts be?</h2><p class="muted">A dose is flagged as <b>missed</b> if it hasn't been logged this long after its scheduled time.</p>
      <div class="opts">${[[60, "1 hour", "Strict — for time-sensitive doses"], [180, "3 hours", "Balanced (recommended)"], [360, "6 hours", "Relaxed"], [720, "12 hours", "Very relaxed — once-daily doses with a flexible window"]]
        .map(([v, t, s]) => this.radio("grace", v, W.grace, t, s)).join("")}</div>`;
    if (step === "about") body = `
      <h2>Which units do you prefer?</h2><p class="muted">Used for weight, height and body measurements. You can switch later.</p>
      <div class="opts">${this.radio("units", "imperial", W.units, "Imperial", "lb, inches, feet")}${this.radio("units", "metric", W.units, "Metric", "kg, centimeters")}</div>`;
    if (step === "prices") body = `
      <h2>Price tracking setup</h2>
      <div class="form-grid" style="margin:14px 0">
        <label class="f">How often should prices be re-checked?<select name="hours">${[[3, "Every 3 hours"], [6, "Every 6 hours"], [12, "Every 12 hours"], [24, "Once a day"]].map(([v, t]) => `<option value="${v}" ${+W.check_hours === v ? "selected" : ""}>${t}</option>`).join("")}</select></label></div>
      <p class="muted" style="margin-bottom:8px">Will you track stores where you have to <b>be logged in</b> to see prices?</p>
      <div class="opts">${this.radio("login", "yes", W.login, "Yes, some of them", "You'll log in yourself in a browser window; the app never stores your password")}
        ${this.radio("login", "no", W.login, "No, or not sure yet", "You can enable this later in Settings")}</div>`;
    if (step === "done") {
      const on = [W.use_meds && "Peptides & meds", W.use_fitness && "Fitness", W.use_prices && "Price tracking"].filter(Boolean);
      body = `<h2>You're all set 🐺</h2><p class="muted">Turned on: <b>${on.join(" · ")}</b>.</p>
        ${W.use_prices && W.login === "yes" ? `<div class="card" style="margin:14px 0"><h3 style="margin-bottom:6px">Sign-in mode for protected stores</h3>
          <p class="muted small" style="margin-top:0">Needed so the app can open a real browser window for you to log in. You can skip this and do it later from Settings.</p><div id="wbox"></div></div>` : ""}
        <p class="muted small">Next: ${W.use_meds ? "add your first medication on the <b>Medication</b> tab" : W.use_fitness ? "log your first weight on the <b>Fitness</b> tab" : "paste a product link on the <b>Prices</b> tab"}.</p>`;
    }
    const last = this.i === steps.length - 1;
    root.innerHTML = `<div class="wiz card">
      <div class="row" style="margin-bottom:18px"><span class="logo" style="width:44px"></span><div><b class="wm">Wulf<em>Protocol</em></b><div class="small muted">Track. Optimize. Evolve.</div></div>
        <div class="dots">${steps.map((_, k) => `<i class="${k === this.i ? "on" : k < this.i ? "past" : ""}"></i>`).join("")}</div></div>
      ${this.i === 0 ? "<p class='small muted' style='margin:0 0 4px;font-weight:700;letter-spacing:.08em'>WELCOME — LET'S SET THINGS UP</p>" : ""}
      ${body}
      <div class="actions" style="margin-top:22px;justify-content:space-between">
        ${this.i ? '<button class="btn" id="wb">← Back</button>' : "<span></span>"}
        <button class="btn primary" id="wn">${last ? "Finish &amp; open dashboard" : "Continue →"}</button></div></div>`;
    if (this.i) $("#wb", root).onclick = () => this.back();
    $("#wn", root).onclick = e => last ? this.finish(e.target) : this.next();
    const bb = $("#wbox", root); if (bb) browserBox(bb);
  },
  async finish(btn) {
    const W = this.W;
    await run(btn, async () => {
      await api("/settings", "PUT", { use_meds: W.use_meds, use_fitness: W.use_fitness, use_prices: W.use_prices, use_calc: W.use_calc, user_name: W.name || "", grace_minutes: W.grace,
        check_hours: W.check_hours, auto_check: W.use_prices, setup_done: true });
      await api("/profile", "PUT", { units: W.units });
      App.profile = await api("/profile"); await refreshSettings();
      $("#wizard").remove();
      location.hash = "#/dashboard"; Router.render();
    });
  },
};
