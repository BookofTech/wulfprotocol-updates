#!/usr/bin/env bash
# Mac: double-click to launch WulfProtocol (first run sets itself up).
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt || { echo "Setup failed"; exit 1; }
fi
.venv/bin/python launcher.py
