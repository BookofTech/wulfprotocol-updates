"""Dose scheduling, cycle phases and refill forecasting. All times are local, naive datetimes."""
import json
from datetime import date, datetime, time, timedelta


def sched(med):
    try:
        s = json.loads(med["schedule"]) if isinstance(med["schedule"], str) else med["schedule"]
    except Exception:
        s = {}
    s.setdefault("type", "daily")
    s.setdefault("times", ["08:00"])
    return s


def _d(s):
    return date.fromisoformat(s) if s else None


def cycle_enabled(med):
    return (med.get("cycle_on") or 0) > 0 and (med.get("cycle_off") or 0) > 0


def is_dose_day(med, d):
    start, end = _d(med["start_date"]), _d(med.get("end_date"))
    if d < start or (end and d > end):
        return False
    if cycle_enabled(med):
        on, off = med["cycle_on"], med["cycle_off"]
        if (d - start).days % (on + off) >= on:
            return False
    s = sched(med)
    t = s["type"]
    if t == "daily":
        return True
    if t == "interval":
        return (d - start).days % max(1, int(s.get("every", 1))) == 0
    if t == "weekdays":
        return d.weekday() in s.get("days", [])
    return False  # prn / as-needed


def norm_steps(steps):
    """Dose steps are counted in days of the plan (day 1 = first day). Older plans were saved in weeks: week N = days 7N-6 .. 7N."""
    out = []
    for x in steps or []:
        y = dict(x)
        if y.get("from_day") is None:
            y["from_day"] = (int(y["from_week"]) - 1) * 7 + 1
        if y.get("to_day") is None and y.get("to_week"):
            y["to_day"] = int(y["to_week"]) * 7
        y.pop("from_week", None); y.pop("to_week", None)
        if y.get("to_day") is None:
            y.pop("to_day", None)
        out.append(y)
    return sorted(out, key=lambda x: int(x["from_day"]))


def _segments(med):
    """If dose steps carry their own schedule: [(first_day, last_day, schedule_or_None)], else None."""
    raw = med.get("phases")
    try:
        steps = json.loads(raw) if isinstance(raw, str) else raw
    except Exception:
        return None
    if not steps or not any(x.get("schedule") for x in steps):
        return None
    start = _d((med.get("phase_start") or med["start_date"])[:10])
    steps = norm_steps(steps)
    day = timedelta(days=1)
    segs = [(None, start + timedelta(days=steps[0]["from_day"] - 1) - day, None)]
    end = None
    for i, x in enumerate(steps):
        a = start + timedelta(days=x["from_day"] - 1)
        if i + 1 < len(steps):
            b = start + timedelta(days=steps[i + 1]["from_day"] - 1) - day
        elif x.get("to_day"):
            b = end = start + timedelta(days=x["to_day"] - 1)
        else:
            b = None
        segs.append((a, b, x.get("schedule")))
    if end:
        segs.append((end + day, None, None))
    return segs


def _with(med, ss, sa):
    base = sched(med)
    s = {**ss, "times": ss.get("times") or base["times"]}
    m2 = {**med, "schedule": json.dumps(s)}
    if s["type"] == "interval" and sa and not cycle_enabled(med):
        m2["start_date"] = max(sa, _d(med["start_date"])).isoformat()      # "every other day" counts from the step's first day
    return m2


def effective(med, today=None):
    """The schedule that applies today (a dose step may change how often you take it)."""
    today = today or date.today()
    for sa, sb, ss in _segments(med) or []:
        if ss and (sa is None or today >= sa) and (sb is None or today <= sb):
            return {**ss, "times": ss.get("times") or sched(med)["times"]}
    return sched(med)


def slots_between(med, a, b):
    """Scheduled dose datetimes within [a, b]."""
    segs = _segments(med)
    if not segs:
        yield from _slots(med, a, b)
        return
    for sa, sb, ss in segs:
        lo = max(a, datetime.combine(sa, time.min)) if sa else a
        hi = min(b, datetime.combine(sb, time(23, 59, 59))) if sb else b
        if lo <= hi:
            yield from _slots(_with(med, ss, sa) if ss else med, lo, hi)


def _slots(med, a, b):
    s = sched(med)
    if s["type"] == "prn":
        return
    d = a.date()
    while d <= b.date():
        if is_dose_day(med, d):
            for t in sorted(s["times"]) or ["23:59"]:   # no set time = "any time that day" (due by the end of the day)
                h, m = map(int, t.split(":"))
                dt = datetime.combine(d, time(h, m))
                if a <= dt <= b:
                    yield dt
        d += timedelta(days=1)


def iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M")


def cycle_info(med, today=None):
    today = today or date.today()
    start, end = _d(med["start_date"]), _d(med.get("end_date"))
    info = {"enabled": cycle_enabled(med), "state": "active"}
    if today < start:
        info.update(state="not_started", starts_in=(start - today).days)
        return info
    if end and today > end:
        info["state"] = "ended"
        return info
    if end:
        info["days_to_end"] = (end - today).days
    if not info["enabled"]:
        info["day_number"] = (today - start).days + 1
        return info
    on, off = med["cycle_on"], med["cycle_off"]
    n = (today - start).days
    pos = n % (on + off)
    phase = "on" if pos < on else "off"
    length = on if phase == "on" else off
    in_phase = pos + 1 if phase == "on" else pos - on + 1
    nxt = today + timedelta(days=length - in_phase + 1)
    info.update(
        phase=phase, day_in_phase=in_phase, phase_length=length,
        days_left_in_phase=length - in_phase, next_change=nxt.isoformat(),
        cycle_number=n // (on + off) + 1, next_phase="off" if phase == "on" else "on",
    )
    return info


def refill_info(med, logged_slots, now, grace):
    """Walk forward through future doses until stock runs out."""
    stock, dose = med.get("stock_qty"), med.get("dose")
    if stock is None or not dose:
        return None
    s = sched(med)
    if s["type"] == "prn":
        return {"tracked": True, "stock": stock, "days_left": None, "runs_out_on": None, "doses_left": int(stock // dose)}
    remaining, doses = stock, 0
    start = datetime.combine(now.date(), time.min)
    for slot in slots_between(med, start, now + timedelta(days=730)):
        if iso(slot) in logged_slots:
            continue
        if slot < now - timedelta(minutes=grace):
            continue  # missed already; won't consume stock
        if remaining < dose:
            days_left = max(0, (slot.date() - now.date()).days)
            return {"tracked": True, "stock": stock, "days_left": days_left,
                    "runs_out_on": slot.date().isoformat(), "doses_left": doses,
                    "low": days_left <= (med.get("refill_lead_days") or 7)}
        remaining -= dose
        doses += 1
    if doses == 0 and remaining >= dose:
        return {"tracked": True, "stock": stock, "days_left": None, "runs_out_on": None,
                "doses_left": int(stock // dose), "low": False}
    return {"tracked": True, "stock": stock, "days_left": None, "runs_out_on": None,
            "doses_left": doses, "low": False}


def describe(med):
    s = sched(med)
    t = s["type"]
    times = ", ".join(s["times"]) or "any time"
    if t == "daily":
        base = f"Daily at {times}"
    elif t == "interval":
        e = int(s.get("every", 1))
        base = f"Every {e} days at {times}"
    elif t == "weekdays":
        names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        base = f"{'/'.join(names[i] for i in sorted(s.get('days', [])))} at {times}"
    else:
        return "As needed"
    return base
