"""Finds the person's real Chrome / Edge so sign-in windows (and the app window) use the browser they actually prefer."""
import os
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

NAMES = {"chrome": "Google Chrome", "edge": "Microsoft Edge"}


def find(kind):
    """Path to an installed Chrome ('chrome') or Edge ('edge'), else None."""
    if os.name == "nt":
        pf, pf86, local = (os.environ.get(k, "") for k in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"))
        cands = {"chrome": [rf"{pf}\Google\Chrome\Application\chrome.exe", rf"{pf86}\Google\Chrome\Application\chrome.exe",
                            rf"{local}\Google\Chrome\Application\chrome.exe"],
                 "edge": [rf"{pf86}\Microsoft\Edge\Application\msedge.exe", rf"{pf}\Microsoft\Edge\Application\msedge.exe"]}[kind]
    elif sys.platform == "darwin":
        cands = {"chrome": ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"],
                 "edge": ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]}[kind]
    else:
        cands = [shutil.which(n) for n in (("google-chrome", "google-chrome-stable", "chromium", "chromium-browser") if kind == "chrome" else ("microsoft-edge",))]
    return next((c for c in cands if c and os.path.exists(c)), None)


def default_kind():
    """'chrome' | 'edge' | None: which of the two is the system default web browser."""
    try:
        if os.name == "nt":
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice") as k:
                prog = winreg.QueryValueEx(k, "ProgId")[0].lower()
        elif sys.platform == "darwin":
            return None
        else:
            prog = subprocess.run(["xdg-settings", "get", "default-web-browser"], capture_output=True, text=True, timeout=3).stdout.lower()
        if "chrome" in prog or "chromium" in prog:
            return "chrome"
        if "edge" in prog or "msedge" in prog:
            return "edge"
    except Exception:
        pass
    return None


def read_pref(data_dir):
    """The 'browser_pref' setting ('auto' | 'chrome' | 'edge'), read straight from the database."""
    try:
        with sqlite3.connect(Path(data_dir) / "tracker.db", timeout=5) as c:
            row = c.execute("SELECT value FROM settings WHERE key='browser_pref'").fetchone()
        return row[0] if row and row[0] in ("auto", "chrome", "edge") else "auto"
    except Exception:
        return "auto"


def choose(pref="auto"):
    """(kind, path) of the browser to use, or None if neither Chrome nor Edge is installed.
    auto = the system default if it is Chrome/Edge, otherwise Chrome, otherwise Edge."""
    if pref in ("chrome", "edge") and find(pref):
        return pref, find(pref)
    order = []
    d = default_kind()
    if pref == "auto" and d:
        order.append(d)
    order += [k for k in ("chrome", "edge") if k not in order]
    for k in order:
        p = find(k)
        if p:
            return k, p
    return None


def describe(pref="auto"):
    c = choose(pref)
    return {"pref": pref, "using": c[0] if c else "bundled", "using_name": NAMES[c[0]] if c else "the built-in Chromium (installed with sign-in mode)",
            "chrome": bool(find("chrome")), "edge": bool(find("edge")), "default": default_kind()}
