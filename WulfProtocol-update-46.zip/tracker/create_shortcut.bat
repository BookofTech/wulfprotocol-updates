@echo off
rem One-time setup + Desktop icon. Double-click this once (safe to run again after an update).
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Setting things up for the first time ^(1-2 minutes^)...
  python -m venv .venv || (echo Python 3.9+ is required. & pause & exit /b 1)
  ".venv\Scripts\pip" install -q -r requirements.txt || (echo Install failed. Check your internet connection and run this again. & pause & exit /b 1)
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\WulfProtocol.lnk'); $s.TargetPath='%~dp0.venv\Scripts\pythonw.exe'; $s.Arguments='launcher.py'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0assets\wulf.ico'; $s.WindowStyle=7; $s.Description='WulfProtocol'; $s.Save()"
if errorlevel 1 (
  echo Could not create the Desktop icon. You can still start the app by double-clicking start.bat.
  pause & exit /b 1
)
echo.
echo Done! A WulfProtocol icon is now on your Desktop. Opening it now...
start "" ".venv\Scripts\pythonw.exe" launcher.py
timeout /t 4 >nul
