#!/usr/bin/env bash
# Mac / Linux launcher: creates a private Python environment on first run, then starts the app.
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "First run: setting things up (1-2 minutes)..."
  python3 -m venv .venv || { echo "Python 3.9+ is required"; exit 1; }
  .venv/bin/pip install -q -r requirements.txt
fi
.venv/bin/python app.py
