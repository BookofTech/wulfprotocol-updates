/* Shows the WulfProtocol "loading" cursor while the app waits on the server for more than a moment.
   It only sets data-cursor="loading" on <body>; nothing else in the app is touched. */
(function () {
  if (!window.fetch) return;
  const SKIP = /\/api\/(login-window\/status|items\/bulk\/|stock-events)/;     // background polling shouldn't flash the cursor
  let pending = 0, timer = null;
  const set = on => { try { if (on) document.body.setAttribute("data-cursor", "loading"); else if (document.body.getAttribute("data-cursor") === "loading") document.body.removeAttribute("data-cursor"); } catch (e) { /* ignore */ } };
  const done = () => { if (--pending <= 0) { pending = 0; clearTimeout(timer); timer = null; set(false); } };
  const orig = window.fetch.bind(window);
  window.fetch = function (input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    if (SKIP.test(url)) return orig(input, init);
    pending++;
    if (!timer) timer = setTimeout(() => { timer = null; if (pending > 0) set(true); }, 350);
    return orig(input, init).finally(done);
  };
})();
