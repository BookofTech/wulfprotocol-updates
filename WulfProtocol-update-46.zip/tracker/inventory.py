"""Inventory: vials, peptides and supplies on hand, with low-stock / expiry alerts and automatic use per dose."""
from datetime import date, datetime, timedelta

import db
import schedule as sch

PEPTIDE_GROUPS = ["Anabolics", "Analgesics", "Cosmetic", "Diluents & Additives", "Fat Burning", "Immune", "Nootropics",
                  "Post-Cycle Therapy (PCT)", "Sexual Health", "Tissue Growth & Repair", "Canine"]
PICK_CATEGORIES = PEPTIDE_GROUPS + ["Supplies", "Other"]            # what "Add item" offers
LEGACY = ["Peptides & vials", "Medications"]                        # older installs: still shown while items use them
# categories whose items are doses of medication (tracked as vials). Diluents & Additives are used like supplies instead.
VIAL_CATEGORIES = [c for c in PEPTIDE_GROUPS if c != "Diluents & Additives"] + ["Peptides & vials"]
MASS = {"mcg": 1, "ug": 1, "µg": 1, "mg": 1000, "g": 1e6}
PRESETS = [
    ("Insulin syringes (U-100)", "Supplies", "pcs", 20),
    ("Draw needles", "Supplies", "pcs", 20), ("Injection needles", "Supplies", "pcs", 20), ("Alcohol swabs", "Supplies", "pcs", 30),
    ("Bacteriostatic water", "Supplies", "vials", 1), ("Sterile water", "Supplies", "vials", 1), ("Sharps container", "Supplies", "pcs", 1),
    ("Gauze / bandages", "Supplies", "pcs", 20), ("Gloves", "Supplies", "pcs", 10), ("Nasal spray bottle", "Supplies", "pcs", 1),
]


def _now():
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


def adjust(inv_id, delta=None, reason="adjust", note=None, set_to=None, ts=None):
    """Change a quantity (never below 0) and record it in the history. Returns the new quantity or None."""
    row = db.q("SELECT qty FROM inventory WHERE id=?", (inv_id,), one=True)
    if not row:
        return None
    old = row["qty"] or 0
    new = max(0.0, float(set_to) if set_to is not None else old + float(delta))
    if abs(new - old) < 1e-9 and set_to is None:
        return new
    db.x("UPDATE inventory SET qty=? WHERE id=?", (new, inv_id))
    db.x("INSERT INTO inventory_log(inv_id,ts,change,qty_after,reason,note) VALUES (?,?,?,?,?,?)", (inv_id, ts or _now(), new - old, new, reason, note))
    return new


def use_for_dose(med_id, sign=-1):
    """A dose was logged (sign=-1) or its log deleted (sign=+1): move linked supplies that are used per dose."""
    for r in db.q("SELECT inv_id, per_dose FROM med_supplies WHERE med_id=? AND per_dose>0", (med_id,)):
        adjust(r["inv_id"], sign * r["per_dose"], "dose" if sign < 0 else "dose log removed")


def supplies_for(med_id):
    """Every supply item (vials are tracked on the Meds tab instead) with how much one dose of this medication uses (None = not linked)."""
    mine = {r["inv_id"]: r["per_dose"] for r in db.q("SELECT inv_id, per_dose FROM med_supplies WHERE med_id=?", (med_id,))} if med_id else {}
    items = db.q("SELECT id,name,category,qty,unit,size FROM inventory WHERE category NOT IN (%s) ORDER BY category, name COLLATE NOCASE" % ",".join("?" * len(VIAL_CATEGORIES)), VIAL_CATEGORIES)
    return [{**i, "per_dose": mine.get(i["id"])} for i in items]


def set_supplies(med_id, links):
    """Replace the supply list of a medication. links: [{inv_id, per_dose}]"""
    db.x("DELETE FROM med_supplies WHERE med_id=?", (med_id,))
    for ln in links:
        try:
            inv, per = int(ln["inv_id"]), float(ln.get("per_dose") or 0)
        except (KeyError, TypeError, ValueError):
            continue
        if per > 0 and db.q("SELECT id FROM inventory WHERE id=?", (inv,), one=True):
            db.x("INSERT OR REPLACE INTO med_supplies(med_id,inv_id,per_dose) VALUES (?,?,?)", (med_id, inv, per))


def _vial_in_dose_unit(m):
    if not (m.get("vial_amount") or 0) > 0:
        return None
    vu, du = (m.get("vial_unit") or m.get("dose_unit") or "").lower(), (m.get("dose_unit") or "").lower()
    if vu == du:
        return m["vial_amount"]
    return m["vial_amount"] * MASS[vu] / MASS[du] if vu in MASS and du in MASS else None


def open_vial(inv_id):
    """Open one unopened vial: -1 from inventory; if linked to a med, add its contents to the med's stock and restart its expiry clock."""
    it = db.q("SELECT * FROM inventory WHERE id=?", (inv_id,), one=True)
    if not it:
        return {"error": "Not found"}
    if (it["qty"] or 0) < 1:
        return {"error": "No unopened vials left to open"}
    adjust(inv_id, -1, "opened a vial")
    out = {"ok": True, "added_to_med": None}
    m = db.q("SELECT * FROM meds WHERE id=?", (it["med_id"],), one=True) if it["med_id"] else None
    if m:
        v = _vial_in_dose_unit(m)
        if v:
            db.x("UPDATE meds SET stock_qty=COALESCE(stock_qty,0)+? WHERE id=?", (v, m["id"]))
            out["added_to_med"] = {"qty": v, "unit": m["dose_unit"], "name": m["name"]}
        db.x("UPDATE meds SET opened_on=? WHERE id=?", (date.today().isoformat(), m["id"]))
    return out


def add_orders(lines, ordered_on=None, expected_by=None):
    """Record that you ordered these (from the Order planner). Each line: name, site, url, qty, unit_price, currency, price_item_id."""
    ids = []
    for ln in lines:
        qty = float(ln.get("qty") or 0)
        if qty <= 0 or not (ln.get("name") or "").strip():
            continue
        pid = int(ln["price_item_id"]) if ln.get("price_item_id") not in (None, "") else None
        link = db.q("SELECT id FROM inventory WHERE price_item_id=? ORDER BY id LIMIT 1", (pid,), one=True) if pid else None
        up = ln.get("unit_price")
        ids.append(db.x("INSERT INTO orders(name,site,url,price_item_id,inv_id,qty,unit_price,currency,ordered_on,expected_by) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (ln["name"].strip(), ln.get("site") or None, ln.get("url") or None, pid, link["id"] if link else None, qty,
                         float(up) if up not in (None, "") else None, ln.get("currency") or None,
                         ordered_on or date.today().isoformat(), expected_by or None)))
    return ids


def receive_order(oid, qty, per_item=1.0, inv_id=None, new_item=None, lot=None, expiry_date=None, note=None, received_on=None):
    """Some or all of an order arrived: add it to stock (history line included). Returns {error} or {ok, ...}."""
    o = db.q("SELECT * FROM orders WHERE id=?", (oid,), one=True)
    if not o or o["status"] != "open":
        return {"error": "That order isn't open any more"}
    left = o["qty"] - (o["qty_received"] or 0)
    try:                                              # the day it actually arrived (can be days ago)
        day = date.fromisoformat((received_on or date.today().isoformat())[:10])
    except ValueError:
        return {"error": "That arrival date isn't valid"}
    if day > date.today():
        return {"error": "The arrival date can't be in the future"}
    qty, per_item = float(qty or 0), float(per_item or 1)
    if qty <= 0 or per_item <= 0:
        return {"error": "Enter how many arrived"}
    if qty > left + 1e-9:
        return {"error": f"Only {left:g} still on order"}
    target = inv_id or o["inv_id"]
    if not target:
        if not new_item or not (new_item.get("name") or "").strip():
            return {"error": "Choose which inventory item this adds to"}
        target = db.x("INSERT INTO inventory(name,category,unit,qty,low_at,price_item_id) VALUES (?,?,?,0,?,?)",
                      (new_item["name"].strip(), new_item.get("category") or "Supplies", new_item.get("unit") or "pcs",
                       float(new_item["low_at"]) if new_item.get("low_at") not in (None, "") else None, o["price_item_id"]))
    elif not db.q("SELECT id FROM inventory WHERE id=?", (target,), one=True):
        return {"error": "That inventory item no longer exists"}
    add = qty * per_item
    adjust(target, add, "received", note or f"order from {o['site'] or 'a store'}" + (f" ({qty:g} × {per_item:g})" if per_item != 1 else ""),
           ts=f"{day.isoformat()}T12:00:00" if day != date.today() else None)
    sets, args = [], []
    for col, v in (("lot", lot), ("expiry_date", expiry_date)):
        if v:
            sets.append(f"{col}=?"); args.append(v)
    if sets:
        db.x(f"UPDATE inventory SET {','.join(sets)} WHERE id=?", (*args, target))
    got = (o["qty_received"] or 0) + qty
    done = got >= o["qty"] - 1e-9
    db.x("UPDATE orders SET qty_received=?, inv_id=?, status=?, received_on=? WHERE id=?",
         (got, target, "received" if done else "open", day.isoformat(), oid))
    return {"ok": True, "added": add, "inv_id": target, "complete": done}


def orders_payload(today=None):
    today = today or date.today()
    rows = db.q("SELECT * FROM orders WHERE status='open' ORDER BY ordered_on, id")
    for r in rows:
        r["left"] = r["qty"] - (r["qty_received"] or 0)
        r["late_days"] = (today - date.fromisoformat(r["expected_by"][:10])).days if r["expected_by"] and r["expected_by"][:10] < today.isoformat() else 0
    recent = db.q("SELECT * FROM orders WHERE status='received' ORDER BY received_on DESC, id DESC LIMIT 15")
    return {"open": rows, "recent": recent}


def _doses_per_day(m, days=60):
    now = datetime.now()
    n = sum(1 for _ in sch.slots_between(m, now, now + timedelta(days=days)))
    return n / days


def _row(it, meds, price_items, today, ords=None, paid=None, uses=None):
    it = dict(it)
    m = meds.get(it["med_id"]) if it["med_id"] else None
    it["med_name"] = m["name"] if m else None
    it["days_left"], it["basis"] = None, None
    mine = (uses or {}).get(it["id"], [])
    it["uses"] = [{"med_id": u["med_id"], "med_name": meds[u["med_id"]]["name"], "per_dose": u["per_dose"]} for u in mine if u["med_id"] in meds]
    daily = sum(u["per_dose"] * _doses_per_day(meds[u["med_id"]]) for u in mine if u["med_id"] in meds)
    if daily > 0:                                                        # supplies: qty / (use per dose x doses per day, over every medication that uses it)
        it["days_left"], it["basis"] = round((it["qty"] or 0) / daily), "supplies"
    if m:
        rate = _doses_per_day(m)
        if rate > 0:
            if it["category"] in VIAL_CATEGORIES and m["dose"]:      # vials: unopened vials + what's left in the open one
                v = _vial_in_dose_unit(m)
                if v:
                    it["days_left"] = round((((it["qty"] or 0) * v) + (m["stock_qty"] or 0)) / m["dose"] / rate)
                    it["basis"] = "vials"
    exp = it["expiry_date"]
    it["expiry_in"] = (date.fromisoformat(exp[:10]) - today).days if exp else None
    flags = []
    if (it["qty"] or 0) <= 0:
        flags.append("out")
    elif it["low_at"] is not None and it["qty"] <= it["low_at"]:
        flags.append("low")
    elif it["days_left"] is not None and it["days_left"] <= 14:
        flags.append("low")
    if it["expiry_in"] is not None:
        if it["expiry_in"] < 0:
            flags.append("expired")
        elif it["expiry_in"] <= 30:
            flags.append("expiring")
    mine = (ords or {}).get(it["id"], [])
    it["on_order"] = sum(o["left"] for o in mine)
    it["order_late"] = max((o["late_days"] for o in mine), default=0)
    if it["on_order"] > 0:                       # already reordered: don't nag about low / out
        flags = [f for f in flags if f not in ("low", "out")]
        if it["order_late"] > 0:
            flags.append("late")
    it["flags"] = flags
    it["last_paid"] = (paid or {}).get(it["id"])
    p = price_items.get(it["price_item_id"]) if it["price_item_id"] else None
    it["price"] = {"name": p["name"], "best": p["best"]} if p else None
    return it


def build(price_items):
    meds = {m["id"]: m for m in db.q("SELECT * FROM meds")}
    pi = {p["id"]: p for p in price_items}
    today = date.today()
    uses = {}
    for r in db.q("SELECT * FROM med_supplies"):
        uses.setdefault(r["inv_id"], []).append(r)
    op = orders_payload(today)
    ords = {}
    for o in op["open"]:
        if o["inv_id"]:
            ords.setdefault(o["inv_id"], []).append(o)
    paid = {}                                      # most recent price paid per item (from received orders)
    for o in db.q("SELECT * FROM orders WHERE status='received' AND unit_price IS NOT NULL AND inv_id IS NOT NULL ORDER BY received_on, id"):
        paid[o["inv_id"]] = {"price": o["unit_price"], "currency": o["currency"], "site": o["site"], "date": o["received_on"] or o["ordered_on"]}
    items = [_row(r, meds, pi, today, ords, paid, uses) for r in db.q("SELECT * FROM inventory ORDER BY category, name COLLATE NOCASE")]
    cnt = lambda f: sum(f in i["flags"] for i in items)
    used = {i["category"] for i in items}
    cats = PEPTIDE_GROUPS + ["Supplies", "Other"] + [c for c in LEGACY if c in used] + sorted(c for c in used if c not in PICK_CATEGORIES + LEGACY)
    return {"items": items, "categories": cats, "pick_categories": PICK_CATEGORIES, "vial_categories": VIAL_CATEGORIES, "presets": [{"name": n, "category": c, "unit": u, "low_at": l} for n, c, u, l in PRESETS],
            "orders": op,
            "summary": {"count": len(items), "low": cnt("low"), "out": cnt("out"), "expiring": cnt("expiring"), "expired": cnt("expired"),
                        "late": len([o for o in op["open"] if o["late_days"] > 0]), "on_order": len(op["open"])}}


def summary(price_items):
    b = build(price_items)
    flagged = [i for i in b["items"] if i["flags"]]
    order = {"expired": 0, "out": 1, "late": 2, "low": 3, "expiring": 4}
    flagged.sort(key=lambda i: min(order[f] for f in i["flags"]))
    return {**b["summary"], "top": [{"id": i["id"], "name": i["name"], "qty": i["qty"], "unit": i["unit"], "flags": i["flags"], "days_left": i["days_left"],
                                     "expiry_in": i["expiry_in"]} for i in flagged[:5]]}
