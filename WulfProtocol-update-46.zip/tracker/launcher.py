"""Desktop-icon launcher (run with pythonw so no console window appears).

  1. If WulfProtocol's background engine isn't running, start it hidden.
  2. Open the app in its own window (Edge or Chrome "app mode": no tabs, no address bar).

The engine keeps running after you close the window, so price checks and reminders continue.
Stop it with Settings -> Quit WulfProtocol, or end "Python" (pythonw.exe) in Task Manager.
Use `--background` to start the engine only (used by "start with Windows").
"""
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = Path(os.environ.get("TRACKER_DATA", HERE / "data"))
PORT = int(os.environ.get("PORT", 8765))
URL = f"http://127.0.0.1:{PORT}"


def notify(msg):
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, msg, "WulfProtocol", 0x10)
            return
        except Exception:
            pass
    print(msg)


def ping():
    """'ours' | 'other' | None (nothing listening)"""
    try:
        with urllib.request.urlopen(URL + "/api/ping", timeout=1.5) as r:
            return "ours" if json.load(r).get("app") == "wulfprotocol" else "other"
    except urllib.error.HTTPError:
        return "other"
    except Exception:
        return None


def start_engine():
    DATA.mkdir(parents=True, exist_ok=True)
    log_path = DATA / "app.log"
    if log_path.exists() and log_path.stat().st_size > 500_000:      # keep the log small
        log_path.write_text("")
    log = open(log_path, "a", buffering=1, encoding="utf-8")
    env = dict(os.environ, NO_BROWSER="1", PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = 0x00000008 | 0x08000000 | 0x00000200      # detached, no window, own process group
    else:
        kw["start_new_session"] = True
    subprocess.Popen([sys.executable, str(HERE / "app.py")], cwd=str(HERE), env=env,
                     stdin=subprocess.DEVNULL, stdout=log, stderr=log, **kw)


def find_app_browser():
    """Chrome or Edge for the app-style window: the person's setting, else their system default browser."""
    try:
        import browsers
        pick = browsers.choose(browsers.read_pref(DATA))
        return pick[1] if pick else None
    except Exception:
        return None


def open_window():
    exe = find_app_browser()
    if exe:
        profile = DATA / "app_window_profile"       # own profile => own taskbar icon and remembered window size
        try:
            subprocess.Popen([exe, f"--app={URL}", f"--user-data-dir={profile}", "--no-first-run", "--no-default-browser-check",
                              "--window-size=1320,880"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except Exception:
            pass
    webbrowser.open(URL)                              # fallback: a normal browser tab


def main():
    state = ping()
    if state == "other":
        return notify(f"Port {PORT} is being used by another program, so WulfProtocol can't start.\n"
                      "Close that program (or restart your PC) and try again.")
    if state is None:
        start_engine()
        for _ in range(60):                           # wait up to ~30 s
            time.sleep(0.5)
            if ping() == "ours":
                break
        else:
            return notify("WulfProtocol couldn't start.\n\nOpen the 'data' folder and look at app.log for details, "
                          "or run start.bat to see the error.")
    if "--background" not in sys.argv:
        open_window()


if __name__ == "__main__":
    main()
