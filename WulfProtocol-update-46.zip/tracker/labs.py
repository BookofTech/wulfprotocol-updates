"""Lab / biomarker tracking: presets, status, spike detection and 'what was happening' context."""
from datetime import date, datetime, timedelta

import db

# name, unit, category, {sex: (low, high)} - typical adult ranges. They vary by lab, age and sex:
# the app always lets you edit them to match the range printed on your own report.
_ANY, _M, _F = "any", "male", "female"
PRESETS = [
    ("Total Testosterone", "ng/dL", "Hormones", {_M: (264, 916), _F: (8, 60)}),
    ("Free Testosterone", "pg/mL", "Hormones", {_M: (50, 210)}),
    ("Estradiol (E2)", "pg/mL", "Hormones", {_M: (10, 40)}),
    ("SHBG", "nmol/L", "Hormones", {_M: (16.5, 55.9)}),
    ("LH", "mIU/mL", "Hormones", {_M: (1.7, 8.6)}),
    ("FSH", "mIU/mL", "Hormones", {_M: (1.5, 12.4)}),
    ("Prolactin", "ng/mL", "Hormones", {_M: (4, 15.2), _F: (4.8, 23.3)}),
    ("DHEA-S", "µg/dL", "Hormones", {_M: (80, 560)}),
    ("Cortisol (AM)", "µg/dL", "Hormones", {_ANY: (6, 23)}),
    ("IGF-1", "ng/mL", "Hormones", {}),                      # strongly age-specific: enter your lab's range
    ("TSH", "mIU/L", "Thyroid", {_ANY: (0.4, 4.0)}),
    ("Free T4", "ng/dL", "Thyroid", {_ANY: (0.8, 1.8)}),
    ("Free T3", "pg/mL", "Thyroid", {_ANY: (2.3, 4.2)}),
    ("Fasting Glucose", "mg/dL", "Metabolic", {_ANY: (70, 99)}),
    ("HbA1c", "%", "Metabolic", {_ANY: (4.0, 5.6)}),
    ("Fasting Insulin", "µIU/mL", "Metabolic", {_ANY: (2, 19)}),
    ("Total Cholesterol", "mg/dL", "Lipids", {_ANY: (None, 200)}),
    ("LDL Cholesterol", "mg/dL", "Lipids", {_ANY: (None, 100)}),
    ("HDL Cholesterol", "mg/dL", "Lipids", {_M: (40, None), _F: (50, None)}),
    ("Triglycerides", "mg/dL", "Lipids", {_ANY: (None, 150)}),
    ("ApoB", "mg/dL", "Lipids", {_ANY: (None, 90)}),
    ("hs-CRP", "mg/L", "Inflammation", {_ANY: (None, 3.0)}),
    ("Homocysteine", "µmol/L", "Inflammation", {_ANY: (5, 15)}),
    ("ALT", "U/L", "Liver & kidney", {_ANY: (7, 56)}),
    ("AST", "U/L", "Liver & kidney", {_ANY: (10, 40)}),
    ("GGT", "U/L", "Liver & kidney", {_ANY: (8, 61)}),
    ("Creatinine", "mg/dL", "Liver & kidney", {_M: (0.74, 1.35), _F: (0.59, 1.04)}),
    ("eGFR", "mL/min/1.73m²", "Liver & kidney", {_ANY: (60, None)}),
    ("BUN", "mg/dL", "Liver & kidney", {_ANY: (7, 20)}),
    ("Uric Acid", "mg/dL", "Liver & kidney", {_M: (3.4, 7.0), _F: (2.4, 6.0)}),
    ("Hemoglobin", "g/dL", "Blood", {_M: (13.5, 17.5), _F: (12.0, 15.5)}),
    ("Hematocrit", "%", "Blood", {_M: (38.3, 48.6), _F: (35.5, 44.9)}),
    ("RBC", "10¹²/L", "Blood", {_M: (4.35, 5.65), _F: (3.92, 5.13)}),
    ("WBC", "10⁹/L", "Blood", {_ANY: (4.5, 11.0)}),
    ("Platelets", "10⁹/L", "Blood", {_ANY: (150, 450)}),
    ("Ferritin", "ng/mL", "Blood", {_M: (24, 336), _F: (11, 307)}),
    ("PSA", "ng/mL", "Other", {_M: (None, 4.0)}),
    ("Vitamin D (25-OH)", "ng/mL", "Other", {_ANY: (30, 100)}),
    ("Vitamin B12", "pg/mL", "Other", {_ANY: (200, 900)}),
    ("Magnesium", "mg/dL", "Other", {_ANY: (1.7, 2.2)}),
]
CATEGORIES = ["Hormones", "Thyroid", "Metabolic", "Lipids", "Inflammation", "Liver & kidney", "Blood", "Other"]
EVENT_TYPES = {
    "med_start": "Started a med", "dose_change": "Dose change", "med_stop": "Stopped a med", "illness": "Illness",
    "injury": "Injury", "travel": "Travel", "diet": "Diet change", "training": "Training change",
    "stress": "Stress / poor sleep", "other": "Other",
}


def presets(sex=None):
    out = []
    for name, unit, cat, rng in PRESETS:
        r = rng.get(sex) or (rng.get(_ANY) if _ANY in rng else None)
        if r is None and sex not in (_M, _F):               # sex unknown: fall back to the male range if that's all there is
            r = rng.get(_M)
        lo, hi = r if r else (None, None)
        out.append({"name": name, "unit": unit, "category": cat, "ref_low": lo, "ref_high": hi})
    return out


def status_of(v, lo, hi):
    if lo is not None and v < lo:
        return "low"
    if hi is not None and v > hi:
        return "high"
    return "normal" if (lo is not None or hi is not None) else "none"


def auto_events():
    """Medication start/stop dates, so they show up on the charts without extra typing."""
    ev = []
    for m in db.q("SELECT id,name,start_date,end_date FROM meds"):
        if m["start_date"]:
            ev.append({"id": f"a-s{m['id']}", "auto": True, "date": m["start_date"][:10], "end_date": None, "type": "med_start",
                       "title": f"Started {m['name']}", "notes": None, "med_id": m["id"]})
        if m["end_date"]:
            ev.append({"id": f"a-e{m['id']}", "auto": True, "date": m["end_date"][:10], "end_date": None, "type": "med_stop",
                       "title": f"Ended {m['name']}", "notes": None, "med_id": m["id"]})
    return ev


def all_events():
    ev = [dict(e, auto=False) for e in db.q("SELECT * FROM events ORDER BY date DESC, id DESC")] + auto_events()
    ev.sort(key=lambda e: (e["date"], str(e["id"])), reverse=True)
    return ev


def _days(a, b):
    return (date.fromisoformat(b[:10]) - date.fromisoformat(a[:10])).days


def build(spike_pct=None):
    """Everything the Labs tab needs, in one payload."""
    spike_pct = spike_pct if spike_pct is not None else db.get_settings()["lab_spike_pct"]
    today = date.today().isoformat()
    events = all_events()
    bms = db.q("SELECT * FROM biomarkers ORDER BY category, name COLLATE NOCASE")
    res = {}
    for r in db.q("SELECT * FROM lab_results ORDER BY date, id"):
        res.setdefault(r["biomarker_id"], []).append(r)
    insights = []
    for b in bms:
        rows = res.get(b["id"], [])
        prev = None
        for r in rows:                                          # per-result annotations
            r["status"] = status_of(r["value"], b["ref_low"], b["ref_high"])
            r["change_pct"] = None
            r["spike"] = False
            r["context"] = []
            if prev is not None and prev["value"]:
                r["change_pct"] = round((r["value"] - prev["value"]) / abs(prev["value"]) * 100, 1)
                r["spike"] = abs(r["change_pct"]) >= spike_pct
                r["context"] = [{"date": e["date"], "type": e["type"], "title": e["title"]} for e in sorted(events, key=lambda e: e["date"])
                                if prev["date"] <= e["date"] <= r["date"]][:8]
            prev = r
        b["results"] = rows
        b["latest"] = rows[-1] if rows else None
        b["status"] = b["latest"]["status"] if rows else "none"
        b["days_since"] = _days(b["latest"]["date"], today) if rows else None
        b["retest_due"] = bool(b["retest_days"] and rows and b["days_since"] >= b["retest_days"])
        b["retest_in"] = (b["retest_days"] - b["days_since"]) if (b["retest_days"] and rows) else None
        if not rows:
            continue
        L = b["latest"]
        if L["spike"] and b["days_since"] <= 365:
            insights.append({"kind": "spike", "biomarker_id": b["id"], "name": b["name"], "unit": b["unit"], "value": L["value"],
                             "pct": L["change_pct"], "date": L["date"], "status": L["status"], "context": L["context"]})
        if L["status"] in ("low", "high"):
            insights.append({"kind": "range", "biomarker_id": b["id"], "name": b["name"], "unit": b["unit"], "value": L["value"],
                             "status": L["status"], "date": L["date"], "ref_low": b["ref_low"], "ref_high": b["ref_high"]})
        if b["retest_due"]:
            insights.append({"kind": "retest", "biomarker_id": b["id"], "name": b["name"], "days_since": b["days_since"],
                             "overdue": b["days_since"] - b["retest_days"]})
    order = {"spike": 0, "range": 1, "retest": 2}
    insights.sort(key=lambda i: (order[i["kind"]], -abs(i.get("pct") or 0)))
    return {"biomarkers": bms, "events": events, "insights": insights, "categories": CATEGORIES,
            "event_types": EVENT_TYPES, "spike_pct": spike_pct}


def summary():
    """Small version for the dashboard."""
    n = db.q("SELECT COUNT(*) c FROM biomarkers", one=True)["c"]
    if not n:
        return {"count": 0}
    ins = build()["insights"]
    return {"count": n, "spikes": sum(i["kind"] == "spike" for i in ins), "out_of_range": sum(i["kind"] == "range" for i in ins),
            "retest": sum(i["kind"] == "retest" for i in ins), "top": ins[:4]}
