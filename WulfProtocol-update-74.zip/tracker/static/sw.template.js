/* WulfProtocol phone offline mode (service worker). Served as /sw.js on the phone's secure address only.
   - The app itself (page, scripts, styles, icons) is saved on the phone, so it opens with no connection to the PC.
   - Data (/api GETs): the copy saved on the phone is shown straight away, so changing tabs is instant, and a fresh
     copy is fetched from the PC behind it. If the fresh copy is different the page is told and redraws itself.
     Right after you change something the page asks for fresh data first (X-WP-Fresh) so you never see the old state.
     Away from home the saved copy is all there is (it carries X-WP-Cache: 1) and the page shows the offline bar.
     If the PC says this phone is signed out, the saved data is wiped from the phone.
   - Changes (logging a dose or weigh-in) are not handled here: the page keeps them and sends them when it's home. */
const BUILD = "__BUILD__", SHELL = "wp-shell-" + BUILD, DATA = "wp-data";
const ASSETS = __ASSETS__;
const NO_CACHE = ["/api/export", "/api/log", "/api/phone-login", "/phone-login", "/phone-ca.crt", "/sw.js", "/api/update"];
const WAIT_MS = 4000;     // how long to wait for the PC before giving up on a fresh copy
let down = false;         // the PC couldn't be reached at the last try
const lastTry = new Map();

function tell(msg) { return self.clients.matchAll({ includeUncontrolled: true }).then(cs => cs.forEach(c => c.postMessage(msg))).catch(() => { }); }
function savedCopy(hit, flag) {
  const h = new Headers(hit.headers); h.set(flag, "1");
  return hit.blob().then(b => new Response(b, { status: hit.status, statusText: hit.statusText, headers: h }));
}
/* Fetch a fresh copy from the PC, save it, and tell the page what happened. oldText = the saved copy's text (or null). */
async function refresh(url, oldText) {
  let r;
  try { r = await timed(new Request(url, { credentials: "same-origin", headers: { "X-WulfProtocol": "1" } }), WAIT_MS); }
  catch (x) { down = true; tell({ type: "offline" }); throw x; }
  if (r.status === 401) { await caches.delete(DATA); tell({ type: "signedout" }); return r; }       // signed out: nothing stays on the phone
  const wasDown = down; down = false;
  if (r.ok) {
    const txt = await r.clone().text();
    await putStamped(await caches.open(DATA), url, r);
    if (oldText !== null && txt !== oldText) tell({ type: "fresh", url });
  }
  if (wasDown) tell({ type: "online" });
  return r;
}

function timed(req, ms) {
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
  return fetch(req, { signal: ac.signal }).finally(() => clearTimeout(t));
}
async function putStamped(cache, key, resp) {
  const d = new Date(), p = n => String(n).padStart(2, "0");
  const h = new Headers(resp.headers); h.set("X-WP-Saved-At", `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`);
  await cache.put(key, new Response(await resp.clone().blob(), { status: resp.status, statusText: resp.statusText, headers: h }));
}

self.addEventListener("install", e => {
  e.waitUntil((async () => {
    const c = await caches.open(SHELL);
    for (const u of ["/"].concat(ASSETS)) {
      try { const r = await fetch(u, { credentials: "same-origin" }); if (r.ok && !r.redirected) await c.put(u, r); } catch (x) { /* saved later */ }
    }
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k.startsWith("wp-shell-") && k !== SHELL) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== location.origin || NO_CACHE.some(p => url.pathname === p || url.pathname.startsWith(p + "/"))) return;
  if (req.mode === "navigate" || url.pathname === "/") {            // the app page
    e.respondWith((async () => {
      try {
        const r = await timed(req, WAIT_MS);
        if (r.ok && !r.redirected) await (await caches.open(SHELL)).put("/", r.clone());
        return r;
      } catch (x) {
        const hit = await (await caches.open(SHELL)).match("/");
        return hit || new Response("<!doctype html><meta name=viewport content='width=device-width'><body style='background:#0b1016;color:#e8eef5;font:16px system-ui;padding:40px 20px;text-align:center'>" +
          "<h2>Can't reach your PC</h2><p>WulfProtocol hasn't been saved on this phone yet. Open it once at home on your Wi-Fi first.</p></body>",
          { status: 503, headers: { "Content-Type": "text/html; charset=utf-8" } });
      }
    })());
    return;
  }
  if (url.pathname.startsWith("/static/")) {                         // app files: saved copy first
    e.respondWith((async () => {
      const c = await caches.open(SHELL), hit = await c.match(req);
      if (hit) return hit;
      const r = await fetch(req);
      if (r.ok) c.put(req, r.clone());
      return r;
    })());
    return;
  }
  if (url.pathname.startsWith("/api/")) {                            // data: saved copy now, fresh copy behind it
    e.respondWith((async () => {
      const hit = await (await caches.open(DATA)).match(req.url);
      if (hit && !req.headers.get("X-WP-Fresh")) {
        if (Date.now() - (lastTry.get(req.url) || 0) > 4000) {         // don't ask the PC for the same thing more than every 4 s
          lastTry.set(req.url, Date.now());
          const old = await hit.clone().text();
          e.waitUntil(refresh(req.url, old).catch(() => { }));
        }
        return savedCopy(hit, down ? "X-WP-Cache" : "X-WP-Stale");
      }
      try { lastTry.set(req.url, Date.now()); return await refresh(req.url, null); }
      catch (x) {
        return hit ? savedCopy(hit, "X-WP-Cache") : new Response(JSON.stringify({ error: "offline" }),
          { status: 503, headers: { "Content-Type": "application/json", "X-WP-Cache": "1", "X-WP-Offline": "1" } });
      }
    })());
  }
});
