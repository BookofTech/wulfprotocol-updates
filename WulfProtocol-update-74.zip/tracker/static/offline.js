/* Phone offline mode (page side). Only active on the phone's secure address (window.WP_PHONE on https).
   - Saves the app on the phone (service worker, /sw.js) and keeps copies of your data fresh while at home.
   - Away from home: pages show the last saved data, and logging a dose or a weigh-in is kept on the phone.
   - Back on the home Wi-Fi: what was kept is sent to the PC by itself, oldest first. A dose already logged on the PC
     for the same time isn't logged twice. A bar at the top says when you're offline and what's waiting. */
window.Offline = (function () {
  const on = !!window.WP_PHONE && window.isSecureContext && "serviceWorker" in navigator;
  const QKEY = "wp_queue", WARMKEY = "wp_warm_at";
  const QUEUEABLE = [["POST", /^\/logs$/], ["POST", /^\/metrics$/]];
  let savedAt = null, offline = false, needLogin = false, syncing = false;

  const read = () => { try { return JSON.parse(localStorage.getItem(QKEY) || "[]"); } catch (e) { return []; } };
  const write = q => { try { localStorage.setItem(QKEY, JSON.stringify(q)); } catch (e) { /* storage full / blocked */ } };
  function fetchT(url, opts, ms) {
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
    return fetch(url, { ...opts, signal: ac.signal }).finally(() => clearTimeout(t));
  }

  function canQueue(path, method) { return on && QUEUEABLE.some(([m, re]) => m === method && re.test(path)); }
  function queue(path, method, body) {
    const b = { ...(body || {}) };
    if (path === "/logs" && !b.taken_at) b.taken_at = nowLocalInput();          // the time you pressed it, not the time it syncs
    const it = { qid: Date.now().toString(36) + Math.random().toString(36).slice(2, 7), path, method, body: b, at: new Date().toISOString() };
    const q = read(); q.push(it); write(q); offline = true; bar();
    return { queued: true, qid: it.qid, id: null };
  }
  function remove(qid) { write(read().filter(i => i.qid !== qid)); bar(); }
  function pending(med_id, slot) { return on && read().some(i => i.path === "/logs" && +i.body.med_id === +med_id && i.body.slot === slot); }
  function count() { return read().length; }
  function decorate(view) {               // a dose kept on the phone shows as saved instead of offering Take again
    if (!on || !read().length) return;
    $$("[data-tk], [data-take], [data-take-late], [data-skip]", view).forEach(b => {
      const v = b.dataset.tk || b.dataset.take || b.dataset.takeLate || b.dataset.skip || ""; const [id, slot] = v.split("|");
      if (!pending(id, slot)) return;
      if (b.dataset.skip) { b.style.display = "none"; return; }
      b.outerHTML = '<span class="badge ok offsaved" title="Kept on this phone. It is sent to your PC when you are home.">⏳ Saved · syncs at home</span>';
    });
  }

  async function flush() {
    if (!on || syncing || !read().length) return;
    syncing = true; let done = 0; const failed = [];
    try {
      for (const it of read()) {
        let r;
        try { r = await fetchT("/api" + it.path, { method: it.method, headers: { "Content-Type": "application/json", "X-WulfProtocol": "1" }, body: JSON.stringify(it.body) }, 8000); }
        catch (e) { offline = true; break; }                                       // still away: try again later
        if (r.status === 401) { needLogin = true; break; }                         // signed out: keep everything until the PIN is entered
        needLogin = false; offline = false;
        if (r.ok || r.status === 409) { remove(it.qid); done++; }                  // 409 = already logged on the PC
        else { const d = await r.json().catch(() => ({})); failed.push(d.error || ("error " + r.status)); remove(it.qid); }
      }
    } finally { syncing = false; }
    bar();
    if (done) { wrote(); toast(`Synced ${done} change${done > 1 ? "s" : ""} from this phone ✓`); if (window.Router) Router.render(); }
    if (failed.length) toast("Couldn't sync " + failed.length + ": " + failed[0], true);
  }

  function mark(resp) {                    // called by api() for every answer
    if (!on) return;
    if (resp.headers.get("X-WP-Cache")) { offline = true; savedAt = resp.headers.get("X-WP-Saved-At") || savedAt; }
    else if (resp.headers.get("X-WP-Stale")) { lastSaved = resp.headers.get("X-WP-Saved-At") || lastSaved; if (offline) savedAt = lastSaved; return; }   // saved copy, fresh one on its way
    else live();
    bar();
  }
  function live() { const was = offline; offline = false; savedAt = null; if (was || read().length) flush(); warm(); bar(); }
  let freshUntil = 0, redraw = null, lastSaved = null;
  function wrote() { freshUntil = Date.now() + 6000; }                 // after a change: ask the PC first for a few seconds
  function wantFresh() { return on && Date.now() < freshUntil; }
  function onMessage(ev) {                 // news from the saved-app script
    const m = ev.data || {};
    if (m.type === "offline") { offline = true; savedAt = savedAt || lastSaved; bar(); }
    else if (m.type === "online") live();
    else if (m.type === "signedout") { if (!location.pathname.startsWith("/phone-login")) location.href = "/phone-login"; }
    else if (m.type === "fresh") {         // newer data arrived behind the saved copy: redraw, unless you're in the middle of something
      clearTimeout(redraw);
      redraw = setTimeout(() => {
        const a = document.activeElement, typing = a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName);
        if (document.querySelector(".modal") || typing || !window.Router) return;
        Router.render();
      }, 200);
    }
  }

  async function warm() {                  // keep the saved copies fresh (at most every 10 minutes)
    if (!on) return;
    if (!navigator.serviceWorker.controller) {                                     // first visit: wait until the app is saved on the phone
      navigator.serviceWorker.addEventListener("controllerchange", () => warm(), { once: true }); return;
    }
    try { if (Date.now() - (+localStorage.getItem(WARMKEY) || 0) < 600e3) return; localStorage.setItem(WARMKEY, String(Date.now())); } catch (e) { return; }
    const get = u => fetchT("/api" + u, { headers: { "X-WulfProtocol": "1" } }, 8000).then(r => r.ok ? r.json() : null).catch(() => null);
    const meds = await get("/meds?all=1");
    for (const u of ["/dashboard", "/settings", "/version", "/route-types", "/profile", "/metrics", "/events", "/library", "/inventory", "/phone", "/backups", "/autostart"]) await get(u);
    for (const m of meds || []) await get("/meds/" + m.id);
  }

  function bar() {
    if (!on) return;
    let el = document.getElementById("offbar");
    const n = read().length;
    if (!offline && !n && !needLogin) { if (el) el.remove(); document.body.classList.remove("has-offbar"); return; }
    if (!el) { el = document.createElement("div"); el.id = "offbar"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    document.body.classList.add("has-offbar");
    const waiting = n ? ` · <b>${n} waiting to sync</b>` : "";
    el.className = offline ? "off" : "on";
    el.innerHTML = needLogin ? `🔐 Enter your PIN to sync ${n} change${n === 1 ? "" : "s"} from this phone. <a href="/phone-login">Sign in</a>`
      : offline ? `📴 Offline${savedAt ? " · showing your data from " + esc(rel(savedAt.slice(0, 16))) : ""}. Doses and weigh-ins you log are kept on this phone${waiting}.`
      : `⏳ Syncing with your PC${waiting} <button class="btn sm" type="button" id="offsync">Sync now</button>`;
    const b = document.getElementById("offsync"); if (b) b.onclick = flush;
  }

  if (on) {
    navigator.serviceWorker.register("/sw.js").catch(() => { /* stays online-only */ });
    navigator.serviceWorker.addEventListener("message", onMessage);
    window.addEventListener("online", flush);
    document.addEventListener("visibilitychange", () => { if (!document.hidden) flush(); });
    setInterval(() => { if (read().length) flush(); }, 30000);
    window.addEventListener("load", bar);
  }
  return { on, canQueue, queue, remove, pending, count, flush, mark, warm, decorate, wrote, wantFresh };
})();
