"""Use WulfProtocol from a phone on the same home Wi-Fi.

Off unless switched on in Settings. When on, a second door into the same app opens on the home network (port PORT+1).
Everything that comes in through that door must sign in with a PIN first; the normal PC address (127.0.0.1) is unchanged.
The PIN is stored only as a hash. Five wrong PINs lock the phone door for 10 minutes. A few PC-only actions (quit, updates,
installing the browser, start-with-Windows, changing phone access) are refused from a phone.

Offline mode (optional) switches the door to a secure https address using a private certificate made on this PC
(phonecert.py), so the phone can save the app and log doses away from home; they sync when it's back on the Wi-Fi.
"""
import hmac
import ipaddress
import os
import re
import secrets
import socket
import ssl
import subprocess
import sys
import threading
import time

from itsdangerous import BadSignature, URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.serving import make_server

import db
import phonecert

COOKIE = "wp_phone"
COOKIE_DAYS = 30
MAX_TRIES, LOCK_SECONDS, LOCK_MAX = 5, 600, 86400      # 5 wrong PINs: 10 minutes, then 20, 40 ... up to a day, until the right PIN
PC_ONLY = ("/api/shutdown", "/api/update", "/api/install-browser", "/api/autostart", "/api/phone", "/api/bitwarden",
           "/api/signin-all", "/api/login-window", "/api/reminders")
PC_ONLY_RE = re.compile(r"^/api/sources/\d+/(open|login|pick)$")       # these open a window on the PC
OPEN_PATHS = ("/phone-login", "/api/phone-login", "/static/style.css", "/static/fonts/", "/favicon", "/phone-ca.crt", "/sw.js",
              "/static/manifest.webmanifest", "/static/icon-", "/static/favicon")
SECRET_KEYS = ("phone_pin_hash", "phone_secret", "phone_pin_ver")   # never exported or shown

_state = {"server": None, "thread": None, "error": "", "port": None, "tries": 0, "locked_until": 0.0, "secure": False, "ips": [],
          "install": "idle", "install_msg": "", "watch": False, "locks": 0}
_lock = threading.Lock()


def _get(k, default=""):
    r = db.q("SELECT value FROM settings WHERE key=?", (k,))
    return r[0]["value"] if r else default


def _put(k, v):
    db.x("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)", (k, str(v)))


def _secret():
    s = _get("phone_secret")
    if not s:
        s = secrets.token_hex(32)
        _put("phone_secret", s)
    return s


def _signer():
    return URLSafeTimedSerializer(_secret(), salt="wp-phone")


def enabled():
    return _get("phone_on", "0") == "1" and bool(_get("phone_pin_hash"))


def lan_ip():
    """This PC's address on the home network (nothing is sent; the UDP 'connect' only picks a route)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return ""


def secure_wanted():
    return _get("phone_secure", "0") == "1"


def status(port):
    running = bool(_state["server"])
    ip = lan_ip()
    sec = running and _state["secure"]
    scheme = "https" if sec else "http"
    hn = phonecert.host_name() if sec else ""
    ip_addr = f"{scheme}://{ip}:{port}" if ip else ""
    return {"on": _get("phone_on", "0") == "1", "has_pin": bool(_get("phone_pin_hash")), "running": running,
            "port": port, "ip": ip, "address": (f"https://{hn}:{port}" if hn else ip_addr), "ip_address": ip_addr,
            "error": _state["error"], "secure": sec, "secure_wanted": secure_wanted(), "host": hn,
            "install": _state["install"], "install_msg": _state["install_msg"], "cert_tool": phonecert.available()}


def set_pin(pin):
    pin = str(pin or "").strip()
    if not (pin.isdigit() and 4 <= len(pin) <= 8):
        raise ValueError("The PIN must be 4 to 8 numbers.")
    _put("phone_pin_hash", generate_password_hash(pin))
    _put("phone_pin_ver", int(_get("phone_pin_ver", "0") or 0) + 1)   # a new PIN signs every phone out
    _state.update(tries=0, locked_until=0.0, locks=0)


def sign_out_all():
    _put("phone_pin_ver", int(_get("phone_pin_ver", "0") or 0) + 1)


def try_login(pin):
    """Returns (cookie value or None, message)."""
    now = time.time()
    with _lock:
        if now < _state["locked_until"]:
            mins = int((_state["locked_until"] - now) // 60) + 1
            return None, (f"Too many wrong PINs. Try again in {mins} minute{'s' if mins > 1 else ''}." if mins < 120
                          else f"Too many wrong PINs. Try again in about {mins // 60} hours.")
        h = _get("phone_pin_hash")
        if h and check_password_hash(h, str(pin or "").strip()):
            _state.update(tries=0, locks=0)
            return _signer().dumps({"v": _get("phone_pin_ver", "0")}), ""
        _state["tries"] += 1
        if _state["tries"] >= MAX_TRIES:
            secs = min(LOCK_SECONDS * 2 ** _state["locks"], LOCK_MAX)        # each lock-out is twice as long as the last
            _state.update(tries=0, locked_until=now + secs, locks=_state["locks"] + 1)
            mins = secs // 60
            return None, f"Too many wrong PINs. Phone sign-in is locked for {mins} minutes." if mins < 120 else f"Too many wrong PINs. Phone sign-in is locked for {mins // 60} hours."
        left = MAX_TRIES - _state["tries"]
        return None, f"Wrong PIN. {left} tr{'ies' if left > 1 else 'y'} left."


def cookie_ok(value):
    if not value:
        return False
    try:
        data = _signer().loads(value, max_age=COOKIE_DAYS * 86400)
    except BadSignature:
        return False
    return hmac.compare_digest(str(data.get("v")), str(_get("phone_pin_ver", "0")))


def check(request):
    """Called for every request. None = carry on; otherwise ('login'|'pc_only'|'off')."""
    if not request.environ.get("wp.phone"):
        return None
    if not enabled():
        return "off"
    p = request.path
    if ".." in p or "\\" in p or "%" in p:                 # no path tricks to slip past the PIN
        return "login" if not cookie_ok(request.cookies.get(COOKIE)) else None
    if any(p == o or (o.endswith(("/", "-")) and p.startswith(o)) or (o in ("/favicon", "/static/favicon") and p.startswith(o)) for o in OPEN_PATHS):
        return None
    if not cookie_ok(request.cookies.get(COOKIE)):
        return "login"
    if (any(p == x or p.startswith(x + "/") for x in PC_ONLY) or PC_ONLY_RE.match(p)) and request.method != "GET":
        return "pc_only"
    return None


def host_ok(host):
    """True when the address the browser asked for is really this PC: 127.0.0.1 / localhost, a home-network number, or
    this PC's own name. A website elsewhere can trick a browser into pointing its own name at this PC ("DNS rebinding");
    such requests arrive with that website's name here and are refused."""
    h = (host or "").strip().lower()
    if h.startswith("["):                                    # [::1]:8765
        h = h[1:].split("]")[0]
    elif h.count(":") == 1:
        h = h.split(":")[0]
    if h in ("localhost", ""):
        return h == "localhost"
    try:
        ip = ipaddress.ip_address(h)
        return ip.is_loopback or ip.is_private
    except ValueError:
        pass
    me = (socket.gethostname() or "").split(".")[0].lower()
    return bool(me) and h in (me, me + ".local")


class _PhoneDoor:
    """Marks requests that came in through the home-network door."""
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        environ["wp.phone"] = True
        return self.app(environ, start_response)


def start(app, port):
    with _lock:
        if _state["server"]:
            return
        ctx, ips, secure = None, [], False
        if secure_wanted() and phonecert.available():
            try:
                ips = [lan_ip()] if lan_ip() else []
                cp, kp, _ = phonecert.ensure_leaf(ips)
                ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                ctx.minimum_version = ssl.TLSVersion.TLSv1_2
                ctx.load_cert_chain(cp, kp)
                secure = True
            except Exception as e:  # noqa: BLE001
                _state["error"] = f"Couldn't set up the secure phone address ({e}). Phone access is running without offline mode."
                ctx = None
        try:
            srv = make_server(os.environ.get("PHONE_HOST", "0.0.0.0"), port, _PhoneDoor(app), threaded=True, ssl_context=ctx)
        except OSError as e:
            _state["error"] = f"Couldn't open phone access on port {port} ({e.strerror or e}). Another program may be using it."
            return
        if secure or not secure_wanted():
            _state["error"] = ""
        _state.update(server=srv, port=port, secure=secure, ips=ips)
        t = threading.Thread(target=srv.serve_forever, daemon=True, name="phone-door")
        t.start()
        _state["thread"] = t


def stop(wait=False):
    with _lock:
        srv = _state["server"]
        _state.update(server=None, thread=None, secure=False)
    if srv:
        if wait:
            srv.shutdown(); srv.server_close()
        else:
            threading.Thread(target=lambda: (srv.shutdown(), srv.server_close()), daemon=True).start()


def restart(app, port):
    stop(wait=True)
    sync(app, port)


def sync(app, port):
    """Open or close the phone door to match the settings (and keep the secure address's certificate up to date)."""
    if enabled():
        if _state["server"] and _state["secure"] != (secure_wanted() and phonecert.available()):
            stop(wait=True)                                # switching between plain and secure
        start(app, port)
        _watch(app, port)
    else:
        stop()


def _watch(app, port):
    """Every 2 minutes: if the PC's home-network address changed, renew the secure address's certificate."""
    if _state["watch"]:
        return
    _state["watch"] = True

    def loop():
        while True:
            time.sleep(int(os.environ.get("WP_PHONE_WATCH", 120)))
            try:
                if _state["server"] and _state["secure"] and ([lan_ip()] if lan_ip() else []) != _state["ips"]:
                    restart(app, port)
            except Exception:
                pass
    threading.Thread(target=loop, daemon=True, name="phone-watch").start()


def set_secure(app, port, on):
    """Turn offline mode on/off. Turning it on installs the certificate tool first if it's missing (in the background)."""
    _put("phone_secure", "1" if on else "0")
    if not on or phonecert.available():
        if on:
            phonecert.ensure_ca()
        restart(app, port)
        return
    if _state["install"] == "running":
        return
    _state.update(install="running", install_msg="")

    def work():
        try:
            p = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "cryptography>=42"], capture_output=True, text=True, timeout=900)
            import importlib
            importlib.invalidate_caches()
            if p.returncode or not phonecert.available():
                raise RuntimeError("Couldn't install the certificate tool. Check your internet connection and try again.")
            phonecert.ensure_ca()
            _state.update(install="done", install_msg="")
            restart(app, port)
        except Exception as e:  # noqa: BLE001
            _state.update(install="error", install_msg=str(e)[:300])
    threading.Thread(target=work, daemon=True).start()
