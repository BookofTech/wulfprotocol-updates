var Pages = window.Pages || (window.Pages = {});
const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

/* ---------- shared actions (also used by the dashboard) */
async function quickLog(med_id, slot, status, taken_at) {
  await api("/logs", "POST", { med_id, slot, status, taken_at });
  toast(status === "taken" ? "Logged ✓" : "Skipped");
  Router.render();
}
// One-tap "I took it now": nearest open slot (within 6 h) else an extra dose; offers Undo.
async function takeNow(med_id) {
  const m = await api("/meds/" + med_id);
  const now = new Date(); let slot = null, best = 6 * 3600e3;
  (m.open_slots || []).forEach(sl => { const d = Math.abs(parseLocal(sl) - now); if (d < best) { best = d; slot = sl; } });
  const si = m.site_info;
  const r = await api("/logs", "POST", { med_id, slot, status: "taken", taken_at: nowLocalInput(), amount: m.dose, site: si ? si.suggest : null });
  undoToast(`Logged ${m.name}${si ? " · ★ " + si.suggest : ""}`, async () => { await api("/logs/" + r.id, "DELETE"); toast("Dose removed"); Router.render(); });
  Router.render();
}
function undoToast(msg, undo) {
  const t = document.createElement("div"); t.className = "toast";
  t.innerHTML = `${esc(msg)} <button class="btn sm" style="margin-left:10px">Undo</button>`;
  $("button", t).onclick = async () => { t.remove(); await undo(); };
  $("#toasts").appendChild(t); setTimeout(() => t.remove(), 8000);
}
function cycleBar(m) {
  const c = m.cycle; if (!c || !c.enabled || !c.phase) return "";
  const total = m.cycle_on + m.cycle_off;
  const pos = c.phase === "on" ? c.day_in_phase - 1 : m.cycle_on + c.day_in_phase - 1;
  return `<div style="position:relative;display:flex;height:8px;border-radius:99px;overflow:hidden;background:var(--bg)">
    <i style="width:${100 * m.cycle_on / total}%;background:var(--accent)"></i><i style="width:${100 * m.cycle_off / total}%;background:var(--line)"></i>
    <b style="position:absolute;left:calc(${100 * (pos + .5) / total}% - 5px);top:-1px;width:10px;height:10px;border-radius:50%;background:var(--ink);border:2px solid var(--card)"></b></div>`;
}
function cycleBadge(c) {
  if (!c) return "";
  if (c.state === "not_started") return `<span class="badge">Starts in ${c.starts_in}d</span>`;
  if (c.state === "ended") return `<span class="badge">Ended</span>`;
  if (!c.enabled) return c.days_to_end != null ? `<span class="badge acc">${c.days_to_end}d left</span>` : "";
  return c.phase === "on"
    ? `<span class="badge ok">ON · day ${c.day_in_phase}/${c.phase_length}</span>`
    : `<span class="badge warn">OFF · day ${c.day_in_phase}/${c.phase_length}</span>`;
}
function expiryBadge(m) {
  const e = m.expiry; if (!e) return "";
  if (e.days_left < 0) return '<span class="badge bad">Expired</span>';
  return e.low ? `<span class="badge bad">Expires in ${e.days_left}d</span>` : `<span class="badge">Use by ${fmtDate(e.expires_on)}</span>`;
}
function refillBlock(r, unit) {
  if (!r) return "";
  if (r.days_left == null) return `<div class="small muted">Stock: ${num(r.stock, 2)} ${esc(unit)} · ${r.doses_left} doses</div>`;
  const pct = Math.min(100, r.days_left / 30 * 100), cls = r.low ? (r.days_left <= 3 ? "bad" : "warn") : "ok";
  return `<div><div class="row spread small"><span class="muted">Supply</span><b>${r.days_left === 0 ? "runs out today" : r.days_left + " days left"}</b></div>
    <div class="bar ${cls}" style="margin-top:4px"><i style="width:${Math.max(4, pct)}%"></i></div>
    <div class="small muted" style="margin-top:3px">${num(r.stock, 2)} ${esc(unit)} left · out ${fmtDate(r.runs_out_on)}</div></div>`;
}
const siteLabel = m => m.route_type === "nasal" ? "nostril" : "site";

/* ---------- list */
Pages.meds = async function (view) {
  const [meds, dash] = await Promise.all([api("/meds?all=1"), api("/dashboard").catch(() => null)]);
  const todayRow = (i, late) => { const done = i.status === "taken" || i.status === "skipped";
    return `<div class="li ${late ? "missed" : ""}"><span class="dot" style="background:${i.color}"></span>
      <div class="grow"><span class="t">${i.route_icon || ""} ${esc(i.name)}</span> <span class="m">${doseLine(i)}</span>${i.next_site && !done ? `<div class="m">★ ${esc(i.next_site)}</div>` : ""}</div>
      <span class="m">${late ? "Missed · " + dayLabel(i.slot) + " " : ""}${fmtTime(i.slot)}</span>${late ? "" : statusBadge(i.status)}
      ${done ? "" : `<button class="btn sm primary" data-tk="${i.med_id}|${i.slot}" data-sites="${i.has_sites ? 1 : ""}" data-late="${late ? 1 : ""}">✓ Take</button>`}</div>`; };
  const todayCard = dash && (dash.today.length || dash.missed.length) ? `<div class="card" style="margin-bottom:16px"><h2>Today</h2>
    <div class="list">${dash.missed.map(i => todayRow(i, true)).join("")}${dash.today.map(i => todayRow(i)).join("")}</div></div>` : "";
  view.innerHTML = `
    <div class="page-head"><div><h1>Medication</h1><p>Schedules, cycles, injection sites and supply for everything you take.</p></div>
      <div class="row" style="gap:8px"><button class="btn" id="quick">⚡ Quick add</button><button class="btn" id="mref">📖 Reference</button><button class="btn primary" id="add">+ Add medication</button></div></div>
    ${todayCard}
    ${meds.length ? `<div class="med-grid">${meds.map(m => { const si = m.site_info, r = routeOf(m); return `
      <div class="card med ${m.active ? "" : "paused"}" data-id="${m.id}">
        <div class="row"><span class="dot" style="background:${m.color}"></span><span class="name grow">${esc(m.name)}</span>
          <span class="badge" title="${esc(r.label)}">${r.icon} ${esc(r.short || m.kind)}</span></div>
        <dl class="kv"><dt>Dose</dt><dd>${m.dose != null ? num(m.dose, 3) + " " + esc(m.dose_unit) : "–"}${m.plan ? `<div class="small muted" style="font-weight:500">${m.plan.weekly ? "Week " + m.plan.week : "Day " + m.plan.day} of your plan${m.plan.next ? ` · ${num(m.plan.next.dose, 3)} ${esc(m.dose_unit)} from ${fmtDate(m.plan.next.on)}` : ""}</div>` : ""}</dd>
          <dt>Schedule</dt><dd>${esc(m.schedule_text)}</dd>
          <dt>Next dose</dt><dd>${m.active ? (m.next_dose ? dayLabel(m.next_dose) + ", " + fmtTime(m.next_dose) : "–") : "Paused"}</dd>
          ${si ? `<dt>Next ${siteLabel(m)}</dt><dd>★ ${esc(si.suggest)}${si.last_site ? `<div class="small muted" style="font-weight:500">last: ${esc(si.last_site)} · ${agoText(si.last_at)}</div>` : ""}</dd>` : ""}</dl>
        <div class="row wrap" style="gap:6px">${m.active ? cycleBadge(m.cycle) : ""} ${expiryBadge(m)}</div> ${cycleBar(m)}
        ${refillBlock(m.refill, m.dose_unit)}
        ${m.active ? `<button class="btn sm primary" data-now="${m.id}" style="margin-top:10px;width:100%">✓ Take now</button>` : ""}
      </div>`; }).join("")}</div>`
      : `<div class="card empty"><b>Nothing here yet</b>Add your first peptide or medication to start tracking doses.<br><br><button class="btn primary" id="add2">+ Add medication</button></div>`}`;
  const add = () => medForm();
  $("#quick", view).onclick = () => quickAddModal();
  $("#mref", view).onclick = () => refBrowser();
  $("#add", view).onclick = add; const a2 = $("#add2", view); if (a2) a2.onclick = add;
  $$(".med", view).forEach(c => c.onclick = e => { if (!e.target.closest("button")) location.hash = "#/meds/" + c.dataset.id; });
  $$("[data-now]", view).forEach(b => b.onclick = e => { e.stopPropagation(); run(b, () => takeNow(+b.dataset.now)); });
  $$("[data-tk]", view).forEach(b => b.onclick = () => {
    const [id, slot] = b.dataset.tk.split("|");
    run(b, () => b.dataset.sites || b.dataset.late ? openLogFor(+id, slot, b.dataset.late ? {} : { now: true }) : quickLog(+id, slot, "taken"));
  });
};

/* ---------- detail */
function siteCard(m) {
  const si = m.site_info; if (!si) return "";
  const nasal = m.route_type === "nasal";
  return `<div class="card"><h2>${nasal ? "Nostril rotation" : "Site rotation"} <button class="btn sm" id="editsites">Customize</button></h2>
    <div class="suggest"><div class="small muted" style="font-weight:700;letter-spacing:.06em">NEXT SUGGESTED</div>
      <div class="big">★ ${esc(si.suggest)}</div>
      <div class="small muted">${si.last_site ? `Last used: <b>${esc(si.last_site)}</b> · ${agoText(si.last_at)}` : "Nothing logged yet — this is where to start."}</div></div>
    ${si.sites.some(s => BODY[s.site]) ? bodyMap(si) : ""}
    <div class="scroll-x" style="margin-top:10px"><table><thead><tr><th>${nasal ? "Nostril" : "Site"}</th><th>Last used</th><th class="r">Times</th></tr></thead><tbody>
      ${si.sites.map(s => `<tr><td>${s.site === si.suggest ? "★ " : ""}${esc(s.site)}</td><td class="muted">${agoText(s.last)}</td><td class="r">${s.count}</td></tr>`).join("")}</tbody></table></div></div>`;
}
function fxChips(l) {
  let a = []; try { a = l.effects ? JSON.parse(l.effects) : []; } catch (e) {}
  return a.map(x => `<span class="badge warn" style="margin-right:4px">${esc(x)}</span>`).join("");
}
function effectsCard(m) {
  const c = m.effect_counts || []; if (!c.length) return "";
  const n = m.effect_doses || 1;
  return `<div class="card"><h2>Things you noted</h2>${c.map(([k, v]) => `<div class="fxbar"><span style="min-width:110px">${esc(k)}</span><span class="bar"><i style="width:${Math.min(100, Math.round(100 * v / n))}%"></i></span><span class="muted nowrap">${v} of ${n} doses</span></div>`).join("")}
    <p class="small muted" style="margin:8px 0 0">Counted from the "Anything to note?" taps when you log a dose.</p></div>`;
}
function planCard(m) {
  const p = m.plan, canFind = !p && m.reference_obj && parsePhases(m.reference_obj.dosage, m.dose_unit).length;
  if (!p && !canFind) return `<div class="card"><h2>Dose steps</h2><p class="muted" style="margin-top:0">Raise (or lower) the dose week by week and let the app change it for you.</p><button class="btn sm" id="plan">＋ Set up dose steps</button></div>`;
  if (!p) return `<div class="card"><h2>Dose steps</h2><p class="muted" style="margin-top:0">The reference sheet has a week-by-week plan for this. Want the app to follow it?</p><button class="btn sm primary" id="plan">📈 Review the sheet's steps</button></div>`;
  const day = d => { const x = parseLocal(p.start + "T00:00"); x.setDate(x.getDate() + d); return x; };
  const sd = d => day(d).toLocaleDateString([], { month: "short", day: "numeric" });
  const drawFor = dose => { const d = drawInfo({ ...m, dose }); return d && !d.error ? `${num(d.units, 1)} ${d.pen ? "clicks" : "units"}` : ""; };
  const hasDraw = p.steps.some(x => drawFor(x.dose)), hasFreq = p.steps.some(x => x.schedule);
  const rows = p.steps.map((x, i) => {
    const nx = p.steps[i + 1], to = nx ? nx.from_day - 1 : x.to_day || null;
    const wk = stepLabel(x, nx);
    const dates = to == null ? `from ${sd(x.from_day - 1)}` : `${sd(x.from_day - 1)} – ${sd(to - 1)}`;
    const now = i === p.current && !p.finished;
    return `<tr style="${now ? "font-weight:800;background:var(--accent-soft)" : p.finished || i < p.current ? "opacity:.6" : ""}"><td>${wk}${now ? " ← now" : ""}<div class="small muted" style="font-weight:500">${dates}</div></td>
      <td class="r">${num(x.dose, 3)} ${esc(m.dose_unit)}</td>${hasFreq ? `<td class="r small">${esc(x.text || "")}</td>` : ""}${hasDraw ? `<td class="r">${drawFor(x.dose)}</td>` : ""}</tr>`; }).join("");
  return `<div class="card"><h2>Your plan <span class="badge">${p.finished ? "Finished" : p.weekly ? "Week " + p.week : "Day " + p.day}</span> <button class="btn sm" id="plan">Edit</button></h2>
    <div class="scroll-x"><table><thead><tr><th>When</th><th class="r">Dose</th>${hasFreq ? '<th class="r">How often</th>' : ""}${hasDraw ? `<th class="r">${m.container === "pen" ? "Dial" : "Draw"}</th>` : ""}</tr></thead><tbody>${rows}</tbody></table></div>
    <div class="planbar">${(() => { const el = p.end_day ? (p.end_day % 7 === 0 && p.weekly ? "week " + p.end_day / 7 : "day " + p.end_day) : ""; return p.finished ? `The plan ended after ${el}. Edit it to start another.` : `<b>Today (${p.weekly ? "week " + p.week : "day " + p.day}): ${num(p.dose, 3)} ${esc(m.dose_unit)}.</b> ` + (p.next ? `It changes to ${num(p.next.dose, 3)} ${esc(m.dose_unit)} on ${fmtDate(p.next.on)}.` : el ? `Last step. The plan ends after ${el}.` : "You're on the last step."); })()}</div>
    ${p.finished ? "" : `<div class="row wrap" style="gap:8px;margin-top:10px"><button class="btn sm" data-pa="hold" title="Stay on today's step a little longer. Later steps slide back${p.weekly ? " a week" : " a day"}.">⏸ Stay on this step another ${p.weekly ? "week" : "day"}</button>${p.current > 0 ? `<button class="btn sm" data-pa="back" title="Restart from the previous step">↩ Go back a step</button>` : ""}</div>`}</div>`;
}

function drawCard(m) {
  const d = drawInfo(m); if (!d) return "";
  if (d.error) return `<div class="card"><h2>Draw amount</h2><div class="alert">${esc(d.error)}</div></div>`;
  const what = "vial";
  return `<div class="card"><h2>${d.pen ? "Dial on your pen" : "Draw amount"}</h2><div class="big">${num(d.units, 1)} ${d.custom ? "clicks" : "units"}</div>
    <div class="muted">${d.pen ? `${d.custom ? `at ${num(d.perClick, 3)} ${esc(m.dose_unit)} per click` : `${num(d.units, 1)} clicks`}${d.ml != null ? ` · ${num(d.ml, 3)} mL` : ""}` : `${num(d.ml, 3)} mL on a U-100 insulin syringe`}</div>
    ${d.conc != null ? `<div class="small muted" style="margin-top:6px">${num(d.conc, 2)} ${esc(m.dose_unit)}/mL · ${d.pen && +m.diluent_ml === 3 ? `about ${Math.floor(d.doses)} doses per cartridge` : `about ${Math.floor(d.doses)} doses per vial${d.pen && d.cartDoses ? ` · about ${Math.floor(d.cartDoses)} per full 3 mL cartridge` : ""}`}</div>` : ""}
    ${d.pen && Math.abs(d.units - Math.round(d.units)) > 0.05 ? `<div class="small" style="margin-top:6px">A pen dials whole clicks: <b>${Math.floor(d.units)}</b> clicks = ${num(Math.floor(d.units) * d.perClick, 1)} ${esc(m.dose_unit)}, <b>${Math.ceil(d.units)}</b> clicks = ${num(Math.ceil(d.units) * d.perClick, 1)} ${esc(m.dose_unit)}.</div>` : ""}
    <p class="small muted" style="margin-bottom:0">${d.custom ? "Calculated from the click size you set for your pen." : "Calculated from the strength you entered."} Always double-check against your own protocol or prescriber.</p>
    ${d.pen ? `<button class="btn sm" id="clickedit" style="margin-top:8px">✎ Not the right number of clicks?</button>` : ""}</div>`;
}

Pages.med = async function (view, id) {
  const m = await api("/meds/" + id);
  const s = m.stats, r = routeOf(m), e = m.expiry;
  view.innerHTML = `
    <div class="page-head"><div><a href="#/meds" class="small">← All medication</a>
      <h1 class="row" style="margin-top:6px"><span class="dot" style="background:${m.color}"></span>${esc(m.name)} ${cycleBadge(m.cycle)}${m.active ? "" : ' <span class="badge">Paused</span>'}</h1>
      <p>${r.icon} ${esc(r.label)} · ${m.dose != null ? num(m.dose, 3) + " " + esc(m.dose_unit) : ""} · ${esc(m.schedule_text)}${m.notes ? "<br>" + esc(m.notes) : ""}</p></div>
      <div class="row wrap"><button class="btn primary" id="log">Log dose</button><button class="btn" id="restock">Restock</button>
        <button class="btn" id="edit">Edit</button><button class="btn" id="pause">${m.active ? "Pause" : "Resume"}</button><button class="btn danger" id="del">Delete</button></div></div>
    <div class="grid tiles">
      <div class="tile"><div class="k">Doses logged</div><div class="v">${s.total_taken}</div></div>
      <div class="tile ${s.pct != null && s.pct < 80 ? "warn" : "ok"}"><div class="k">30-day adherence</div><div class="v">${s.pct == null ? "–" : s.pct + "%"}</div><div class="s">${s.taken} taken · ${s.missed} missed · ${s.skipped} skipped</div></div>
      <div class="tile ${m.refill && m.refill.low ? "bad" : ""}"><div class="k">Supply</div><div class="v">${m.refill ? (m.refill.days_left != null ? m.refill.days_left + "d" : m.refill.doses_left + " doses") : "–"}</div><div class="s">${m.refill ? num(m.refill.stock, 2) + " " + esc(m.dose_unit) + " left" : "Stock not tracked"}</div></div>
      ${e ? `<div class="tile ${e.low ? "bad" : ""}"><div class="k">Vial / bottle</div><div class="v">${e.days_left < 0 ? "Expired" : e.days_left + "d"}</div><div class="s">${e.days_left < 0 ? "expired " : "use by "}${fmtDate(e.expires_on)}</div></div>` : ""}
      <div class="tile"><div class="k">Cycle</div><div class="v" style="font-size:1.3rem">${m.cycle.enabled && m.cycle.phase ? (m.cycle.phase === "on" ? "On" : "Off") + " · day " + m.cycle.day_in_phase : m.cycle.state === "not_started" ? "Not started" : "No cycle"}</div>
        <div class="s">${m.cycle.enabled && m.cycle.phase ? `${m.cycle.days_left_in_phase === 0 ? "last day — " : ""}${m.cycle.next_phase.toUpperCase()} starts ${fmtDate(m.cycle.next_change)} · cycle #${m.cycle.cycle_number}` : (m.cycle.days_to_end != null ? m.cycle.days_to_end + " days until end date" : "")}</div></div>
    </div>
    ${m.cycle.enabled && m.cycle.phase ? `<div class="card" style="margin-bottom:16px"><h2>Cycle position <span class="small muted">${m.cycle_on} days on / ${m.cycle_off} days off</span></h2>${cycleBar(m)}</div>` : ""}
    <div class="grid cols-2">
      <div class="card"><h2>Dose history</h2>
        ${m.logs.length ? `<div class="scroll-x"><table><thead><tr><th>When</th><th>Status</th><th>Amount</th><th>${m.route_type === "nasal" ? "Nostril" : "Site"}</th><th>Notes</th><th></th></tr></thead><tbody>
          ${m.logs.map(l => `<tr><td class="nowrap">${fmtDateTime(l.taken_at)}${l.slot ? "" : ' <span class="badge">extra</span>'}</td>
            <td><span class="badge ${l.status === "taken" ? "ok" : "warn"}">${l.status}</span></td>
            <td>${l.amount != null ? num(l.amount, 3) + " " + esc(m.dose_unit) : ""}</td><td>${esc(l.site || "")}</td><td>${fxChips(l)}${esc(l.notes || "")}</td>
            <td class="r"><button class="btn ghost sm" data-dl="${l.id}" title="Delete entry">✕</button></td></tr>`).join("")}</tbody></table></div>`
        : '<div class="empty">No doses logged yet.</div>'}</div>
      <div class="stack">${planCard(m)}${siteCard(m)}${drawCard(m)}${effectsCard(m)}${refCard(m)}<div class="card"><h2>Doses per week</h2><div class="chart-host" id="wk"></div></div></div>
    </div>`;
  Charts.bars($("#wk", view), m.weekly.map(w => ({ label: fmtDate(w.week), value: w.count })), { color: m.color });
  $("#log", view).onclick = () => logDoseModal(m);
  const pb = $("#plan", view); if (pb) pb.onclick = () => stepsModal(m);
  $$("[data-pa]", view).forEach(b => b.onclick = async () => {
    const back = b.dataset.pa === "back";
    if (back && !(await confirmBox(`Go back to the previous step (${num(m.plan.steps[m.plan.current - 1].dose, 3)} ${m.dose_unit}) and count your plan from today?`, "Go back"))) return;
    await run(b, async () => { await api(`/meds/${m.id}/plan-action`, "POST", { action: b.dataset.pa }); toast(back ? "Back on the previous step" : "Holding this step one more week"); Router.render(); });
  });
  $("#restock", view).onclick = () => restockModal(m);
  $("#edit", view).onclick = () => medForm(m);
  const ce = $("#clickedit", view); if (ce) ce.onclick = () => clickModal(m);
  const es = $("#editsites", view); if (es) es.onclick = () => sitesModal(m);
  $("#pause", view).onclick = async () => { await api("/meds/" + id, "PUT", { active: !m.active }); Router.render(); };
  $("#del", view).onclick = async () => {
    if (await confirmBox(`Delete ${m.name} and its entire dose history? This can't be undone. (Use Pause to keep the history.)`)) {
      await api("/meds/" + id, "DELETE"); location.hash = "#/meds";
    }
  };
  $$("[data-dl]", view).forEach(b => b.onclick = async () => { await api("/logs/" + b.dataset.dl, "DELETE"); toast("Entry removed"); Router.render(); });
};

/* ---------- modals */
function logDoseModal(m, preset = {}) {
  const slots = m.open_slots || [], si = m.site_info, draw = drawInfo(m);
  const pen = !!(draw && !draw.error && draw.pen), perClick = pen ? draw.conc * 0.01 : 0;   // dose units per click
  const sel = preset.slot || "";
  const fx = [...new Set([...effectList(m), ...(m.effect_counts || []).map(x => x[0])])];
  const initTime = preset.now || !preset.slot ? nowLocalInput() : (parseLocal(preset.slot) > new Date() ? nowLocalInput() : preset.slot);
  modal(`<h2>${routeOf(m).icon} Log dose — ${esc(m.name)}</h2>
    ${pen ? `<div class="alert info" style="margin-bottom:12px;text-align:center"><div class="small">Dial your pen to</div><div style="font-size:1.8rem;font-weight:800;line-height:1.2">${num(draw.units, 1)} units</div><div class="small">${num(draw.units, 1)} clicks · ${num(draw.ml, 3)} mL · ${num(m.dose, 3)} ${esc(m.dose_unit)}</div></div>`
      : draw && !draw.error ? `<div class="alert info" style="margin-bottom:12px">${drawText(draw)}</div>` : ""}
    <form id="f" class="form-grid">
      <label class="f full">Which dose?<select name="slot"><option value="">Extra / as-needed dose</option>
        ${slots.map(s => `<option value="${s}" ${s === sel ? "selected" : ""}>${dayLabel(s)} ${fmtTime(s)}</option>`).join("")}</select></label>
      ${si ? `<div class="f full"><span>${m.route_type === "nasal" ? "Which nostril?" : "Injection site"} <span class="muted" style="font-weight:400">— ★ is the suggested rotation</span></span>${siteChips(si, si.suggest)}
        <input name="site_custom" placeholder="Somewhere else? Type it here (optional)" style="margin-top:8px"></div>` : ""}
      <label class="f">Status<select name="status"><option value="taken">Taken</option><option value="skipped">Skipped</option></select></label>
      ${pen ? `<label class="f">Units dialed (clicks)<input type="number" step="1" min="0" name="units" id="units" value="${Math.round(draw.units)}"><span class="small muted" id="units-eq"></span></label><input type="hidden" name="amount" value="${m.dose ?? ""}">`
        : `<label class="f">Amount (${esc(m.dose_unit)})<input type="number" step="any" name="amount" value="${m.dose ?? ""}"></label>`}
      <div class="f full"><span>When taken</span><div class="row" style="gap:6px"><input type="date" name="taken_date" value="${initTime.slice(0, 10)}" required style="flex:1"><input type="time" name="taken_time" value="${initTime.slice(11, 16)}" style="flex:1"><button type="button" class="btn ghost sm" id="notime" title="Don't record a time">✕</button></div><span class="small muted">Don't know the time? Press ✕ to leave it out.</span></div>
      ${fx.length ? `<div class="f full" id="fxwrap"><span>Anything to note? <span class="muted" style="font-weight:400">— tap any that apply</span></span><div class="chips-fx">${fx.map(x => `<label><input type="checkbox" name="fx" value="${esc(x)}"><span>${esc(x)}</span></label>`).join("")}</div></div>` : ""}
      <label class="f full">Notes<input name="notes" placeholder="optional"></label>
      <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div>
    </form>`, {
    onMount: (el, close) => {
      $("#notime", el).onclick = () => { $("[name=taken_time]", el).value = ""; };
      const un = $("#units", el), amt = $("[name=amount]", el);
      if (un) { const eq = () => { const a = +un.value * perClick; amt.value = +a.toFixed(4); $("#units-eq", el).textContent = `= ${num(a, 3)} ${m.dose_unit} · ${num(+un.value * 0.01, 3)} mL`; }; un.oninput = eq; eq(); }
      $("#f", el).onsubmit = async e => {
      e.preventDefault();
      const f = Object.fromEntries(new FormData(e.target)); delete f.units; delete f.fx;
      f.effects = $$("[name=fx]:checked", e.target).map(i => i.value);
      f.taken_at = f.taken_date ? f.taken_date + (f.taken_time ? "T" + f.taken_time : "") : ""; delete f.taken_date; delete f.taken_time;
      f.site = f.status === "skipped" ? null : ((f.site_custom || "").trim() || f.site || null);
      delete f.site_custom;
      await run($(".primary", el), async () => { await api("/logs", "POST", { med_id: m.id, ...f }); close(); toast("Dose logged"); Router.render(); });
      };
    },
  });
}
// Dashboard version: needs the med's open slots / site info, so fetch them first.
async function openLogFor(med_id, slot, opts = {}) {
  const m = await api("/meds/" + med_id);
  logDoseModal(m, { slot, ...opts });
}

function restockModal(m) {
  const vial = vialInDoseUnit(m), hasExp = routeOf(m).expiry;
  modal(`<h2>Restock — ${esc(m.name)}</h2>
    <form id="f" class="form-grid"><p class="muted full" style="margin:0">Currently ${m.stock_qty != null ? num(m.stock_qty, 2) : "not tracked"} ${esc(m.dose_unit)}.</p>
      <label class="f">Quantity (${esc(m.dose_unit)})<input type="number" step="any" name="qty" required value="${vial ? +vial.toFixed(3) : ""}"></label>
      <label class="f">Mode<select name="mode"><option value="add">Add to current stock</option><option value="set">Set stock to this number</option></select></label>
      ${hasExp ? `<label class="chk full"><input type="checkbox" name="new_vial" ${m.use_within_days ? "checked" : ""}> I opened a new vial / bottle today (restarts the expiry clock${m.use_within_days ? ": " + m.use_within_days + " days" : ""})</label>` : ""}
      <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Save</button></div></form>`, {
    onMount: (el, close) => $("#f", el).onsubmit = async e => {
      e.preventDefault();
      const f = Object.fromEntries(new FormData(e.target)); f.new_vial = !!f.new_vial;
      await run(null, async () => { await api(`/meds/${m.id}/restock`, "POST", f); close(); toast("Stock updated"); Router.render(); });
    },
  });
}

function sitesModal(m) {
  const sel = m.sites ? JSON.parse(m.sites) : null;
  modal(`<h2>Customize rotation — ${esc(m.name)}</h2>
    <p class="muted" style="margin-top:0">Untick any site you want to skip (bruised, sore, or not used for this). The suggestion always picks the one you've rested the longest.</p>
    <div class="daypick" id="rsites">${siteChecklist(m.route_type, sel)}</div>
    <div class="row" style="margin-top:10px"><input data-newsite placeholder="Add your own site…"><button type="button" class="btn sm" data-addsite>Add</button></div>
    <div class="actions"><button class="btn" data-close>Cancel</button><button class="btn" id="reset">Reset to default</button><button class="btn primary" id="save">Save</button></div>`, {
    onMount: (el, close) => {
      wireChecklist(el, m.route_type);

      $("#reset", el).onclick = async () => { await api("/meds/" + m.id, "PUT", { sites: null }); close(); Router.render(); };
      $("#save", el).onclick = async () => {
        const list = readChecklist(el, m.route_type);
        if (list && !list.length) return toast("Keep at least one site", true);
        await run(null, async () => { await api("/meds/" + m.id, "PUT", { sites: list }); close(); toast("Rotation saved"); Router.render(); });
      };
    },
  });
}

function clickModal(m) {
  const d = drawInfo(m), cur = d && !d.error ? +num(d.units, 2) : "";
  const mm = modal(`<h2>Your pen's clicks</h2>
    <p class="muted" style="margin-top:0">Your dose today is <b>${num(m.dose, 3)} ${esc(m.dose_unit)}</b>. How many clicks does your pen actually take for that?</p>
    <label class="f">Clicks for ${num(m.dose, 3)} ${esc(m.dose_unit)}<input type="number" step="any" min="0" id="cl" value="${cur}"></label>
    <p class="small muted" id="clh"></p>
    <div class="actions"><button class="btn" data-close>Cancel</button><button class="btn" id="clr">Use the standard</button><button class="btn primary" id="cls">Save</button></div>`, {
    onMount: el => {
      const hint = () => { const c = +$("#cl", el).value; $("#clh").textContent = c > 0 && +m.dose > 0 ? `So one click = ${num(m.dose / c, 3)} ${m.dose_unit}. Other doses in your plan use the same click size.` : ""; };
      $("#cl", el).oninput = hint; hint();
    } });
  $("#cls", mm.el).onclick = e => run(e.target, async () => {
    const c = +$("#cl", mm.el).value; if (!(c > 0)) throw new Error("Type how many clicks it takes.");
    await api("/meds/" + m.id, "PUT", { click_amt: +(m.dose / c).toFixed(4) }); mm.close(); toast("Saved"); Router.render(); });
  $("#clr", mm.el).onclick = e => run(e.target, async () => { await api("/meds/" + m.id, "PUT", { click_amt: null }); mm.close(); Router.render(); });
}

async function medForm(med, pre) {
  const R = App.routes;
  const m = med || { name: "", kind: "peptide", route_type: "subq", dose: "", dose_unit: R.subq.unit, schedule_obj: { type: "daily", times: ["08:00"] },
    start_date: todayStr(), end_date: "", cycle_on: 0, cycle_off: 0, stock_qty: "", refill_lead_days: 7, notes: "", ...((pre && pre.fields) || {}) };
  const sc = m.schedule_obj;
  const vialSum = m.vial_amount ? `${num(m.vial_amount, 3)} ${m.vial_unit || "mg"}${+m.diluent_ml ? " in " + num(m.diluent_ml, 3) + " mL" : ""}${m.container === "pen" ? " · pen" : ""}` : "optional — for syringe units / pen clicks";
  const cycSum = m.cycle_on ? `${m.cycle_on} on / ${m.cycle_off} off` : m.end_date ? "ends " + m.end_date : "none";
  const stockSum = m.stock_qty != null && m.stock_qty !== "" ? `${num(m.stock_qty, 2)} ${m.dose_unit || ""} on hand` : "not tracked";
  const expSum = m.use_within_days ? `use within ${m.use_within_days} days` : "optional";
  const lastMode = r => { try { return localStorage.getItem("wp_ctn_" + r); } catch (e) { return null; } };
  const ctnMode = m.container === "pen" ? (+m.diluent_ml === 3 ? "cart" : "vialpen") : (!med && !m.vial_amount ? (lastMode(m.route_type) || "vial") : "vial");
  let selSites = m.sites ? JSON.parse(m.sites) : null, prevType = m.route_type;
  const sup = await api(`/meds/${med ? med.id : 0}/supplies`).catch(() => []);
  let supFrom = null;
  if (!med) {                                     // a new medication starts with what you used for the last one taken the same way
    const ls = await api("/meds/last-supplies?route_type=" + encodeURIComponent(m.route_type || "")).catch(() => null);
    if (ls && ls.supplies.length) { supFrom = ls.from; ls.supplies.forEach(x => { const r = sup.find(y => y.id === x.id); if (r) r.per_dose = x.per_dose; }); }
  }
  const lib = await api("/library").catch(() => []);
  const libFind = n => { const k = String(n || "").trim().toLowerCase(); if (!k) return null;
    return lib.find(x => x.name.toLowerCase() === k) || lib.find(x => String(x.names || "").split(/[,;\n]/).some(a => a.trim().toLowerCase() === k)) || null; };
  const refItem = (pre && pre.reference) || libFind(m.name) || (med && med.reference_obj) || null;
  const supRow = s => `<div class="row" style="gap:8px;padding:6px 0;border-top:1px solid var(--line)" data-sup="${s.id}">
      <label class="chk grow"><input type="checkbox" ${s.per_dose ? "checked" : ""}> ${esc(s.name)} <span class="small muted">${num(s.qty, 2)} ${esc(s.unit || "")} on hand</span></label>
      <span class="small muted">uses</span><input type="number" step="any" min="0" value="${s.per_dose ?? 1}" style="width:80px" ${s.per_dose ? "" : "disabled"}><span class="small muted">each dose</span></div>`;
  modal(`<h2>${med ? "Edit" : "Add"} medication</h2>
    ${pre && pre.reference ? (() => { const f = pre.found || [], w = pre.warn || [];
      return `<div class="alert info" id="sheetread" style="margin-bottom:12px">
      <div class="row spread wrap" style="gap:8px"><span>⚡ <b>${esc(pre.reference.name)}</b> from your reference sheet${f.length ? ` · ${f.length}-step plan: ${num(f[0].dose, 3)} → ${num(f[f.length - 1].dose, 3)} ${esc(m.dose_unit)}` : ""}${w.length ? ` <span class="badge warn">⚠ ${w.length} to check</span>` : ""}</span>
        <button type="button" class="btn sm" id="sheetmore">Details</button></div>
      ${f.length ? `<label class="chk" style="margin-top:6px"><input type="checkbox" id="useplan" checked> Use the sheet's dose steps</label>` : ""}
      <div id="sheetdetails" style="display:none;margin-top:8px;font-weight:500">
        ${f.length ? `<div class="small">${stepSummary(f, m.dose_unit).map(esc).join("<br>")}</div><div class="small muted" style="margin:4px 0">Your dose${f.some(x => x.freq && x.freq !== "keep") ? " and how often you take it" : ""} will change by itself as the plan moves along. You can edit it later on the medication's page.</div>` : ""}
        ${pre.hint ? `<div class="small muted">${esc(pre.hint)}</div>` : ""}
        ${w.map(x => `<div class="small err2">⚠ ${esc(x)}</div>`).join("")}
        ${w.length ? `<div style="margin-top:6px"><button type="button" class="btn sm" id="fixsheet">✎ Fix it in the reference sheet</button></div>` : ""}</div></div>`; })() : ""}
    <div id="refban"></div>
    <form id="f" class="form-grid">
      <label class="f full">Name<input name="name" value="${esc(m.name)}" required placeholder="e.g. BPC-157"></label>
      <label class="f">How do you take it?<select name="route_type" id="rt">${Object.entries(R).map(([k, r]) => `<option value="${k}" ${m.route_type === k ? "selected" : ""}>${r.icon} ${esc(r.label)}</option>`).join("")}</select></label>
      <label class="f">Dose per administration<input type="number" step="any" name="dose" value="${m.dose ?? ""}" ${m.plan ? "readonly" : ""}>${m.plan ? '<span class="small muted">Set by your dose steps (see the medication page)</span>' : ""}</label>
      ${unitField("Unit", "dose_unit", m.dose_unit || "mg", ["mg", "mcg", "IU", "mL", "units", "sprays", "drops", "tablet", "capsule"])}
      <div class="full chiprow" id="dchips" style="display:none;margin-top:-6px"></div>

      <div class="full" data-sec="vial"><div class="f"><span>What do you have?</span>
        <div class="row wrap" id="cbuttons" style="gap:8px;margin-top:4px">
          <button type="button" class="btn" data-cm="vial">💉 Vial + syringe</button>
          <button type="button" class="btn" data-cm="cart">🖊 Peptide pen · 3 mL cartridge</button>
          <button type="button" class="btn" data-cm="vialpen">💉➜🖊 Vial loaded into a pen</button></div>
        <span class="small muted">Skip the strength below if you don't need syringe units or pen clicks.</span></div>
        <span id="use-w"><input type="hidden" name="usemode" id="usem" value="${ctnMode === "vialpen" ? "pen" : "syringe"}"></span><input type="hidden" name="ctnmode" id="ctn" value="${ctnMode === "cart" ? "cart" : "vial"}">
        <div class="form-grid" style="margin-top:12px"><div class="full" id="sheetline"></div>
        <label class="f full">The label shows<select name="labelmode" id="lblm"><option value="total">Total amount in it (e.g. 10 mg in 2 mL)</option><option value="perml">Amount per mL (e.g. 5 mg/mL)</option></select></label>
        <label class="f"><span data-ctn-label="size"></span><input type="number" step="any" name="vial_amount" value="${m.vial_amount ?? ""}" placeholder="e.g. 10"></label>
        <label class="f"><span id="unit-l">Unit</span><select name="vial_unit">${["mg", "mcg", "IU"].map(u => `<option ${(m.vial_unit || "mg") === u ? "selected" : ""}>${u}</option>`).join("")}</select></label>
        <label class="f" id="liquid-w"><span>Liquid in the vial (mL)</span><input type="number" step="any" name="diluent_ml" value="${m.diluent_ml ?? ""}" placeholder="e.g. 2"></label>
        <div class="full" id="vchips"></div>
        <details class="more acc full" id="click-w"><summary>🖊 Pen click size <span class="muted" id="clicksum"></span></summary><div class="form-grid" style="margin-top:12px">
          <label class="f">My dose takes (clicks)<input type="number" step="any" min="0" id="cpd" placeholder="e.g. 5"></label>
          <label class="f">One click is (<span id="click-u"></span>)<input type="number" step="any" min="0" name="click_amt" value="${m.click_amt ?? ""}" placeholder="auto"></label>
          <p class="small muted full" style="margin:0">Type either one and the other fills itself in. Leave both blank to use the standard (1 click = 0.01 mL). Count the clicks your pen really makes for the dose above.</p></div></details>
        <p class="small muted full" id="ctn-help" style="margin:0"></p></div></div>

      <details class="more acc full" id="schedbox" ${med ? "open" : ""}><summary>🗓 Schedule <span class="muted" id="schedsum"></span></summary><div class="form-grid" style="margin-top:12px">
      <label class="f">Schedule<select name="stype" id="stype">
        <option value="daily">Every day</option><option value="interval">Every N days</option>
        <option value="weekdays">Specific days of the week</option><option value="prn">As needed (no schedule)</option></select></label>
      <label class="f">Start date<input type="date" name="start_date" value="${m.start_date}" required></label>
      <label class="f" id="every-w">Every how many days?<input type="number" min="1" name="every" value="${sc.every || 2}"></label>
      <div class="f full" id="days-w"><span>Days</span><div class="daypick">${DAYS.map((d, i) => `<label><input type="checkbox" name="day" value="${i}" ${(sc.days || []).includes(i) ? "checked" : ""}>${d}</label>`).join("")}</div></div>
      <div class="f full" id="times-w"><span>Dose times</span><div id="times" class="row wrap"></div><button type="button" class="btn sm" id="addt" style="align-self:flex-start;margin-top:4px">+ Add time</button><span class="small muted" id="notime-h" style="display:none">No set time: it counts as due any time that day. Press + Add time to set one.</span></div></div></details>

      <fieldset class="sec" id="catchup" style="display:none"><legend>Started earlier? Catch up <span class="muted">(optional)</span></legend>
        <label class="chk"><input type="checkbox" id="cu-on" ${med ? "" : "checked"}> Count the doses since my start date as taken</label>
        <label class="f" style="margin-top:8px">How much did you have on the start date? <span class="muted">(${"in the dose unit, e.g. the whole vial or bottle"})</span><input type="number" step="any" id="cu-stock" placeholder="optional"></label>
        <div id="cu-prev" class="small" style="margin:8px 0"></div>
        <p class="small muted" style="margin:0">Assumes you took every scheduled dose since then. They're marked “added by catch-up” in the history so you can fix any you skipped. If you enter an amount, the app works out how much is left from it and uses that instead of “Stock on hand” below. Supplies like needles aren't changed.</p></fieldset>

      <div class="full acc-list">
      ${med ? "" : `<details class="more acc" id="moreopts"><summary>⚙ More options <span class="muted">cycle, stock, shelf life, rotation sites, supplies, notes</span></summary><div class="acc-list" style="margin-top:12px">`}
      <details class="more acc"><summary>🔁 Cycle &amp; end date <span class="muted">${cycSum}</span></summary><div class="form-grid" style="margin-top:12px">
        <label class="f">Cycle: days ON<input type="number" min="0" name="cycle_on" value="${m.cycle_on || ""}" placeholder="e.g. 28"></label>
        <label class="f">Cycle: days OFF<input type="number" min="0" name="cycle_off" value="${m.cycle_off || ""}" placeholder="e.g. 14"></label>
        <p class="small muted full" style="margin:-4px 0 0">Cycles count from the start date. Leave blank for continuous use. No doses are scheduled during OFF days.</p>
        <label class="f">End date (optional)<input type="date" name="end_date" value="${m.end_date || ""}"></label></div></details>

      <details class="more acc"><summary>📦 Stock &amp; refill warning <span class="muted">${stockSum}</span></summary><div class="form-grid" style="margin-top:12px">
        <label class="f">Stock on hand (dose unit)<input type="number" step="any" name="stock_qty" value="${m.stock_qty ?? ""}" placeholder="optional"></label>
        <label class="f">Refill warning (days before)<input type="number" min="0" name="refill_lead_days" value="${m.refill_lead_days ?? 7}"></label></div></details>

      <details class="more acc" data-sec="expiry"><summary>⏳ Vial / bottle shelf life <span class="muted">${expSum}</span></summary><div class="form-grid" style="margin-top:12px">
        <label class="f">Opened / mixed on<input type="date" name="opened_on" value="${m.opened_on || ""}"></label>
        <label class="f">Use within (days)<input type="number" min="1" name="use_within_days" value="${m.use_within_days ?? ""}" placeholder="e.g. 28"></label>
        <p class="small muted full" style="margin:0">You'll get a dashboard warning a few days before it expires. Use the label or your pharmacist's guidance for the number of days.</p></div></details>

      <details class="more acc" data-sec="sites"><summary>📍 Rotation sites <span class="muted">${m.sites ? "custom" : "all default sites"}</span></summary><div style="margin-top:12px">
        <div class="daypick" id="rsites"></div>
        <div class="row" style="margin-top:10px"><input data-newsite placeholder="Add your own site…"><button type="button" class="btn sm" data-addsite>Add</button></div></div></details>

      <details class="more acc"><summary>🧰 Supplies used with each dose <span class="muted">${sup.filter(x => x.per_dose).length ? sup.filter(x => x.per_dose).length + " ticked" + (supFrom ? " · same as " + esc(supFrom) : "") : "none"}</span></summary><div style="margin-top:12px">
        <p class="small muted" style="margin:0 0 6px">Tick what you use up every time you log a dose of this (a needle, a swab…). It comes off your Inventory by itself, and putting a dose back puts it back. How much medication is left is tracked separately.</p>
        <div id="sups">${sup.length ? sup.map(supRow).join("") : '<div class="small muted">No supplies in your Inventory yet. Add one below.</div>'}</div>
        <div class="row" style="margin-top:8px;gap:6px"><input id="newsup" placeholder="Add a supply, e.g. Pen needles 31G" class="grow"><input id="newsupunit" value="pcs" style="width:80px" title="Counted in"><button type="button" class="btn sm" id="addsup">Add</button></div></div></details>

      <details class="more acc"><summary>📝 Category &amp; notes <span class="muted">${esc(m.kind || "peptide")}${m.notes ? " · has notes" : ""}</span></summary><div class="form-grid" style="margin-top:12px">
        <label class="f">Category<select name="kind">${["peptide", "medication", "supplement", "other"].map(k => `<option ${m.kind === k ? "selected" : ""}>${k}</option>`).join("")}</select></label>
        <label class="f full">Notes<textarea name="notes">${esc(m.notes || "")}</textarea></label></div></details>
      ${med ? "" : "</div></details>"}
      </div>
      <div class="actions full"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">${med ? "Save" : "Add medication"}</button></div>
    </form>`, {
    wide: true,
    onMount: (el, close) => {
      const timesBox = $("#times", el);
      const addTime = (v = "08:00") => {
        const w = document.createElement("span"); w.className = "row"; w.style.gap = "4px";
        w.innerHTML = `<input type="time" class="t" value="${v}" style="width:130px"><button type="button" class="btn ghost sm" title="Remove">✕</button>`;
        $("button", w).onclick = () => { w.remove(); notimeHint(); };
        timesBox.appendChild(w);
      };
      const notimeHint = () => { const h = $("#notime-h", el); if (h) h.style.display = $$(".t", timesBox).length ? "none" : ""; };
      (sc.type === "prn" || (sc.times && sc.times.length) || !med ? (sc.times && sc.times.length ? sc.times : ["08:00"]) : []).forEach(addTime); notimeHint();
      $("#addt", el).onclick = () => { addTime("20:00"); notimeHint(); };
      const stype = $("#stype", el); stype.value = sc.type;
      const sync = () => {
        const t = stype.value;
        $("#every-w", el).style.display = t === "interval" ? "" : "none";
        $("#days-w", el).style.display = t === "weekdays" ? "" : "none";
        $("#times-w", el).style.display = t === "prn" ? "none" : "";
      };
      stype.onchange = sync; sync();

      // route type: show the sections that make sense, suggest a unit, rebuild the site list
      const rt = $("#rt", el);
      const refresh = changed => {
        const t = rt.value, r = R[t];
        $$("[data-sec]", el).forEach(s => { const k = s.dataset.sec; s.style.display = (k === "vial" ? r.vial : k === "sites" ? r.sites.length : r.expiry) ? "" : "none"; });
        if (changed) {
          const u = $("[name=dose_unit]", el); if (!u.value || u.value === R[prevType].unit) setUnitValue(el, "dose_unit", r.unit);
          selSites = null; prevType = t;
          if (r.vial && !med && ctn && ctn.value !== undefined) { const lm = lastMode(t); if (lm) setMode(lm); }
        }
        $("#rsites", el).innerHTML = siteChecklist(t, selSites);
      };
      rt.onchange = () => refresh(true); refresh(false);
      wireChecklist(el, m.route_type);
      bindUnits(el);
      const ctn = $("#ctn", el);
      const usem = $("#usem", el), lblm = $("#lblm", el);
      const ctnSync = () => {
        const cart = ctn.value === "cart", perml = lblm.value === "perml", dl = $("[name=diluent_ml]", el);
        $("#use-w", el).style.display = cart ? "none" : "";
        $("#liquid-w", el).style.display = cart ? "none" : "";
        const penOn = cart || usem.value === "pen"; $("#click-w", el).style.display = penOn ? "" : "none"; $("#click-u", el).textContent = ($("[name=dose_unit]", el) || {}).value || "";
        if (cart) dl.value = 3;
        const what = cart ? "the cartridge" : "the vial";
        $("[data-ctn-label=size]", el).textContent = perml ? "Strength (amount in each mL)" : `Total medication in ${what} (from the label)`;
        $("#unit-l", el).textContent = perml ? "Unit (per mL)" : "Unit";
        $("#ctn-help", el).textContent = cart ? "A ready-made cartridge holds 3 mL. A pen dials in units (1 unit = 1 click = 0.01 mL) and the app works out how many to dial for each dose."
          : usem.value === "pen" ? "The app works out the units to dial on your pen (1 unit = 1 click = 0.01 mL) from the strength of the liquid."
          : "The app works out how many syringe units to draw for each dose from the strength of the liquid.";
      };
      ctn.onchange = usem.onchange = ctnSync;
      const curMode = () => ctn.value === "cart" ? "cart" : usem.value === "pen" ? "vialpen" : "vial";
      const showMode = () => $$("[data-cm]", el).forEach(b => { b.classList.toggle("sel", b.dataset.cm === curMode()); });
      const setMode = mode => { ctn.value = mode === "cart" ? "cart" : "vial"; usem.value = mode === "vialpen" ? "pen" : "syringe"; ctn.dispatchEvent(new Event("change")); showMode(); };
      $$("[data-cm]", el).forEach(b => b.onclick = () => setMode(b.dataset.cm));
      showMode();
      let lastMode = lblm.value;
      lblm.onchange = () => {      // switch what the box means without losing the numbers
        const a = $("[name=vial_amount]", el), v = cart => cart ? 3 : +$("[name=diluent_ml]", el).value;
        const vol = v(ctn.value === "cart");
        if (a.value && vol > 0) a.value = +(lblm.value === "perml" ? a.value / vol : a.value * vol).toFixed(4);
        lastMode = lblm.value; ctnSync();
      };
      ctnSync();
      {
        const dose = $("[name=dose]", el), ca = $("[name=click_amt]", el), cpd = $("#cpd", el), cs = $("#clicksum", el);
        const sum = () => { cs.textContent = +ca.value > 0 ? `${num(ca.value, 3)} ${$("[name=dose_unit]", el).value} per click` : "standard"; };
        const fromDose = () => { cpd.value = +ca.value > 0 && +dose.value > 0 ? +(dose.value / ca.value).toFixed(2) : ""; sum(); };
        cpd.oninput = () => { if (+cpd.value > 0 && +dose.value > 0) ca.value = +(dose.value / cpd.value).toFixed(4); else if (!cpd.value) ca.value = ""; sum(); };
        ca.oninput = fromDose; dose.addEventListener("input", fromDose); fromDose();
      }
      const schedSum = () => {
        const f = $("#f", el), t = f.stype.value, times = $$(".t", timesBox).map(i => i.value).filter(Boolean).sort().map(v => { const [h, mi] = v.split(":"); return `${(+h % 12) || 12}:${mi} ${+h < 12 ? "AM" : "PM"}`; });
        const when = t === "prn" ? "As needed" : t === "interval" ? `Every ${f.every.value || "?"} days` : t === "weekdays" ? "Certain days" : "Every day";
        $("#schedsum", el).textContent = `${when}${times.length && t !== "prn" ? " at " + times.join(", ") : ""} · starts ${f.start_date.value ? fmtDate(f.start_date.value) : "today"}`;
      };
      $("#f", el).addEventListener("input", schedSum); $("#f", el).addEventListener("change", schedSum); $("#addt", el).addEventListener("click", () => setTimeout(schedSum, 0)); timesBox.addEventListener("click", () => setTimeout(schedSum, 0)); schedSum();

      // ---- fill-ins from the reference sheet
      const setVal = (name, v) => { const i = $(`[name=${name}]`, el); i.value = v; i.dispatchEvent(new Event("input", { bubbles: true })); };
      const chipsHtml = (list, attr, suffix) => list.map(v => `<button type="button" class="btn sm" ${attr}="${v}">${num(v, 3)}${suffix}</button>`).join(" ");
      const drawDoseChips = () => {
        const box = $("#dchips", el), u = $("[name=dose_unit]", el).value;
        const opts = refItem && !m.plan && !(pre && (pre.found || []).length) ? doseOptions(refItem.dosage, u) : [];
        box.style.display = opts.length ? "" : "none";
        box.innerHTML = opts.length ? `<span class="small muted">📖 Doses on the sheet — tap to use:</span> ${chipsHtml(opts, "data-dose", " " + esc(u))}` : "";
        $$("[data-dose]", box).forEach(b => b.onclick = () => setVal("dose", b.dataset.dose));
      };
      const drawVChips = () => {
        const cart = ctn.value === "cart", perml = lblm.value === "perml", vu = $("[name=vial_unit]", el).value;
        const sizes = { mg: [2, 5, 10, 15, 20, 30], mcg: [500, 1000, 5000], IU: [10, 30, 60] }[vu] || [];
        $("#vchips", el).innerHTML = (perml ? "" : `<div style="margin-bottom:6px"><span class="small muted">Common vial sizes:</span> ${chipsHtml(sizes, "data-vs", " " + esc(vu))}</div>`)
          + (cart ? "" : `<div><span class="small muted">Water added:</span> ${chipsHtml([1, 2, 3, 5, 10], "data-vw", " mL")}</div>`);
        $$("[data-vs]", el).forEach(b => b.onclick = () => setVal("vial_amount", b.dataset.vs));
        $$("[data-vw]", el).forEach(b => b.onclick = () => setVal("diluent_ml", b.dataset.vw));
      };
      const sl = refItem && refItem.reconstitute && !/^n\/?a\b/i.test(refItem.reconstitute.trim()) ? refItem.reconstitute.split("\n")[0] : "";
      $("#sheetline", el).innerHTML = sl ? `<div class="small muted">📖 Sheet says to mix with: <b>${esc(sl)}</b></div>` : "";
      ctn.addEventListener("change", drawVChips); lblm.addEventListener("change", drawVChips); $("[name=vial_unit]", el).addEventListener("change", drawVChips);
      $("[data-unitwrap=dose_unit] [data-unit]", el).addEventListener("change", () => setTimeout(drawDoseChips, 0));
      $("#rt", el).addEventListener("change", () => setTimeout(drawDoseChips, 0));
      drawVChips(); drawDoseChips();
      // adding by hand and the name matches a saved sheet: offer to start from it
      if (!med && !(pre && pre.reference)) {
        const nm = $("[name=name]", el), ban = $("#refban", el);
        nm.addEventListener("input", () => {
          const it = libFind(nm.value);
          ban.innerHTML = it ? `<div class="alert info" style="margin-bottom:12px;display:flex;align-items:center;gap:10px;flex-wrap:wrap"><span class="grow">📖 You have a reference sheet for <b>${esc(it.name)}</b>. Fill in the dose, schedule and how it's taken from it?</span><button type="button" class="btn sm primary" id="usesheet">Use the sheet</button></div>` : "";
          const b = $("#usesheet", el); if (b) b.onclick = () => { close(); medForm(null, prefillFromItem(it)); };
        });
        nm.addEventListener("change", () => {                 // nothing else typed yet: fill everything in from the sheet straight away
          const it = libFind(nm.value), f = $("#f", el);
          if (it && !f.dose.value && !f.vial_amount.value && !f.notes.value) { close(); toast(`Filled in from your reference sheet for ${it.name}`); medForm(null, prefillFromItem(it)); }
        });
      }

      const sm = $("#sheetmore", el); if (sm) sm.onclick = () => { const d = $("#sheetdetails", el); d.style.display = d.style.display === "none" ? "" : "none"; sm.textContent = d.style.display === "none" ? "Details" : "Hide"; };
      const fx = $("#fixsheet", el);
      if (fx) fx.onclick = () => { const it = pre.reference; close(); libEditModal(it, async () => { const l = (await api("/library")).find(x => x.id === it.id); medForm(null, l ? prefillFromItem(l) : pre); }); };

      // ---- catch-up for a medication started before you added it
      const form = $("#f", el), cu = $("#catchup", el), origStart = med ? med.start_date : null;
      const readSched = () => {
        const fd = new FormData(form), t = fd.get("stype"), times = [...new Set($$(".t", timesBox).map(i => i.value).filter(Boolean))].sort();
        const s = { type: t, times: t === "prn" ? [] : times };
        if (t === "interval") s.every = +fd.get("every") || 1;
        if (t === "weekdays") s.days = fd.getAll("day").map(Number);
        return s;
      };
      const cuActive = () => { const sd = form.start_date.value; return !!sd && sd < todayStr() && (!origStart || sd < origStart); };
      let cuTimer;
      const cuRefresh = () => {
        const on = cuActive(); cu.style.display = on ? "" : "none";
        clearTimeout(cuTimer); if (!on || !$("#cu-on", el).checked) { $("#cu-prev", el).innerHTML = ""; return; }
        cuTimer = setTimeout(async () => {
          const fd = new FormData(form), s = readSched(); if (s.type === "prn") { $("#cu-prev", el).innerHTML = '<span class="muted">As-needed medications have no schedule to catch up. Log doses as you take them.</span>'; return; }
          try {
            const r = await api("/meds/preview-catch-up", "POST", { schedule: s, since: fd.get("start_date"), until: origStart, end_date: fd.get("end_date"), cycle_on: fd.get("cycle_on"), cycle_off: fd.get("cycle_off"), dose: fd.get("dose"), start_stock: $("#cu-stock", el).value });
            const u = fd.get("dose_unit");
            $("#cu-prev", el).innerHTML = `<b>${r.count}</b> scheduled dose${r.count === 1 ? "" : "s"} since ${fmtDate(fd.get("start_date"), true)}${r.used != null ? ` (${num(r.used, 3)} ${esc(u)} used)` : ""}${r.left != null ? ` → about <b>${num(r.left, 2)} ${esc(u)}</b> left, enough for <b>${r.doses_left}</b> more dose${r.doses_left === 1 ? "" : "s"}` : ""}.`;
          } catch (e) { $("#cu-prev", el).innerHTML = ""; }
        }, 300);
      };
      form.addEventListener("input", cuRefresh); form.addEventListener("change", cuRefresh); cuRefresh();

      const supBox = $("#sups", el);
      const wireSup = row => { const cb = $("input[type=checkbox]", row), n = $("input[type=number]", row); cb.onchange = () => { n.disabled = !cb.checked; }; };
      $$("[data-sup]", supBox).forEach(wireSup);
      $("#addsup", el).onclick = async () => {
        const name = $("#newsup", el).value.trim(); if (!name) return toast("Type the supply's name first", true);
        const r = await api("/inventory", "POST", { name, category: "Supplies", unit: $("#newsupunit", el).value.trim() || "pcs", qty: 0 });
        if (!$("[data-sup]", supBox)) supBox.innerHTML = "";
        supBox.insertAdjacentHTML("beforeend", supRow({ id: r.ids[0], name, qty: 0, unit: $("#newsupunit", el).value.trim() || "pcs", per_dose: 1 }));
        wireSup(supBox.lastElementChild); $("#newsup", el).value = ""; toast("Added to Inventory (0 on hand). Update the amount there");
      };

      $("#f", el).onsubmit = async e => {
        e.preventDefault();
        const fd = new FormData(e.target), t = fd.get("stype"), type = fd.get("route_type"), r = R[type];
        const times = [...new Set($$(".t", timesBox).map(i => i.value).filter(Boolean))].sort();
        const schedule = { type: t, times: t === "prn" ? [] : times };
        if (t === "interval") schedule.every = +fd.get("every") || 1;
        if (t === "weekdays") { schedule.days = fd.getAll("day").map(Number); if (!schedule.days.length) return toast("Pick at least one day", true); }
        const on = +fd.get("cycle_on") || 0, off = +fd.get("cycle_off") || 0;
        if ((on > 0) !== (off > 0)) return toast("Enter both ON and OFF days for a cycle (or neither)", true);
        const sites = r.sites.length ? readChecklist(el, type) : null;
        if (sites && !sites.length) return toast("Keep at least one rotation site ticked", true);
        const cart = fd.get("ctnmode") === "cart", vialRaw = fd.get("vial_amount");
        try { if (r.vial) localStorage.setItem("wp_ctn_" + type, curMode()); } catch (er) { /* ignore */ }
        const vialTotal = vialRaw !== "" && fd.get("labelmode") === "perml" ? +(+vialRaw * (cart ? 3 : +fd.get("diluent_ml") || 0)).toFixed(4) : vialRaw;
        if (r.vial && vialRaw !== "" && fd.get("labelmode") === "perml" && !cart && !(+fd.get("diluent_ml") > 0)) return toast("Enter how many mL of liquid are in the vial.", true);
        const body = { name: fd.get("name"), kind: fd.get("kind"), route_type: type, dose: fd.get("dose"), dose_unit: fd.get("dose_unit"),
          schedule, start_date: fd.get("start_date"), end_date: fd.get("end_date"), cycle_on: on, cycle_off: off,
          stock_qty: fd.get("stock_qty"), refill_lead_days: fd.get("refill_lead_days"), notes: fd.get("notes"),
          container: r.vial && (cart || fd.get("usemode") === "pen") ? "pen" : "vial", vial_amount: r.vial ? vialTotal : null, vial_unit: r.vial ? fd.get("vial_unit") : null, diluent_ml: r.vial ? (cart ? 3 : fd.get("diluent_ml")) : null,
          opened_on: r.expiry ? fd.get("opened_on") : null, use_within_days: r.expiry ? fd.get("use_within_days") : null, sites, click_amt: r.vial && (cart || fd.get("usemode") === "pen") ? fd.get("click_amt") : null };
        if (!med && pre && pre.reference) body.reference = refFromItem(pre.reference);
        await run($(".primary", el), async () => {
          const links = $$("[data-sup]", el).filter(r => $("input[type=checkbox]", r).checked).map(r => ({ inv_id: +r.dataset.sup, per_dose: parseFloat($("input[type=number]", r).value) || 0 }));
          let id = med && med.id;
          if (med) await api("/meds/" + med.id, "PUT", body); else id = (await api("/meds", "POST", body)).id;
          await api(`/meds/${id}/supplies`, "PUT", { links });
          let note = "Saved";
          if (!med && pre && (pre.found || []).length && $("#useplan", el) && $("#useplan", el).checked && schedule.type !== "prn") {
            try { await api(`/meds/${id}/phases`, "PUT", { steps: stepsPayload(pre.found, schedule), start: fd.get("start_date") }); note = `Saved — dose steps set up (${pre.found.length} steps from your sheet)`; }
            catch (e) { note = "Saved, but the dose steps couldn't be set up: " + e.message; }
          }
          if (cuActive() && $("#cu-on", el).checked && schedule.type !== "prn") {
            const r = await api(`/meds/${id}/catch-up`, "POST", { since: fd.get("start_date"), until: origStart, start_stock: $("#cu-stock", el).value });
            note = `Saved — ${r.added} past dose${r.added === 1 ? "" : "s"} added${r.doses_left != null ? `, about ${r.doses_left} dose${r.doses_left === 1 ? "" : "s"} left` : ""}`;
          }
          close(); toast(note); Router.render();
        });
      };
    },
  });
}
