/* Shared helpers */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const App = { profile: null, settings: null };

async function api(path, method = "GET", body) {
  const r = await fetch("/api" + path, {
    method, headers: body ? { "Content-Type": "application/json", "X-WulfProtocol": "1" } : { "X-WulfProtocol": "1" }, body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await r.json(); } catch (e) { /* ignore */ }
  if (!r.ok) throw new Error((data && data.error) || `Request failed (${r.status})`);
  return data;
}

function toast(msg, bad) {
  const t = document.createElement("div");
  t.className = "toast" + (bad ? " bad" : ""); t.textContent = msg;
  $("#toasts").appendChild(t); setTimeout(() => t.remove(), bad ? 6000 : 2800);
}
async function run(btn, fn) {           // disable a button while an async action runs
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { if (btn) btn.disabled = false; }
}

/* ---- modal */
function modal(html, { wide, onMount } = {}) {
  const bg = document.createElement("div");
  bg.className = "modal-bg";
  bg.innerHTML = `<div class="modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true">${html}</div>`;
  let closed = false;
  const close = () => {
    if (closed) return; closed = true; document.removeEventListener("keydown", onKey);
    const calm = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (calm) { bg.remove(); return; }
    bg.classList.add("closing"); bg.setAttribute("aria-hidden", "true");          // a short fade-out; it can't be clicked meanwhile
    setTimeout(() => bg.remove(), 170);
  };
  const onKey = e => { if (e.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  bg.addEventListener("mousedown", e => { if (e.target === bg) close(); });
  document.body.appendChild(bg);
  $$("[data-close]", bg).forEach(b => b.addEventListener("click", close));
  if (onMount) onMount(bg, close);
  const first = $("input:not([type=hidden]), select", bg); if (first) first.focus();
  return { el: bg, close };
}
function confirmBox(msg, okLabel = "Delete") {
  return new Promise(res => {
    const m = modal(`<h2>Are you sure?</h2><p>${esc(msg)}</p>
      <div class="actions"><button class="btn" data-close>Cancel</button><button class="btn primary danger-fill" id="ok">${esc(okLabel)}</button></div>`);
    $("#ok", m.el).addEventListener("click", () => { m.close(); res(true); });
    $$("[data-close]", m.el).forEach(b => b.addEventListener("click", () => res(false)));
  });
}

/* ---- dates */
const pad = n => String(n).padStart(2, "0");
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const nowLocalInput = () => { const d = new Date(); return `${todayStr()}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const parseLocal = s => { const [d, t = "00:00"] = s.split("T"); const [y, m, dd] = d.split("-").map(Number); const [h, mi] = t.split(":").map(Number); return new Date(y, m - 1, dd, h, mi); };
const fmtTime = s => s.endsWith("T23:59") ? "Any time" : parseLocal(s).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
const fmtDate = (s, withYear) => parseLocal(s.length === 10 ? s + "T00:00" : s).toLocaleDateString([], { month: "short", day: "numeric", ...(withYear ? { year: "numeric" } : {}) });
const fmtDateTime = s => s.length === 10 ? fmtDate(s) : `${fmtDate(s)}, ${fmtTime(s)}`;
function dayLabel(s) {
  const d = parseLocal(s.slice(0, 10) + "T00:00"), t = parseLocal(todayStr() + "T00:00");
  const diff = Math.round((d - t) / 864e5);
  if (diff === 0) return "Today"; if (diff === 1) return "Tomorrow"; if (diff === -1) return "Yesterday";
  return d.toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" });
}
function rel(s) {           // "in 3h", "2d ago"
  const ms = parseLocal(s) - new Date(), a = Math.abs(ms), m = Math.round(a / 6e4);
  let t = m < 60 ? `${m}m` : m < 2880 ? `${Math.round(m / 60)}h` : `${Math.round(m / 1440)}d`;
  if (m < 1) return "now";
  return ms > 0 ? `in ${t}` : `${t} ago`;
}
const num = (v, d = 1) => (v == null || isNaN(v)) ? "–" : (+v).toLocaleString(undefined, { maximumFractionDigits: d });

/* ---- units: DB stores kg / cm */
const KG_LB = 2.2046226218, CM_IN = 1 / 2.54;
const METRICS = {
  weight: { label: "Weight", kind: "mass" }, body_fat: { label: "Body fat", unit: "%" },
  waist: { label: "Waist", kind: "length" }, chest: { label: "Chest", kind: "length" }, hips: { label: "Hips", kind: "length" },
  arm: { label: "Arm", kind: "length" }, thigh: { label: "Thigh", kind: "length" }, neck: { label: "Neck", kind: "length" },
  resting_hr: { label: "Resting HR", unit: "bpm" }, bp_sys: { label: "BP systolic", unit: "mmHg" }, bp_dia: { label: "BP diastolic", unit: "mmHg" },
  sleep: { label: "Sleep", unit: "h" },
};
const imperial = () => (App.profile?.units || "imperial") === "imperial";
const metricLabel = k => METRICS[k]?.label || k.replace(/_/g, " ").replace(/^./, c => c.toUpperCase());
function metricUnit(k) {
  const m = METRICS[k]; if (!m) return "";
  if (m.kind === "mass") return imperial() ? "lb" : "kg";
  if (m.kind === "length") return imperial() ? "in" : "cm";
  return m.unit || "";
}
function toDisplay(k, v) { const m = METRICS[k]; if (!m || v == null) return v; return m.kind === "mass" && imperial() ? v * KG_LB : m.kind === "length" && imperial() ? v * CM_IN : v; }
function fromDisplay(k, v) { const m = METRICS[k]; if (!m) return v; return m.kind === "mass" && imperial() ? v / KG_LB : m.kind === "length" && imperial() ? v / CM_IN : v; }
const fmtMetric = (k, v) => `${num(toDisplay(k, v), 1)} ${metricUnit(k)}`.trim();

const money = (v, cur) => {
  if (v == null) return "–";
  try { return v.toLocaleString(undefined, { style: "currency", currency: cur || "USD" }); } catch (e) { return "$" + v.toFixed(2); }
};


/* Unit dropdown: a real list (a text box with suggestions only shows the entries that match what's typed) + "Other…" for anything else.
   Keeps the chosen value in a hidden field named `name`, so forms and FormData work as before. */
function unitField(label, name, current, list) {
  const opts = [...new Set([...list, ...(current && !list.includes(current) ? [current] : [])])];
  return `<label class="f" data-unitwrap="${name}">${label}<select data-unit>${opts.map(u => `<option ${u === current ? "selected" : ""}>${esc(u)}</option>`).join("")}<option value="__other__">Other…</option></select>
    <input data-unitnew placeholder="Type the unit" style="display:none;margin-top:6px"><input type="hidden" name="${name}" value="${esc(current || opts[0] || "")}"></label>`;
}
function bindUnits(root) {
  $$("[data-unitwrap]", root).forEach(w => {
    const sel = $("[data-unit]", w), nw = $("[data-unitnew]", w), hid = $("input[type=hidden]", w);
    const sync = () => { const o = sel.value === "__other__"; nw.style.display = o ? "" : "none"; hid.value = o ? nw.value.trim() : sel.value; if (o) nw.focus(); };
    sel.onchange = sync; nw.oninput = () => { hid.value = nw.value.trim(); };
  });
}
function setUnitValue(root, name, v) {
  const w = $(`[data-unitwrap="${name}"]`, root); if (!w) return;
  const sel = $("[data-unit]", w), hid = $("input[type=hidden]", w);
  if (![...sel.options].some(o => o.value === v)) sel.insertBefore(new Option(v, v), sel.querySelector('[value="__other__"]'));
  sel.value = v; hid.value = v; $("[data-unitnew]", w).style.display = "none";
}
