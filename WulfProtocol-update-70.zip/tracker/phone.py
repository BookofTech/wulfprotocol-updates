"""Use WulfProtocol from a phone on the same home Wi-Fi.

Off unless switched on in Settings. When on, a second door into the same app opens on the home network (port PORT+1).
Everything that comes in through that door must sign in with a PIN first; the normal PC address (127.0.0.1) is unchanged.
The PIN is stored only as a hash. Five wrong PINs lock the phone door for 10 minutes. A few PC-only actions (quit, updates,
installing the browser, start-with-Windows, changing phone access) are refused from a phone.
"""
import hmac
import os
import secrets
import socket
import threading
import time

from itsdangerous import BadSignature, URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.serving import make_server

import db

COOKIE = "wp_phone"
COOKIE_DAYS = 30
MAX_TRIES, LOCK_SECONDS = 5, 600
PC_ONLY = ("/api/shutdown", "/api/update", "/api/install-browser", "/api/autostart", "/api/phone", "/api/bitwarden")
OPEN_PATHS = ("/phone-login", "/api/phone-login", "/static/style.css", "/static/fonts/", "/favicon")
SECRET_KEYS = ("phone_pin_hash", "phone_secret", "phone_pin_ver")   # never exported or shown

_state = {"server": None, "thread": None, "error": "", "port": None, "tries": 0, "locked_until": 0.0}
_lock = threading.Lock()


def _get(k, default=""):
    r = db.q("SELECT value FROM settings WHERE key=?", (k,))
    return r[0]["value"] if r else default


def _put(k, v):
    db.x("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)", (k, str(v)))


def _secret():
    s = _get("phone_secret")
    if not s:
        s = secrets.token_hex(32)
        _put("phone_secret", s)
    return s


def _signer():
    return URLSafeTimedSerializer(_secret(), salt="wp-phone")


def enabled():
    return _get("phone_on", "0") == "1" and bool(_get("phone_pin_hash"))


def lan_ip():
    """This PC's address on the home network (nothing is sent; the UDP 'connect' only picks a route)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return ""


def status(port):
    running = bool(_state["server"])
    ip = lan_ip()
    return {"on": _get("phone_on", "0") == "1", "has_pin": bool(_get("phone_pin_hash")), "running": running,
            "port": port, "ip": ip, "address": f"http://{ip}:{port}" if ip else "", "error": _state["error"]}


def set_pin(pin):
    pin = str(pin or "").strip()
    if not (pin.isdigit() and 4 <= len(pin) <= 8):
        raise ValueError("The PIN must be 4 to 8 numbers.")
    _put("phone_pin_hash", generate_password_hash(pin))
    _put("phone_pin_ver", int(_get("phone_pin_ver", "0") or 0) + 1)   # a new PIN signs every phone out
    _state.update(tries=0, locked_until=0.0)


def sign_out_all():
    _put("phone_pin_ver", int(_get("phone_pin_ver", "0") or 0) + 1)


def try_login(pin):
    """Returns (cookie value or None, message)."""
    now = time.time()
    with _lock:
        if now < _state["locked_until"]:
            mins = int((_state["locked_until"] - now) // 60) + 1
            return None, f"Too many wrong PINs. Try again in {mins} minute{'s' if mins > 1 else ''}."
        h = _get("phone_pin_hash")
        if h and check_password_hash(h, str(pin or "").strip()):
            _state["tries"] = 0
            return _signer().dumps({"v": _get("phone_pin_ver", "0")}), ""
        _state["tries"] += 1
        if _state["tries"] >= MAX_TRIES:
            _state.update(tries=0, locked_until=now + LOCK_SECONDS)
            return None, "Too many wrong PINs. Phone sign-in is locked for 10 minutes."
        left = MAX_TRIES - _state["tries"]
        return None, f"Wrong PIN. {left} tr{'ies' if left > 1 else 'y'} left."


def cookie_ok(value):
    if not value:
        return False
    try:
        data = _signer().loads(value, max_age=COOKIE_DAYS * 86400)
    except BadSignature:
        return False
    return hmac.compare_digest(str(data.get("v")), str(_get("phone_pin_ver", "0")))


def check(request):
    """Called for every request. None = carry on; otherwise ('login'|'pc_only'|'off')."""
    if not request.environ.get("wp.phone"):
        return None
    if not enabled():
        return "off"
    p = request.path
    if any(p == o or p.startswith(o) for o in OPEN_PATHS):
        return None
    if not cookie_ok(request.cookies.get(COOKIE)):
        return "login"
    if any(p == x or p.startswith(x + "/") for x in PC_ONLY) and request.method != "GET":
        return "pc_only"
    return None


class _PhoneDoor:
    """Marks requests that came in through the home-network door."""
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        environ["wp.phone"] = True
        return self.app(environ, start_response)


def start(app, port):
    with _lock:
        if _state["server"]:
            return
        try:
            srv = make_server(os.environ.get("PHONE_HOST", "0.0.0.0"), port, _PhoneDoor(app), threaded=True)
        except OSError as e:
            _state["error"] = f"Couldn't open phone access on port {port} ({e.strerror or e}). Another program may be using it."
            return
        _state.update(server=srv, error="", port=port)
        t = threading.Thread(target=srv.serve_forever, daemon=True, name="phone-door")
        t.start()
        _state["thread"] = t


def stop():
    with _lock:
        srv = _state["server"]
        _state.update(server=None, thread=None)
    if srv:
        threading.Thread(target=lambda: (srv.shutdown(), srv.server_close()), daemon=True).start()


def sync(app, port):
    """Open or close the phone door to match the setting."""
    if enabled():
        start(app, port)
    else:
        stop()
