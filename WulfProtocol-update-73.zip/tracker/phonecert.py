"""Certificates for phone offline mode.

A phone can only save the app for offline use (a "service worker") on a secure https address. This makes a small private
certificate authority that lives only on this PC (data/phone-cert), and a certificate for the phone address signed by it.
You install the authority's public certificate on your phone once and trust it; after that the phone trusts the app.

The authority is fenced in with name constraints: it can only vouch for this PC's own name (<name>.local) and home-network
addresses (192.168.x.x, 10.x.x.x, 172.16-31.x.x), never for real websites, even if someone copied its key.
The address certificate is renewed by itself when the PC's home-network address changes or it nears expiry; the phone keeps
trusting it because the authority stays the same. Needs the `cryptography` package (installed on demand from Settings).
"""
import datetime as dt
import ipaddress
import os
import socket
from pathlib import Path

import db

CA_DAYS = 3650
LEAF_DAYS = 800               # iPhones refuse server certificates valid for more than 825 days
PRIVATE_NETS = ("192.168.0.0/16", "10.0.0.0/8", "172.16.0.0/12", "127.0.0.0/8")


def available():
    try:
        import cryptography  # noqa: F401
        return True
    except Exception:
        return False


def folder():
    return db.DATA_DIR / "phone-cert"


def host_name():
    """This PC's name on the home network, e.g. bookoftech.local"""
    n = (socket.gethostname() or "").split(".")[0].strip().lower()
    return (n + ".local") if n else ""


def _ip_list(extra=()):
    out = []
    for ip in list(extra) + ["127.0.0.1"]:
        try:
            a = ipaddress.ip_address(ip)
            if a.version == 4 and any(a in ipaddress.ip_network(n) for n in PRIVATE_NETS) and a not in out:
                out.append(a)
        except ValueError:
            pass
    return out


def _write(p, data):
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(p)


def ensure_ca():
    """The private authority (made once). Returns (cert, key)."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    f = folder(); f.mkdir(parents=True, exist_ok=True)
    kp, cp = f / "ca.key", f / "ca.crt"
    if kp.exists() and cp.exists():
        return (x509.load_pem_x509_certificate(cp.read_bytes()),
                serialization.load_pem_private_key(kp.read_bytes(), password=None))
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    hn = host_name()
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "WulfProtocol on " + (hn.replace(".local", "") or "this PC")),
                      x509.NameAttribute(NameOID.ORGANIZATION_NAME, "WulfProtocol (private, this PC only)")])
    now = dt.datetime.now(dt.timezone.utc)
    permitted = [x509.IPAddress(ipaddress.ip_network(n)) for n in PRIVATE_NETS]
    if hn:
        permitted += [x509.DNSName(hn), x509.DNSName(hn.replace(".local", ""))]
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - dt.timedelta(days=1))
            .not_valid_after(now + dt.timedelta(days=CA_DAYS))
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True, content_commitment=False,
                                         key_encipherment=False, data_encipherment=False, key_agreement=False,
                                         encipher_only=False, decipher_only=False), critical=True)
            .add_extension(x509.NameConstraints(permitted_subtrees=permitted, excluded_subtrees=None), critical=True)
            .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
            .sign(key, hashes.SHA256()))
    _write(kp, key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    _write(cp, cert.public_bytes(serialization.Encoding.PEM))
    try:
        os.chmod(kp, 0o600)
    except OSError:
        pass
    return cert, key


def ca_der():
    """The authority's public certificate, in the form an iPhone installs."""
    from cryptography.hazmat.primitives import serialization
    cert, _ = ensure_ca()
    return cert.public_bytes(serialization.Encoding.DER)


def ensure_leaf(ips):
    """The certificate for the phone address. Re-made when the address list changes or it nears expiry.
    Returns (cert_path, key_path, renewed)."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
    ca, ca_key = ensure_ca()
    f = folder(); cp, kp = f / "phone.crt", f / "phone.key"
    hn = host_name()
    names = [n for n in (hn, hn.replace(".local", "")) if n]
    want_ips = _ip_list(ips)
    if cp.exists() and kp.exists():
        try:
            old = x509.load_pem_x509_certificate(cp.read_bytes())
            san = old.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            same = set(san.get_values_for_type(x509.DNSName)) == set(names) and set(san.get_values_for_type(x509.IPAddress)) == set(want_ips)
            fresh = old.not_valid_after_utc - dt.datetime.now(dt.timezone.utc) > dt.timedelta(days=30)
            if same and fresh and old.issuer == ca.subject:
                return cp, kp, False
        except Exception:
            pass
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    now = dt.datetime.now(dt.timezone.utc)
    cert = (x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, names[0] if names else str(want_ips[0]))]))
            .issuer_name(ca.subject).public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now - dt.timedelta(days=1)).not_valid_after(now + dt.timedelta(days=LEAF_DAYS))
            .add_extension(x509.SubjectAlternativeName([x509.DNSName(n) for n in names] + [x509.IPAddress(a) for a in want_ips]), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .add_extension(x509.KeyUsage(digital_signature=True, key_encipherment=True, content_commitment=False, data_encipherment=False,
                                         key_agreement=False, key_cert_sign=False, crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
            .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
            .sign(ca_key, hashes.SHA256()))
    _write(kp, key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    _write(cp, cert.public_bytes(serialization.Encoding.PEM) + ca.public_bytes(serialization.Encoding.PEM))
    return cp, kp, True
