/* WulfProtocol phone offline mode (service worker). Served as /sw.js on the phone's secure address only.
   - The app itself (page, scripts, styles, icons) is saved on the phone, so it opens with no connection to the PC.
   - Data (/api GETs) comes from the PC when it can be reached; the last copy is kept, so pages still show your
     doses, plan and reference sheets away from home. A copy served this way carries X-WP-Cache: 1.
   - Changes (logging a dose or weigh-in) are not handled here: the page keeps them and sends them when it's home. */
const BUILD = "__BUILD__", SHELL = "wp-shell-" + BUILD, DATA = "wp-data";
const ASSETS = __ASSETS__;
const NO_CACHE = ["/api/export", "/api/log", "/api/phone-login", "/phone-login", "/phone-ca.crt", "/sw.js", "/api/update"];
const WAIT_MS = 5000;     // how long to wait for the PC before using the saved copy

function timed(req, ms) {
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
  return fetch(req, { signal: ac.signal }).finally(() => clearTimeout(t));
}
async function putStamped(cache, key, resp) {
  const d = new Date(), p = n => String(n).padStart(2, "0");
  const h = new Headers(resp.headers); h.set("X-WP-Saved-At", `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`);
  await cache.put(key, new Response(await resp.clone().blob(), { status: resp.status, statusText: resp.statusText, headers: h }));
}
async function fromCache(cacheName, key) {
  const hit = await (await caches.open(cacheName)).match(key);
  if (!hit) return null;
  const h = new Headers(hit.headers); h.set("X-WP-Cache", "1");
  return new Response(await hit.blob(), { status: hit.status, statusText: hit.statusText, headers: h });
}

self.addEventListener("install", e => {
  e.waitUntil((async () => {
    const c = await caches.open(SHELL);
    for (const u of ["/"].concat(ASSETS)) {
      try { const r = await fetch(u, { credentials: "same-origin" }); if (r.ok && !r.redirected) await c.put(u, r); } catch (x) { /* saved later */ }
    }
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k.startsWith("wp-shell-") && k !== SHELL) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== location.origin || NO_CACHE.some(p => url.pathname === p || url.pathname.startsWith(p + "/"))) return;
  if (req.mode === "navigate" || url.pathname === "/") {            // the app page
    e.respondWith((async () => {
      try {
        const r = await timed(req, WAIT_MS);
        if (r.ok && !r.redirected) await (await caches.open(SHELL)).put("/", r.clone());
        return r;
      } catch (x) {
        const hit = await (await caches.open(SHELL)).match("/");
        return hit || new Response("<!doctype html><meta name=viewport content='width=device-width'><body style='background:#0b1016;color:#e8eef5;font:16px system-ui;padding:40px 20px;text-align:center'>" +
          "<h2>Can't reach your PC</h2><p>WulfProtocol hasn't been saved on this phone yet. Open it once at home on your Wi-Fi first.</p></body>",
          { status: 503, headers: { "Content-Type": "text/html; charset=utf-8" } });
      }
    })());
    return;
  }
  if (url.pathname.startsWith("/static/")) {                         // app files: saved copy first
    e.respondWith((async () => {
      const c = await caches.open(SHELL), hit = await c.match(req);
      if (hit) return hit;
      const r = await fetch(req);
      if (r.ok) c.put(req, r.clone());
      return r;
    })());
    return;
  }
  if (url.pathname.startsWith("/api/")) {                            // data: from the PC, else the last saved copy
    e.respondWith((async () => {
      try {
        const r = await timed(req, WAIT_MS);
        if (r.ok) await putStamped(await caches.open(DATA), req.url, r);
        return r;
      } catch (x) {
        return (await fromCache(DATA, req.url)) || new Response(JSON.stringify({ error: "offline" }),
          { status: 503, headers: { "Content-Type": "application/json", "X-WP-Cache": "1", "X-WP-Offline": "1" } });
      }
    })());
  }
});
