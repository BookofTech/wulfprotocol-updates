"""Dose reminder pop-ups: a small Windows notification when a timed dose is due ("Time for LL-37 - 200 mcg").

Off unless switched on in Settings. Checked once a minute while the app runs (including in the background). Each dose time
pops up once, also across restarts. "Any time" doses don't pop up (they have no set time). Nothing is sent anywhere: the
pop-up is shown by Windows itself through a hidden PowerShell call. For tests, WP_NOTIFY_LOG=<file> writes the pop-ups to a
file instead of showing them.
"""
import json
import os
import subprocess
import threading
import time
from datetime import datetime, timedelta

import db
import schedule as sch

SENT_KEY = "popup_sent"
_PS = r"""
$ErrorActionPreference = 'Stop'
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
$t = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$x = $t.GetElementsByTagName('text')
$x.Item(0).AppendChild($t.CreateTextNode($env:WP_TITLE)) > $null
$x.Item(1).AppendChild($t.CreateTextNode($env:WP_BODY)) > $null
$n = [Windows.UI.Notifications.ToastNotification]::new($t)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe').Show($n)
"""


def notify(title, body):
    """Show a Windows pop-up. Returns True if it was shown (or logged in test mode)."""
    log = os.environ.get("WP_NOTIFY_LOG")
    if log:
        with open(log, "a", encoding="utf-8") as f:
            f.write(json.dumps({"title": title, "body": body}) + "\n")
        return True
    if os.name != "nt":
        return False
    try:
        r = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _PS],
                           env=dict(os.environ, WP_TITLE=title[:120], WP_BODY=body[:200]), capture_output=True, timeout=20,
                           creationflags=0x08000000)       # no console window
        return r.returncode == 0
    except Exception:
        return False


def _fmt(n):
    return ("%g" % n) if isinstance(n, (int, float)) else str(n or "")


def due_now(now=None):
    """Timed doses whose time has come (within the grace period) and that aren't logged yet."""
    now = now or datetime.now()
    grace = db.get_settings()["grace_minutes"]
    out = []
    for m in db.q("SELECT * FROM meds WHERE active=1"):
        for slot in sch.slots_between(m, now - timedelta(minutes=max(grace, 1)), now):
            key = sch.iso(slot)
            if key.endswith("T23:59"):
                continue                                            # "any time": no set time to remind at
            if db.q("SELECT 1 FROM dose_logs WHERE med_id=? AND slot=?", (m["id"], key)):
                continue
            out.append({"med_id": m["id"], "name": m["name"], "dose": m["dose"], "unit": m["dose_unit"], "slot": key})
    return out


def _sent():
    r = db.q("SELECT value FROM settings WHERE key=?", (SENT_KEY,))
    try:
        return json.loads(r[0]["value"]) if r else []
    except Exception:
        return []


def check_once(now=None):
    """Pop up every due dose not popped up before. Returns how many were shown."""
    cfg = db.get_settings()
    if not (cfg.get("dose_popups") and cfg["use_meds"]):
        return 0
    sent = _sent()
    shown = 0
    for d in due_now(now):
        k = f"{d['med_id']}|{d['slot']}"
        if k in sent:
            continue
        dose = f"{_fmt(d['dose'])} {d['unit']}".strip() if d["dose"] is not None else ""
        if notify(f"Time for {d['name']}", (dose + " · " if dose else "") + "Open WulfProtocol to log it."):
            shown += 1
        sent.append(k)
    db.x("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)", (SENT_KEY, json.dumps(sent[-200:])))
    return shown


def start():
    def loop():
        while True:
            try:
                check_once()
            except Exception:
                pass
            time.sleep(int(os.environ.get("WP_REMIND_EVERY", 60)))
    threading.Thread(target=loop, daemon=True, name="dose-popups").start()
